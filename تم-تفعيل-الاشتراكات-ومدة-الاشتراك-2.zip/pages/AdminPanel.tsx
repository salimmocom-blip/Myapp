
import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { ShieldCheck, Lock, CheckCircle, Trash2, ArrowLeft, Key, AlertOctagon, AlertTriangle, Calendar, Clock, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const AdminPanel: React.FC = () => {
  const navigate = useNavigate();
  const { approvedIds, approveId, revokeId, storeProfile, realUser } = useStore();
  
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [inputStoreId, setInputStoreId] = useState('');
  const [selectedDuration, setSelectedDuration] = useState<number>(1); // Default 1 month

  // Delete Modal State
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [idToDelete, setIdToDelete] = useState<string | null>(null);

  // The specific Admin Phone Number
  const ADMIN_PHONE = '01050011413';
  // Hardcoded Admin Password
  const ADMIN_PASSWORD = '0000';

  // Security Check
  if (realUser !== ADMIN_PHONE) {
      return (
          <div className="min-h-screen bg-gray-50 dark:bg-slate-900 flex flex-col items-center justify-center p-6 text-center">
              <div className="bg-red-100 dark:bg-red-900/30 p-6 rounded-full mb-6">
                  <AlertOctagon size={64} className="text-red-600 dark:text-red-500" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">غير مصرح بالدخول</h1>
              <p className="text-gray-500 dark:text-gray-400 mb-8 max-w-xs mx-auto">
                  عذراً، هذه الصفحة مخصصة فقط لمسؤول النظام (رقم الهاتف {ADMIN_PHONE}).
              </p>
              <button 
                  onClick={() => navigate('/reports')}
                  className="bg-gray-800 dark:bg-slate-700 text-white px-8 py-3 rounded-xl font-bold hover:bg-gray-700 transition-colors"
              >
                  العودة للإعدادات
              </button>
          </div>
      );
  }

  const handleLogin = () => {
      if (password === ADMIN_PASSWORD) {
          setIsAuthenticated(true);
      } else {
          alert('كلمة المرور غير صحيحة');
          setPassword('');
      }
  };

  const handleApprove = () => {
      if (inputStoreId.length < 3) {
          alert('يرجى إدخال ID صحيح');
          return;
      }
      approveId(inputStoreId, selectedDuration);
      setInputStoreId('');
      alert('تم تفعيل/تجديد الاشتراك بنجاح');
  };

  const handleQuickActivate = () => {
      if (storeProfile.id) {
          approveId(storeProfile.id, selectedDuration);
          alert('تم تفعيل/تجديد هذا الجهاز بنجاح');
      }
  };
  
  const handleDeleteClick = (id: string) => {
       setIdToDelete(id);
       setShowDeleteConfirm(true);
  };

  const confirmDelete = () => {
      if (idToDelete) {
          revokeId(idToDelete);
          setShowDeleteConfirm(false);
          setIdToDelete(null);
      }
  };

  // Helper to calculate days remaining
  const getDaysRemaining = (endDateStr: string) => {
      const now = new Date();
      const end = new Date(endDateStr);
      const diffTime = end.getTime() - now.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
  };

  const isCurrentDevicePro = approvedIds.some(sub => sub.id === storeProfile.id);

  if (!isAuthenticated) {
      return (
          <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-6 text-white">
              <div className="bg-slate-800 p-8 rounded-2xl w-full max-w-sm shadow-2xl border border-slate-700">
                  <div className="flex justify-center mb-6">
                      <div className="bg-red-500/10 p-4 rounded-full text-red-500">
                          <Lock size={48} />
                      </div>
                  </div>
                  <h1 className="text-2xl font-bold text-center mb-2">لوحة التحكم</h1>
                  <p className="text-emerald-400 text-center mb-4 text-xs font-mono font-bold">المستخدم المصرح: {ADMIN_PHONE}</p>
                  <p className="text-gray-400 text-center mb-6 text-sm">أدخل كلمة مرور المسؤول للمتابعة</p>
                  
                  <input 
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-600 rounded-xl p-4 text-center text-xl font-bold tracking-widest mb-4 outline-none focus:border-red-500 transition-colors"
                      placeholder="••••"
                      autoFocus
                  />
                  
                  <button 
                      onClick={handleLogin}
                      className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 rounded-xl transition-colors"
                  >
                      دخول
                  </button>
                  
                  <button 
                      onClick={() => navigate(-1)}
                      className="w-full mt-4 text-gray-500 hover:text-white text-sm"
                  >
                      عودة
                  </button>
              </div>
          </div>
      );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors pb-10">
        <div className="bg-white dark:bg-slate-800 p-4 shadow-sm border-b border-gray-100 dark:border-slate-700 sticky top-0 z-10 flex items-center justify-between">
            <div className="flex items-center">
                <button onClick={() => navigate('/reports')} className="p-2 -mr-2 text-gray-600 dark:text-gray-300">
                    <ArrowLeft size={24} />
                </button>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white mr-2 flex items-center gap-2">
                    <ShieldCheck className="text-red-600" />
                    لوحة تفعيل الاشتراكات
                </h1>
            </div>
        </div>

        <div className="p-4 space-y-6 max-w-lg mx-auto">
            {/* Quick Action Card */}
            <div className="bg-gradient-to-l from-slate-800 to-slate-900 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                    <Key size={100} />
                </div>
                <h2 className="text-lg font-bold mb-1">تفعيل الجهاز الحالي</h2>
                <p className="text-gray-400 text-sm mb-4">ID: <span className="font-mono text-white">{storeProfile.id}</span></p>
                
                {isCurrentDevicePro ? (
                     <div className="flex items-center gap-2 bg-emerald-500/20 text-emerald-400 px-3 py-2 rounded-lg w-fit mb-3">
                         <CheckCircle size={18} />
                         <span className="font-bold text-sm">هذا الجهاز مفعل (Pro)</span>
                     </div>
                ) : null}

                <div className="flex gap-2">
                    <button 
                        onClick={handleQuickActivate}
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg font-bold shadow-lg transition-colors flex items-center justify-center gap-2"
                    >
                        {isCurrentDevicePro ? <RefreshCw size={18}/> : <CheckCircle size={18}/>}
                        {isCurrentDevicePro ? 'تجديد الاشتراك' : 'تفعيل الآن'}
                    </button>
                </div>
            </div>

            {/* Manual Activation */}
            <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700">
                <h3 className="font-bold text-gray-800 dark:text-white mb-4">تفعيل / تجديد حساب</h3>
                
                {/* Duration Select */}
                <div className="grid grid-cols-4 gap-2 mb-4">
                    {[1, 3, 6, 12].map(m => (
                        <button
                            key={m}
                            onClick={() => setSelectedDuration(m)}
                            className={`py-2 rounded-lg text-sm font-bold border transition-all ${
                                selectedDuration === m 
                                ? 'bg-emerald-500 text-white border-emerald-500' 
                                : 'bg-gray-50 dark:bg-slate-700 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-slate-600'
                            }`}
                        >
                            {m} شهر
                        </button>
                    ))}
                </div>

                <div className="flex gap-2">
                    <input 
                        type="text" 
                        value={inputStoreId}
                        onChange={(e) => setInputStoreId(e.target.value)}
                        placeholder="أدخل ID المتجر..."
                        className="flex-1 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl p-3 text-center font-mono text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    <button 
                        onClick={handleApprove}
                        disabled={!inputStoreId}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 rounded-xl font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        تنفيذ
                    </button>
                </div>
            </div>

            {/* Approved List */}
            <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700 overflow-hidden">
                <div className="p-4 border-b border-gray-100 dark:border-slate-700 bg-gray-50 dark:bg-slate-700/50 flex justify-between items-center">
                    <h3 className="font-bold text-gray-800 dark:text-white">الاشتراكات ({approvedIds.length})</h3>
                </div>
                <div className="divide-y divide-gray-100 dark:divide-slate-700">
                    {approvedIds.length > 0 ? (
                        approvedIds.map(sub => {
                            const daysRemaining = getDaysRemaining(sub.endDate);
                            const isExpired = daysRemaining < 0;

                            return (
                                <div key={sub.id} className="p-4 hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors">
                                    <div className="flex justify-between items-start mb-2">
                                        <div className="flex items-center gap-2">
                                            <span className="font-mono font-bold text-lg text-gray-800 dark:text-white">
                                                {sub.id}
                                            </span>
                                            {sub.id === storeProfile.id && <span className="text-[10px] bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 px-1.5 py-0.5 rounded">(أنت)</span>}
                                        </div>
                                        <button 
                                            onClick={() => handleDeleteClick(sub.id)}
                                            className="text-red-400 hover:text-red-600"
                                            title="إلغاء الاشتراك"
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    </div>

                                    <div className="grid grid-cols-2 gap-2 text-xs text-gray-500 dark:text-gray-400 mb-2">
                                        <div className="flex items-center gap-1">
                                            <Calendar size={12} />
                                            <span>البدء: {new Date(sub.startDate).toLocaleDateString('en-GB')}</span>
                                        </div>
                                        <div className="flex items-center gap-1">
                                            <Clock size={12} />
                                            <span>الانتهاء: {new Date(sub.endDate).toLocaleDateString('en-GB')}</span>
                                        </div>
                                    </div>

                                    <div className="flex items-center justify-between">
                                        <div className={`text-xs font-bold px-2 py-1 rounded ${
                                            isExpired 
                                            ? 'bg-red-100 dark:bg-red-900/30 text-red-600' 
                                            : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600'
                                        }`}>
                                            {isExpired ? 'منتهي الصلاحية' : `نشط - باقي ${daysRemaining} يوم`}
                                        </div>
                                        <button 
                                            onClick={() => { setInputStoreId(sub.id); }}
                                            className="text-xs text-blue-500 hover:underline flex items-center gap-1"
                                        >
                                            <RefreshCw size={10} />
                                            تجديد
                                        </button>
                                    </div>
                                </div>
                            );
                        })
                    ) : (
                        <div className="p-8 text-center text-gray-400">
                            لا توجد اشتراكات مسجلة
                        </div>
                    )}
                </div>
            </div>
        </div>

        {/* --- Delete Confirmation Modal --- */}
        {showDeleteConfirm && (
            <div className="fixed inset-0 bg-black bg-opacity-60 z-[80] flex items-center justify-center p-4 animate-fade-in">
                <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 text-center shadow-xl transition-colors">
                    <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                        <AlertTriangle size={32} className="text-red-600 dark:text-red-500" />
                    </div>
                    <h3 className="font-bold text-lg text-gray-900 dark:text-white mb-2">إلغاء الاشتراك؟</h3>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">
                        هل أنت متأكد من حذف الاشتراك للحساب ({idToDelete})؟
                        <br />
                        <span className="text-red-500 font-bold block mt-2">سيعود الحساب للنسخة المجانية فوراً</span>
                    </p>
                    <div className="flex space-x-3 space-x-reverse">
                        <button 
                            onClick={confirmDelete}
                            className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 rounded-xl font-bold transition-colors shadow-lg"
                        >
                            نعم، حذف
                        </button>
                        <button 
                            onClick={() => { setShowDeleteConfirm(false); setIdToDelete(null); }}
                            className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 py-3 rounded-xl font-bold transition-colors hover:bg-gray-200 dark:hover:bg-slate-600"
                        >
                            إلغاء
                        </button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default AdminPanel;
