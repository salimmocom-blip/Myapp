
import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Product, TransactionType, Transaction, PaymentMethod } from '../types';
import { Search, Edit2, Trash2, Plus, Package, History, User, Calendar, AlertTriangle, X, PlusCircle, Check, FileText, ChevronDown } from 'lucide-react';

const Inventory: React.FC = () => {
  const { products, addProduct, updateProduct, deleteProduct, transactions, updateTransaction, addTransaction, contacts, hasPermission } = useStore();
  const canManageInventory = hasPermission('INVENTORY');
  
  // Modal States
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [viewingProduct, setViewingProduct] = useState<Product | null>(null); // For Details View
  
  const [search, setSearch] = useState('');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Delete Confirmation State
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [productToDeleteId, setProductToDeleteId] = useState<string | null>(null);

  // History Edit State
  const [isHistoryEditOpen, setIsHistoryEditOpen] = useState(false);
  const [historyEditData, setHistoryEditData] = useState<{
      transactionId: string;
      productId: string;
      quantity: number;
      buyPrice: number;
      sellPrice: number; 
  } | null>(null);

  // --- Quick Add Stock State ---
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [addStockProduct, setAddStockProduct] = useState<Product | null>(null);
  const [addStockQty, setAddStockQty] = useState('');
  const [addStockBuyPrice, setAddStockBuyPrice] = useState('');
  const [addStockSellPrice, setAddStockSellPrice] = useState('');
  const [addStockWithInvoice, setAddStockWithInvoice] = useState(false);
  const [addStockSupplierId, setAddStockSupplierId] = useState('');
  const [addStockPaidAmount, setAddStockPaidAmount] = useState('');

  // Form State
  const [formData, setFormData] = useState<Partial<Product>>({
    name: '',
    code: '',
    buyPrice: 0,
    sellPrice: 0,
    stock: 0,
    minStock: 5
  });

  // --- Edit/Create Logic ---
  const openEditModal = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setFormData(product);
    } else {
      setEditingProduct(null);
      setFormData({ name: '', code: '', buyPrice: 0, sellPrice: 0, stock: 0, minStock: 5 });
    }
    setIsEditModalOpen(true);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nameToCheck = formData.name?.trim();
    if (!nameToCheck) return;

    // Check for duplicate name (ignore current product if editing)
    const isDuplicate = products.some(p => 
        p.name.trim() === nameToCheck && 
        p.id !== (editingProduct?.id || '')
    );

    if (isDuplicate) {
        alert('هذا المنتج موجود بالفعل في المخزن! الرجاء اختيار اسم آخر.');
        return;
    }

    const productPayload = {
      id: editingProduct ? editingProduct.id : Date.now().toString(),
      ...formData,
      buyPrice: editingProduct ? editingProduct.buyPrice : 0, // Preserve internal cost or 0
      sellPrice: 0, // Reset or ignore sell price as requested
      name: nameToCheck // Use trimmed name
    } as Product;

    if (editingProduct) {
      updateProduct(productPayload);
      setIsEditModalOpen(false);
    } else {
      const success = addProduct(productPayload);
      if (success) {
          setIsEditModalOpen(false);
      }
    }
  };

  // Trigger Delete Confirmation
  const handleDeleteClick = (id: string, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    setProductToDeleteId(id);
    setShowDeleteConfirm(true);
  };

  // Execute Delete
  const confirmDelete = () => {
    if (productToDeleteId) {
        deleteProduct(productToDeleteId);
        
        // Reset states
        setShowDeleteConfirm(false);
        setProductToDeleteId(null);
        
        // Close other modals if the deleted product was being viewed/edited
        if (editingProduct?.id === productToDeleteId) setIsEditModalOpen(false);
        if (viewingProduct?.id === productToDeleteId) setViewingProduct(null);
    }
  };

  // --- Details Logic ---
  const openDetails = (product: Product) => {
    setViewingProduct(product);
  };

  // --- Quick Add Stock Logic ---
  const openQuickAddStock = (product: Product) => {
      setAddStockProduct(product);
      setAddStockQty('');
      setAddStockBuyPrice(product.buyPrice.toString());
      setAddStockSellPrice(product.sellPrice.toString());
      setAddStockWithInvoice(false);
      setAddStockSupplierId('');
      setAddStockPaidAmount('');
      setIsQuickAddOpen(true);
  };

  const handleQuickStockSubmit = () => {
      if (!addStockProduct || !addStockQty) return;
      const qty = parseFloat(addStockQty);
      const buyPrice = parseFloat(addStockBuyPrice) || 0;
      const sellPrice = parseFloat(addStockSellPrice) || 0;

      if (isNaN(qty) || qty <= 0) {
          alert('الرجاء إدخال كمية صحيحة');
          return;
      }

      if (addStockWithInvoice) {
          // Create Purchase Transaction
          const totalAmount = qty * buyPrice;
          const paid = addStockPaidAmount ? parseFloat(addStockPaidAmount) : totalAmount;

          addTransaction({
              id: Date.now().toString(),
              type: TransactionType.PURCHASE,
              date: new Date().toISOString(),
              amount: totalAmount,
              paidAmount: paid,
              paymentMethod: PaymentMethod.CASH,
              items: [{
                  productId: addStockProduct.id,
                  productName: addStockProduct.name,
                  quantity: qty,
                  price: buyPrice,
                  sellPrice: sellPrice
              }],
              contactId: addStockSupplierId || undefined,
              notes: 'إضافة مخزون سريعة'
          });
      } else {
          // Direct Update (Calculate Weighted Average)
          const currentStock = addStockProduct.stock;
          const currentBuy = addStockProduct.buyPrice;
          
          const totalQty = currentStock + qty;
          let newAvgBuy = currentBuy;
          
          if (totalQty > 0) {
              newAvgBuy = ((currentStock * currentBuy) + (qty * buyPrice)) / totalQty;
          }

          const updatedProduct = {
              ...addStockProduct,
              stock: totalQty,
              buyPrice: parseFloat(newAvgBuy.toFixed(2)),
              sellPrice: sellPrice
          };
          updateProduct(updatedProduct);
      }

      setIsQuickAddOpen(false);
      setAddStockProduct(null);
  };

  // Get Purchase History for the viewing product
  const getProductHistory = (productId: string) => {
    const product = products.find(p => p.id === productId);
    return transactions
      .filter(t => 
        t.type === TransactionType.PURCHASE && 
        t.items?.some(item => item.productId === productId)
      )
      .map(t => {
        const item = t.items?.find(i => i.productId === productId);
        const contact = contacts.find(c => c.id === t.contactId);
        return {
          transactionId: t.id,
          productId: productId,
          date: t.date,
          supplierName: contact ? contact.name : 'مورد غير محدد',
          quantity: item?.quantity || 0,
          price: item?.price || 0, // Historical buy price
          sellPrice: item?.sellPrice || 0, // Historical Sell Price
          total: (item?.quantity || 0) * (item?.price || 0)
        };
      });
  };

  // --- History Edit Logic ---
  const openHistoryEdit = (record: any) => {
      setHistoryEditData({
          transactionId: record.transactionId,
          productId: record.productId,
          quantity: record.quantity,
          buyPrice: record.price,
          sellPrice: record.sellPrice
      });
      setIsHistoryEditOpen(true);
  };

  const saveHistoryEdit = () => {
      if (!historyEditData) return;

      // 1. Update Transaction (Quantity & Buy Price)
      const transaction = transactions.find(t => t.id === historyEditData.transactionId);
      if (transaction && transaction.items) {
          // Clone items and update the specific one
          const updatedItems = transaction.items.map(item => {
              if (item.productId === historyEditData.productId) {
                  return {
                      ...item,
                      quantity: Number(historyEditData.quantity),
                      price: Number(historyEditData.buyPrice),
                      sellPrice: Number(historyEditData.sellPrice)
                  };
              }
              return item;
          });

          // Recalculate total amount
          const newTotal = updatedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0) - (transaction.discount || 0);

          // Update paid amount if necessary
          let newPaid = transaction.paidAmount || 0;
          if (newPaid > newTotal) newPaid = newTotal;
          if ((transaction.paidAmount || 0) >= transaction.amount) {
              newPaid = newTotal;
          }

          const updatedTransaction: Transaction = {
              ...transaction,
              items: updatedItems,
              amount: newTotal,
              paidAmount: newPaid
          };

          updateTransaction(transaction.id, updatedTransaction);
      }
      
      setIsHistoryEditOpen(false);
      setHistoryEditData(null);
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.code?.includes(search)
  );

  return (
    <div className="p-4 pb-24 min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">المنتجات والمخزون</h1>
        {canManageInventory && (
            <button onClick={() => openEditModal()} className="bg-primary text-white p-2 rounded-lg shadow-md">
                <Plus size={24} />
            </button>
        )}
      </div>

      <div className="relative mb-6">
        <Search className="absolute right-3 top-3 text-gray-400" size={20} />
        <input 
          type="text"
          placeholder="بحث بالاسم أو الكود..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full p-3 pr-10 border border-gray-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-slate-800 text-gray-900 dark:text-white"
        />
      </div>

      <div className="space-y-3">
        {filteredProducts.map(product => (
          <div 
            key={product.id} 
            onClick={() => openDetails(product)} // Clicking card opens Details now
            className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex justify-between items-center cursor-pointer hover:border-primary/30 transition-colors"
          >
            <div className="flex items-center flex-1">
               <div className={`p-3 rounded-lg mr-3 ${product.stock <= product.minStock ? 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400' : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400'}`}>
                  <Package size={24} />
               </div>
               <div>
                 <h3 className="font-bold text-gray-800 dark:text-white">{product.name}</h3>
                 <p className="text-xs text-gray-500 dark:text-gray-400">كود: {product.code || '-'}</p>
                 <div className="flex gap-2 mt-1">
                     <span className="text-[10px] bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-300 px-1.5 py-0.5 rounded">شراء: {product.buyPrice}</span>
                     <span className="text-[10px] bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-300 px-1.5 py-0.5 rounded">بيع: {product.sellPrice}</span>
                 </div>
               </div>
            </div>
            <div className="text-left flex flex-col items-end">
                <div className="flex items-center mb-2">
                    <span className={`text-sm font-bold ml-2 ${product.stock <= product.minStock ? 'text-red-600 dark:text-red-400' : 'text-gray-800 dark:text-white'}`}>
                        الكمية: {product.stock}
                    </span>
                    {canManageInventory && (
                        <button
                            onClick={(e) => { e.stopPropagation(); openQuickAddStock(product); }}
                            className="p-1.5 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-lg hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-colors"
                            title="إضافة رصيد سريع"
                        >
                            <PlusCircle size={18} />
                        </button>
                    )}
                </div>
                
                {canManageInventory && (
                    <div className="flex space-x-2 space-x-reverse z-10">
                        <button 
                            type="button"
                            onClick={(e) => { e.stopPropagation(); openEditModal(product); }} 
                            className="p-2 bg-gray-100 dark:bg-slate-700 rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-600"
                        >
                            <Edit2 size={18} />
                        </button>
                        <button 
                            type="button"
                            onClick={(e) => handleDeleteClick(product.id, e)} 
                            className="p-2 bg-red-50 dark:bg-red-900/20 rounded-md text-red-500 hover:bg-red-100 dark:hover:bg-red-900/40"
                        >
                            <Trash2 size={18} />
                        </button>
                    </div>
                )}
            </div>
          </div>
        ))}
        {filteredProducts.length === 0 && <p className="text-center text-gray-400 mt-10">لا توجد منتجات</p>}
      </div>

      {/* --- Details Modal --- */}
      {viewingProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end sm:items-center justify-center animate-fade-in">
            <div className="bg-white dark:bg-slate-800 w-full max-w-md h-[85vh] sm:h-auto sm:rounded-2xl rounded-t-2xl p-6 animate-slide-up sm:animate-none flex flex-col transition-colors">
                <div className="flex justify-between items-start mb-4 border-b border-gray-100 dark:border-slate-700 pb-4">
                    <div>
                        <h2 className="text-xl font-bold text-gray-800 dark:text-white">{viewingProduct.name}</h2>
                        <p className="text-gray-500 dark:text-gray-400 text-sm">كود: {viewingProduct.code || 'N/A'}</p>
                    </div>
                    <button onClick={() => setViewingProduct(null)} className="text-gray-400 hover:text-gray-600">
                        إغلاق
                    </button>
                </div>

                <div className="grid grid-cols-1 gap-2 mb-6 text-center">
                    <div className="bg-gray-50 dark:bg-slate-700 p-3 rounded-lg flex justify-around items-center">
                        <div>
                             <span className="text-xs text-gray-500 dark:text-gray-300 block">المخزون الحالي</span>
                             <span className="font-bold text-gray-800 dark:text-white text-xl">{viewingProduct.stock}</span>
                        </div>
                        {canManageInventory && (
                            <button 
                                onClick={() => openQuickAddStock(viewingProduct)}
                                className="flex items-center gap-1 bg-emerald-600 text-white px-3 py-1.5 rounded-lg text-sm font-bold shadow-sm"
                            >
                                <PlusCircle size={16}/>
                                إضافة
                            </button>
                        )}
                    </div>
                </div>

                <div className="flex-1 overflow-hidden flex flex-col">
                    <h3 className="font-bold text-gray-800 dark:text-gray-200 mb-3 flex items-center text-sm">
                        <History size={16} className="ml-2 text-primary"/>
                        سجل المشتريات
                    </h3>
                    
                    <div className="overflow-y-auto flex-1 no-scrollbar space-y-3">
                        {getProductHistory(viewingProduct.id).length > 0 ? (
                            getProductHistory(viewingProduct.id).map((record, idx) => (
                                <div key={idx} className="bg-gray-50 dark:bg-slate-700 p-3 rounded-lg border border-gray-100 dark:border-slate-600 text-sm relative group">
                                    <div className="flex justify-between mb-2">
                                        <div className="flex items-center text-gray-600 dark:text-gray-300">
                                            <User size={14} className="ml-1"/>
                                            <span className="font-bold">{record.supplierName}</span>
                                        </div>
                                        <div className="flex items-center text-gray-400 text-xs">
                                            <Calendar size={12} className="ml-1"/>
                                            {new Date(record.date).toLocaleDateString('ar-EG')}
                                        </div>
                                    </div>
                                    
                                    {/* Grid Layout for details */}
                                    <div className="grid grid-cols-4 gap-2 border-t border-gray-200 dark:border-slate-600 pt-2 text-xs text-center">
                                        <div>
                                            <span className="text-gray-500 dark:text-gray-400 block mb-0.5">الكمية</span>
                                            <span className="font-bold text-gray-800 dark:text-white">{record.quantity}</span>
                                        </div>
                                        <div>
                                            <span className="text-gray-500 dark:text-gray-400 block mb-0.5">شراء</span>
                                            <span className="font-bold text-blue-600 dark:text-blue-400">{record.price}</span>
                                        </div>
                                        <div>
                                            <span className="text-gray-500 dark:text-gray-400 block mb-0.5">بيع</span>
                                            <span className="font-bold text-emerald-600 dark:text-emerald-400">{record.sellPrice}</span>
                                        </div>
                                        <div>
                                            <span className="text-gray-500 dark:text-gray-400 block mb-0.5">الإجمالي</span>
                                            <span className="font-bold text-gray-800 dark:text-white">{record.total.toLocaleString()}</span>
                                        </div>
                                    </div>

                                    {canManageInventory && (
                                        <button 
                                            onClick={() => openHistoryEdit(record)}
                                            className="absolute top-3 left-3 p-1.5 bg-gray-200 dark:bg-slate-600 rounded-md text-gray-600 dark:text-gray-300 hover:bg-white dark:hover:bg-slate-500 shadow-sm"
                                        >
                                            <Edit2 size={12} />
                                        </button>
                                    )}
                                </div>
                            ))
                        ) : (
                            <p className="text-center text-gray-400 py-4 text-sm">لا توجد عمليات شراء مسجلة لهذا المنتج</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
      )}

      {/* --- Quick Add Stock Modal --- */}
      {isQuickAddOpen && addStockProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[70] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 shadow-2xl transition-colors">
                <div className="flex justify-between items-center mb-4 border-b border-gray-100 dark:border-slate-700 pb-2">
                    <h3 className="font-bold text-lg text-gray-800 dark:text-white flex items-center">
                        <Package size={20} className="ml-2 text-emerald-600 dark:text-emerald-400" />
                        إضافة مخزون
                    </h3>
                    <button onClick={() => setIsQuickAddOpen(false)} className="bg-gray-100 dark:bg-slate-700 p-1 rounded-full"><X size={20} className="text-gray-500 dark:text-gray-300"/></button>
                </div>

                <div className="mb-4">
                     <p className="text-sm text-gray-500 dark:text-gray-400">المنتج</p>
                     <p className="font-bold text-lg text-gray-900 dark:text-white">{addStockProduct.name}</p>
                </div>
                
                <div className="space-y-3">
                    <div className="flex gap-3">
                        <div className="flex-1">
                            <label className="block text-xs font-bold text-gray-600 dark:text-gray-400 mb-1">الكمية المضافة</label>
                            <input 
                                type="number"
                                value={addStockQty}
                                onChange={(e) => setAddStockQty(e.target.value)}
                                className="w-full p-3 border border-gray-200 dark:border-slate-600 rounded-xl bg-gray-50 dark:bg-slate-700 text-center font-bold text-xl text-emerald-600 dark:text-emerald-400 outline-none focus:ring-2 focus:ring-emerald-500"
                                placeholder="0"
                                autoFocus
                            />
                        </div>
                         <div className="flex-1">
                            <label className="block text-xs font-bold text-gray-600 dark:text-gray-400 mb-1">سعر الشراء (الوحدة)</label>
                            <input 
                                type="number"
                                value={addStockBuyPrice}
                                onChange={(e) => setAddStockBuyPrice(e.target.value)}
                                className="w-full p-3 border border-gray-200 dark:border-slate-600 rounded-xl bg-gray-50 dark:bg-slate-700 text-center font-bold text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-gray-600 dark:text-gray-400 mb-1">سعر البيع (تحديث السعر الحالي)</label>
                        <input 
                            type="number"
                            value={addStockSellPrice}
                            onChange={(e) => setAddStockSellPrice(e.target.value)}
                            className="w-full p-3 border border-gray-200 dark:border-slate-600 rounded-xl bg-gray-50 dark:bg-slate-700 text-center font-bold text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
                        />
                    </div>

                    {/* Invoice Toggle */}
                    <div className="bg-gray-50 dark:bg-slate-700 p-3 rounded-xl flex items-center justify-between cursor-pointer" onClick={() => setAddStockWithInvoice(!addStockWithInvoice)}>
                        <div className="flex items-center gap-2">
                            <FileText size={18} className="text-blue-500" />
                            <span className="text-sm font-bold text-gray-700 dark:text-gray-200">إضافة فاتورة شراء؟</span>
                        </div>
                        <div className={`w-10 h-6 rounded-full p-1 transition-colors ${addStockWithInvoice ? 'bg-blue-500' : 'bg-gray-300 dark:bg-slate-600'}`}>
                            <div className={`w-4 h-4 bg-white rounded-full shadow-md transform transition-transform ${addStockWithInvoice ? '-translate-x-4' : 'translate-x-0'}`}></div>
                        </div>
                    </div>

                    {/* Invoice Details */}
                    {addStockWithInvoice && (
                        <div className="bg-blue-50 dark:bg-blue-900/10 p-3 rounded-xl border border-blue-100 dark:border-blue-900/30 space-y-3 animate-fade-in">
                            <div>
                                <label className="block text-xs font-bold text-gray-600 dark:text-gray-400 mb-1">المورد (اختياري)</label>
                                <div className="relative">
                                    <select 
                                        value={addStockSupplierId}
                                        onChange={(e) => setAddStockSupplierId(e.target.value)}
                                        className="w-full p-2 bg-white dark:bg-slate-800 border border-blue-200 dark:border-slate-600 rounded-lg outline-none text-right text-sm appearance-none"
                                        dir="rtl"
                                    >
                                        <option value="">بدون مورد (نقدي عام)</option>
                                        {contacts.filter(c => c.type === 'SUPPLIER').map(c => (
                                            <option key={c.id} value={c.id}>{c.name}</option>
                                        ))}
                                    </select>
                                    <ChevronDown className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" size={16}/>
                                </div>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-600 dark:text-gray-400 mb-1">المدفوع (اتركه فارغاً للدفع الكامل)</label>
                                <input 
                                    type="number"
                                    value={addStockPaidAmount}
                                    onChange={(e) => setAddStockPaidAmount(e.target.value)}
                                    className="w-full p-2 bg-white dark:bg-slate-800 border border-blue-200 dark:border-slate-600 rounded-lg text-center font-bold text-sm outline-none"
                                    placeholder={`الاجمالي: ${(parseFloat(addStockQty || '0') * parseFloat(addStockBuyPrice || '0')).toLocaleString()}`}
                                />
                            </div>
                        </div>
                    )}

                    <button 
                        onClick={handleQuickStockSubmit}
                        className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-lg transition-colors mt-2"
                    >
                        تأكيد وإضافة
                    </button>
                </div>
             </div>
        </div>
      )}

      {/* --- History Edit Modal --- */}
      {isHistoryEditOpen && historyEditData && (
          <div className="fixed inset-0 bg-black bg-opacity-60 z-[60] flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 shadow-xl transition-colors">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-lg text-gray-800 dark:text-white">تعديل سجل الشراء</h3>
                    <button onClick={() => setIsHistoryEditOpen(false)} className="bg-gray-100 dark:bg-slate-700 p-1 rounded-full"><X size={20} className="text-gray-500 dark:text-gray-300"/></button>
                </div>
                
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">الكمية (في الفاتورة)</label>
                        <input 
                            type="number"
                            value={historyEditData.quantity}
                            onChange={(e) => setHistoryEditData({...historyEditData, quantity: parseFloat(e.target.value)})}
                            className="w-full p-3 border border-gray-200 dark:border-slate-600 rounded-xl bg-white dark:bg-slate-700 text-gray-900 dark:text-white text-center font-bold"
                        />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                        <div>
                            <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">سعر الشراء (بالفاتورة)</label>
                            <input 
                                type="number"
                                value={historyEditData.buyPrice}
                                onChange={(e) => setHistoryEditData({...historyEditData, buyPrice: parseFloat(e.target.value)})}
                                className="w-full p-3 border border-gray-200 dark:border-slate-600 rounded-xl bg-white dark:bg-slate-700 text-gray-900 dark:text-white text-center font-bold"
                            />
                        </div>
                         <div>
                            <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">سعر البيع (بالفاتورة)</label>
                            <input 
                                type="number"
                                value={historyEditData.sellPrice}
                                onChange={(e) => setHistoryEditData({...historyEditData, sellPrice: parseFloat(e.target.value)})}
                                className="w-full p-3 border border-gray-200 dark:border-slate-600 rounded-xl bg-white dark:bg-slate-700 text-gray-900 dark:text-white text-center font-bold text-emerald-600"
                            />
                        </div>
                    </div>
                    
                    <p className="text-[10px] text-gray-400 mt-1 text-center">
                        * هذا التعديل يخص سجل هذه العملية فقط
                    </p>

                    <div className="flex gap-3 pt-2">
                        <button 
                            onClick={saveHistoryEdit}
                            className="flex-1 bg-primary text-white py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors"
                        >
                            حفظ التعديلات
                        </button>
                        <button 
                            onClick={() => setIsHistoryEditOpen(false)}
                            className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-gray-300 py-3 rounded-xl font-bold"
                        >
                            إلغاء
                        </button>
                    </div>
                </div>
            </div>
          </div>
      )}

      {/* --- Delete Confirmation Modal --- */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[60] flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 text-center shadow-xl transition-colors">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <AlertTriangle size={32} className="text-red-600 dark:text-red-500" />
                </div>
                <h3 className="font-bold text-lg text-gray-900 dark:text-white mb-2">حذف المنتج؟</h3>
                <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">
                    هل أنت متأكد من حذف هذا المنتج؟ لا يمكن التراجع عن هذا الإجراء وسيتم فقدان بيانات المخزون الخاص به.
                </p>
                <div className="flex space-x-3 space-x-reverse">
                    <button 
                        onClick={confirmDelete}
                        className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 rounded-xl font-bold transition-colors shadow-lg"
                    >
                        نعم، حذف
                    </button>
                    <button 
                        onClick={() => setShowDeleteConfirm(false)}
                        className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 py-3 rounded-xl font-bold transition-colors hover:bg-gray-200 dark:hover:bg-slate-600"
                    >
                        إلغاء
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* --- Edit Modal --- */}
      {isEditModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-800 rounded-2xl w-full max-w-md p-6 animate-fade-in max-h-[90vh] overflow-y-auto no-scrollbar transition-colors">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold dark:text-white">{editingProduct ? 'تعديل منتج' : 'منتج جديد'}</h2>
                    {editingProduct && (
                        <button 
                            type="button"
                            onClick={(e) => handleDeleteClick(editingProduct.id, e)}
                            className="text-red-500 bg-red-50 dark:bg-red-900/20 px-3 py-1 rounded-lg text-xs font-bold flex items-center"
                        >
                            <Trash2 size={14} className="ml-1"/>
                            حذف المنتج
                        </button>
                    )}
                </div>
                
                <form onSubmit={handleEditSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-300 mb-1">اسم المنتج</label>
                        <input 
                            className="w-full border dark:border-slate-600 rounded-lg p-2 focus:ring-2 ring-primary outline-none bg-white dark:bg-slate-700 text-gray-900 dark:text-white"
                            value={formData.name}
                            onChange={e => setFormData({...formData, name: e.target.value})}
                            required
                        />
                    </div>
                    {/* Price inputs removed as requested */}
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm text-gray-600 dark:text-gray-300 mb-1">الكمية الحالية</label>
                            <input 
                                type="number" 
                                className="w-full border dark:border-slate-600 rounded-lg p-2 bg-white dark:bg-slate-700 text-gray-900 dark:text-white" 
                                value={formData.stock || ''} 
                                onChange={e => setFormData({...formData, stock: Number(e.target.value)})} 
                            />
                        </div>
                         <div>
                            <label className="block text-sm text-gray-600 dark:text-gray-300 mb-1">الحد الأدنى</label>
                            <input 
                                type="number" 
                                className="w-full border dark:border-slate-600 rounded-lg p-2 bg-white dark:bg-slate-700 text-gray-900 dark:text-white" 
                                value={formData.minStock || ''} 
                                onChange={e => setFormData({...formData, minStock: Number(e.target.value)})} 
                            />
                        </div>
                    </div>
                     <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-300 mb-1">كود المنتج (اختياري)</label>
                        <input 
                            className="w-full border dark:border-slate-600 rounded-lg p-2 bg-white dark:bg-slate-700 text-gray-900 dark:text-white"
                            value={formData.code}
                            onChange={e => setFormData({...formData, code: e.target.value})}
                        />
                    </div>
                    <div className="flex space-x-3 space-x-reverse pt-4">
                        <button type="submit" className="flex-1 bg-primary text-white py-3 rounded-xl font-bold">حفظ</button>
                        <button type="button" onClick={() => setIsEditModalOpen(false)} className="flex-1 bg-gray-100 dark:bg-slate-600 text-gray-600 dark:text-gray-200 py-3 rounded-xl font-bold">إلغاء</button>
                    </div>
                </form>
            </div>
        </div>
      )}
    </div>
  );
};

export default Inventory;
