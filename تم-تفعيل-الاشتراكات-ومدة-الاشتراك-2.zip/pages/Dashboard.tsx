
import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { TrendingUp, TrendingDown, DollarSign, AlertTriangle, ShoppingBag, ShoppingCart, Wallet, Banknote, X, Check, ArrowRight, ArrowLeft, User, Phone } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { useNavigate } from 'react-router-dom';
import { TransactionType, PaymentMethod } from '../types';

const StatCard: React.FC<{ title: string; value: string; icon: React.ElementType; color: string }> = ({ title, value, icon: Icon, color }) => (
  <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700 flex items-center justify-between transition-colors">
    <div>
      <p className="text-gray-500 dark:text-gray-400 text-xs font-medium mb-1">{title}</p>
      <h3 className="text-xl font-bold text-gray-800 dark:text-white">{value}</h3>
    </div>
    <div className={`p-3 rounded-full ${color} bg-opacity-10 dark:bg-opacity-20`}>
      <Icon className={color.replace('bg-', 'text-')} size={24} />
    </div>
  </div>
);

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { getDashboardStats, transactions, contacts, addTransaction, darkMode, storeProfile, hasPermission } = useStore();
  const stats = getDashboardStats();

  // Check Permissions
  const canViewStats = hasPermission('DASHBOARD');
  const canViewSales = hasPermission('SALES');
  const canViewPurchases = hasPermission('PURCHASES');
  const canViewExpenses = hasPermission('EXPENSES');

  // Payment Modal State
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentType, setPaymentType] = useState<'CLIENT' | 'SUPPLIER'>('CLIENT');
  const [paymentContactId, setPaymentContactId] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentDate, setPaymentDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Prepare chart data (Current Week: Sat -> Fri)
  const getChartData = () => {
    const data = [];
    const today = new Date();
    const currentDay = today.getDay(); // 0=Sun ... 6=Sat
    
    // Calculate days to subtract to reach the last Saturday
    // If Sat(6) -> 0, Sun(0) -> 1, ..., Fri(5) -> 6
    const daysSinceSaturday = (currentDay + 1) % 7;
    
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - daysSinceSaturday);

    const dayNamesMap: {[key: number]: string} = {
        0: 'أحد',
        1: 'اثنين',
        2: 'ثلاثاء',
        3: 'أربعاء',
        4: 'خميس',
        5: 'جمعة',
        6: 'سبت'
    };

    for (let i = 0; i < 7; i++) {
      const d = new Date(startOfWeek);
      d.setDate(startOfWeek.getDate() + i);
      const dateStr = d.toISOString().split('T')[0];
      const dayIndex = d.getDay();
      
      const dayName = dayNamesMap[dayIndex];

      const dayTransactions = transactions.filter(t => t.date.startsWith(dateStr));
      const sales = dayTransactions.filter(t => t.type === 'SALE').reduce((sum, t) => sum + t.amount, 0);
      const expenses = dayTransactions.filter(t => t.type === 'EXPENSE').reduce((sum, t) => sum + t.amount, 0);
      const purchases = dayTransactions.filter(t => t.type === 'PURCHASE').reduce((sum, t) => sum + t.amount, 0);

      data.push({ 
          rawDate: dateStr,
          name: dayName, 
          مبيعات: sales, 
          مصروفات: expenses,
          مشتريات: purchases
      });
    }
    return data;
  };

  const chartData = getChartData();

  const handleQuickPaymentSubmit = () => {
      if (!paymentContactId || !paymentAmount) return;
      
      const amount = parseFloat(paymentAmount);
      if (isNaN(amount) || amount <= 0) return;

      addTransaction({
          id: Date.now().toString(),
          type: TransactionType.PAYMENT,
          amount: amount,
          date: new Date(paymentDate).toISOString(),
          paymentMethod: PaymentMethod.CASH,
          contactId: paymentContactId,
          notes: 'دفعة سريعة من لوحة التحكم',
          paidAmount: amount
      });

      setIsPaymentModalOpen(false);
      setPaymentAmount('');
      setPaymentContactId('');
  };

  const getContactName = (id?: string) => {
      return contacts.find(c => c.id === id)?.name || 'غير معروف';
  };

  return (
    <div className="p-4 space-y-6 pb-24 dark:text-gray-100">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-black text-gray-900 dark:text-white">{storeProfile.name}</h1>
          <p className="text-gray-500 dark:text-gray-400 text-sm">ملخص نشاط اليوم</p>
        </div>
        <div className="w-12 h-12 bg-white dark:bg-slate-700 rounded-full overflow-hidden shadow-sm border border-gray-100 dark:border-slate-600">
            {storeProfile.image ? (
                <img src={storeProfile.image} alt="Store Profile" className="w-full h-full object-cover" />
            ) : (
                <div className="w-full h-full flex items-center justify-center bg-emerald-50 dark:bg-slate-800 text-emerald-500">
                    <User size={24} />
                </div>
            )}
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {canViewSales && (
            <button 
                onClick={() => navigate('/invoices', { state: { tab: 'SALES' } })} 
                className="bg-white dark:bg-slate-800 p-3 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex flex-col items-center justify-center space-y-2 active:scale-95 transition-all"
            >
                <div className="bg-emerald-50 dark:bg-emerald-900/30 p-2 rounded-full text-emerald-600 dark:text-emerald-400">
                    <ShoppingBag size={20} />
                </div>
                <span className="font-bold text-gray-700 dark:text-gray-300 text-[10px] text-center">فواتير البيع</span>
            </button>
        )}
        {canViewPurchases && (
            <button 
                onClick={() => navigate('/invoices', { state: { tab: 'PURCHASES' } })} 
                className="bg-white dark:bg-slate-800 p-3 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex flex-col items-center justify-center space-y-2 active:scale-95 transition-all"
            >
                <div className="bg-blue-50 dark:bg-blue-900/30 p-2 rounded-full text-blue-600 dark:text-blue-400">
                    <ShoppingCart size={20} />
                </div>
                <span className="font-bold text-gray-700 dark:text-gray-300 text-[10px] text-center">فواتير الشراء</span>
            </button>
        )}
        <button 
            onClick={() => navigate('/invoices', { state: { tab: 'PAYMENTS' } })} 
            className="bg-white dark:bg-slate-800 p-3 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex flex-col items-center justify-center space-y-2 active:scale-95 transition-all"
        >
            <div className="bg-purple-50 dark:bg-purple-900/30 p-2 rounded-full text-purple-600 dark:text-purple-400">
                <Banknote size={20} />
            </div>
            <span className="font-bold text-gray-700 dark:text-gray-300 text-[10px] text-center">سجل المدفوعات</span>
        </button>
        {canViewExpenses && (
            <button 
                onClick={() => navigate('/invoices', { state: { tab: 'EXPENSES' } })} 
                className="bg-white dark:bg-slate-800 p-3 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex flex-col items-center justify-center space-y-2 active:scale-95 transition-all"
            >
                <div className="bg-red-50 dark:bg-red-900/30 p-2 rounded-full text-red-600 dark:text-red-400">
                    <TrendingDown size={20} />
                </div>
                <span className="font-bold text-gray-700 dark:text-gray-300 text-[10px] text-center">سجل المصروفات</span>
            </button>
        )}
      </div>

      {/* Primary Action Button */}
      <button 
        onClick={() => setIsPaymentModalOpen(true)}
        className="w-full bg-gradient-to-l from-purple-600 to-indigo-600 text-white p-4 rounded-xl shadow-lg flex items-center justify-between active:scale-[0.98] transition-transform"
      >
          <div className="flex items-center">
              <div className="bg-white/20 p-2 rounded-lg ml-3">
                  <Wallet size={24} className="text-white" />
              </div>
              <div className="text-right">
                  <p className="font-bold text-lg">تسجيل دفعة جديدة</p>
                  <p className="text-purple-100 text-xs">تحصيل من عميل أو سداد لمورد</p>
              </div>
          </div>
          <ArrowLeft size={20} className="text-purple-200" />
      </button>

      {/* Alerts */}
      {canViewStats && stats.lowStockCount > 0 && (
        <div className="bg-orange-50 dark:bg-orange-900/20 border-r-4 border-orange-500 p-4 rounded-lg flex items-center shadow-sm">
            <AlertTriangle className="text-orange-500 ml-3" size={24} />
            <div>
                <p className="font-bold text-orange-800 dark:text-orange-400">تنبيه المخزون</p>
                <p className="text-sm text-orange-700 dark:text-orange-300">يوجد {stats.lowStockCount} منتجات وصلت للحد الأدنى.</p>
            </div>
        </div>
      )}

      {/* Stats Grid - Only if Permission Allows */}
      {canViewStats ? (
          <div className="grid grid-cols-2 gap-4">
            <StatCard 
            title="مبيعات اليوم" 
            value={`${stats.dailySales.toLocaleString()} ج.م`} 
            icon={TrendingUp} 
            color="bg-emerald-500 text-emerald-500" 
            />
            <StatCard 
            title="مصروفات اليوم" 
            value={`${stats.dailyExpenses.toLocaleString()} ج.م`} 
            icon={TrendingDown} 
            color="bg-red-500 text-red-500" 
            />
            <StatCard 
            title="مشتريات اليوم" 
            value={`${stats.dailyPurchases.toLocaleString()} ج.م`} 
            icon={ShoppingCart} 
            color="bg-blue-500 text-blue-500" 
            />
            <StatCard 
            title="صافي ربح اليوم" 
            value={`${stats.dailyProfit.toLocaleString()} ج.م`} 
            icon={DollarSign} 
            color="bg-purple-500 text-purple-500" 
            />
        </div>
      ) : (
          <div className="bg-gray-100 dark:bg-slate-800 p-8 rounded-2xl text-center text-gray-400">
              <AlertTriangle className="mx-auto mb-2 opacity-30" size={32} />
              <p className="text-sm">لا تملك صلاحية لعرض الإحصائيات المالية</p>
          </div>
      )}

      {/* Chart - Only if Permission Allows */}
      {canViewStats && (
        <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700">
            <h3 className="font-bold text-gray-800 dark:text-white mb-4">أداء الأسبوع الحالي</h3>
            <div className="h-64 w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkMode ? '#334155' : '#e5e7eb'} />
                <XAxis 
                    dataKey="name" 
                    tick={{fontSize: 10, fill: darkMode ? '#94a3b8' : '#6b7280'}} 
                    axisLine={false}
                    tickLine={false}
                    dy={10}
                />
                <YAxis 
                    tick={{fontSize: 10, fill: darkMode ? '#94a3b8' : '#6b7280'}} 
                    axisLine={false}
                    tickLine={false}
                />
                <Tooltip 
                    cursor={{fill: darkMode ? '#334155' : '#f3f4f6'}}
                    content={({ active, payload, label }) => {
                        if (active && payload && payload.length) {
                        return (
                            <div className="bg-white dark:bg-slate-800 p-3 border border-gray-100 dark:border-slate-600 shadow-xl rounded-xl text-right" dir="rtl">
                                <p className="font-bold text-gray-800 dark:text-white text-sm mb-2">{label}</p>
                                <div className="flex items-center justify-between space-x-3 space-x-reverse text-xs mb-1">
                                    <span className="text-emerald-600 dark:text-emerald-400">مبيعات:</span>
                                    <span className="font-bold text-gray-700 dark:text-gray-300">{Number(payload[0].value).toLocaleString()}</span>
                                </div>
                                <div className="flex items-center justify-between space-x-3 space-x-reverse text-xs mb-1">
                                    <span className="text-blue-600 dark:text-blue-400">مشتريات:</span>
                                    <span className="font-bold text-gray-700 dark:text-gray-300">{Number(payload[1].value).toLocaleString()}</span>
                                </div>
                                <div className="flex items-center justify-between space-x-3 space-x-reverse text-xs">
                                    <span className="text-red-600 dark:text-red-400">مصروفات:</span>
                                    <span className="font-bold text-gray-700 dark:text-gray-300">{Number(payload[2].value).toLocaleString()}</span>
                                </div>
                            </div>
                        );
                        }
                        return null;
                    }}
                />
                <Legend />
                <Bar dataKey="مبيعات" fill="#10b981" radius={[4, 4, 0, 0]} maxBarSize={30} />
                <Bar dataKey="مشتريات" fill="#3b82f6" radius={[4, 4, 0, 0]} maxBarSize={30} />
                <Bar dataKey="مصروفات" fill="#ef4444" radius={[4, 4, 0, 0]} maxBarSize={30} />
                </BarChart>
            </ResponsiveContainer>
            </div>
        </div>
      )}

      {/* Recent Transactions */}
      <div>
        <div className="flex justify-between items-center mb-3">
            <h3 className="font-bold text-gray-800 dark:text-white">آخر العمليات</h3>
        </div>
        <div className="space-y-3">
            {transactions.slice(0, 5).map((t) => (
                <div key={t.id} className="bg-white dark:bg-slate-800 p-3 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex justify-between items-center transition-colors">
                    <div className="flex items-center">
                        <div className={`p-2 rounded-full ${
                            t.type === 'SALE' ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' : 
                            t.type === 'EXPENSE' ? 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400' : 
                            t.type === 'PURCHASE' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400' :
                            'bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400'
                        }`}>
                            {t.type === 'SALE' ? <TrendingUp size={18}/> : 
                             t.type === 'EXPENSE' ? <TrendingDown size={18}/> : 
                             t.type === 'PURCHASE' ? <DollarSign size={18}/> :
                             <Wallet size={18}/>}
                        </div>
                        <div className="mr-3">
                            <p className="font-bold text-sm text-gray-800 dark:text-gray-200">
                                {t.type === 'SALE' ? 'عملية بيع' : 
                                 t.type === 'EXPENSE' ? 'مصروف' : 
                                 t.type === 'PURCHASE' ? 'شراء بضاعة' :
                                 'دفعة نقدية'}
                            </p>
                            <div className="flex flex-col">
                                <span className="text-xs text-gray-500 dark:text-gray-400">
                                    {t.type === 'PAYMENT' ? getContactName(t.contactId) : 
                                    new Date(t.date).toLocaleTimeString('ar-EG', {hour: '2-digit', minute:'2-digit'})}
                                </span>
                                {t.createdBy && (
                                    <span className="text-[10px] text-gray-400 mt-0.5 flex items-center">
                                        <User size={10} className="ml-1"/>
                                        {t.createdBy.name} 
                                        <span className="mr-1 text-[9px]">({t.createdBy.phone})</span>
                                    </span>
                                )}
                            </div>
                        </div>
                    </div>
                    {canViewStats && (
                        <span className={`font-bold ${
                            t.type === 'SALE' ? 'text-emerald-600 dark:text-emerald-400' : 
                            t.type === 'EXPENSE' ? 'text-red-600 dark:text-red-400' : 
                            t.type === 'PURCHASE' ? 'text-blue-600 dark:text-blue-400' :
                            'text-purple-600 dark:text-purple-400'
                        }`}>
                            {t.type === 'SALE' || t.type === 'PAYMENT' ? '+' : '-'} {t.amount.toLocaleString()}
                        </span>
                    )}
                </div>
            ))}
            {transactions.length === 0 && (
                <div className="text-center text-gray-400 py-8 text-sm">لا توجد عمليات مسجلة اليوم</div>
            )}
        </div>
      </div>

      {/* --- Quick Payment Modal --- */}
      {isPaymentModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[60] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 shadow-2xl transition-colors">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-lg text-gray-800 dark:text-white">تسجيل دفعة سريعة</h3>
                    <button onClick={() => setIsPaymentModalOpen(false)} className="bg-gray-100 dark:bg-slate-700 p-1 rounded-full"><X size={20} className="text-gray-500 dark:text-gray-300"/></button>
                </div>
                
                <div className="space-y-4">
                    {/* Type Selector */}
                    <div className="flex bg-gray-100 dark:bg-slate-700 p-1 rounded-lg">
                        <button 
                            className={`flex-1 py-2 text-sm font-bold rounded-md transition-all ${paymentType === 'CLIENT' ? 'bg-white dark:bg-slate-600 text-purple-600 dark:text-purple-400 shadow-sm' : 'text-gray-500 dark:text-gray-400'}`}
                            onClick={() => { setPaymentType('CLIENT'); setPaymentContactId(''); }}
                        >
                            تحصيل من عميل
                        </button>
                        <button 
                            className={`flex-1 py-2 text-sm font-bold rounded-md transition-all ${paymentType === 'SUPPLIER' ? 'bg-white dark:bg-slate-600 text-purple-600 dark:text-purple-400 shadow-sm' : 'text-gray-500 dark:text-gray-400'}`}
                            onClick={() => { setPaymentType('SUPPLIER'); setPaymentContactId(''); }}
                        >
                            سداد لمورد
                        </button>
                    </div>

                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">
                            {paymentType === 'CLIENT' ? 'اسم العميل' : 'اسم المورد'}
                        </label>
                        <div className="relative">
                            <select 
                                value={paymentContactId}
                                onChange={(e) => setPaymentContactId(e.target.value)}
                                className="w-full p-3 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl outline-none focus:ring-2 focus:ring-purple-500 text-right appearance-none font-bold text-gray-700 dark:text-white"
                                dir="rtl"
                            >
                                <option value="">اختر الاسم...</option>
                                {contacts
                                    .filter(c => c.type === paymentType)
                                    .map(c => (
                                        <option key={c.id} value={c.id}>{c.name}</option>
                                ))}
                            </select>
                            <ArrowLeft className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none rotate-90" size={16}/>
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">المبلغ</label>
                        <input 
                            type="number"
                            value={paymentAmount}
                            onChange={(e) => setPaymentAmount(e.target.value)}
                            className="w-full p-3 border border-gray-300 dark:border-slate-600 bg-white dark:bg-slate-700 rounded-lg font-bold text-center text-xl text-purple-600 dark:text-purple-400 outline-none focus:ring-2 focus:ring-purple-500"
                            placeholder="0"
                        />
                    </div>
                    
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">التاريخ</label>
                        <input 
                             type="date"
                             value={paymentDate}
                             onChange={(e) => setPaymentDate(e.target.value)}
                             className="w-full p-3 border border-gray-300 dark:border-slate-600 rounded-lg text-center bg-gray-50 dark:bg-slate-700 text-gray-900 dark:text-white"
                             style={{ colorScheme: darkMode ? 'dark' : 'light' }}
                        />
                    </div>

                    <button 
                        onClick={handleQuickPaymentSubmit}
                        disabled={!paymentContactId || !paymentAmount}
                        className={`w-full py-3 rounded-xl font-bold text-white shadow-lg transition-colors ${
                            !paymentContactId || !paymentAmount ? 'bg-gray-300 dark:bg-slate-600 cursor-not-allowed' : 'bg-purple-600 hover:bg-purple-700'
                        }`}
                    >
                        حفظ العملية
                    </button>
                </div>
             </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
