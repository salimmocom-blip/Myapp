
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useStore } from '../context/StoreContext';
import { TransactionType, PaymentMethod, TransactionItem, Transaction, Product } from '../types';
import { Save, Plus, Trash2, Search, ScanBarcode, ArrowRight, MoreVertical, Minus, Calendar, User as UserIcon, CreditCard, FileText, Clock, ChevronDown, ArrowLeft, X, Check, Package, ShoppingCart, AlertCircle, Tag, RefreshCw } from 'lucide-react';

const AddTransaction: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { addTransaction, updateTransaction, addContact, addProduct, updateProduct, products, contacts, darkMode, hasPermission } = useStore();
  
  // Check Permissions
  const canSell = hasPermission('SALES');
  const canBuy = hasPermission('PURCHASES');
  const canExpense = hasPermission('EXPENSES');

  // Determine available types
  const availableTypes = [
      { id: TransactionType.SALE, label: 'بيع', color: 'emerald', allowed: canSell },
      { id: TransactionType.PURCHASE, label: 'شراء', color: 'cyan', allowed: canBuy },
      { id: TransactionType.EXPENSE, label: 'مصروف', color: 'red', allowed: canExpense },
  ].filter(t => t.allowed);

  // Check for Edit Mode
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);

  // Initial Type Logic
  const [type, setType] = useState<TransactionType>(() => {
      if (location.state?.editTransaction) return location.state.editTransaction.type;
      if (location.state?.initialType) {
          const requested = location.state.initialType;
          if (requested === TransactionType.SALE && canSell) return TransactionType.SALE;
          if (requested === TransactionType.PURCHASE && canBuy) return TransactionType.PURCHASE;
          if (requested === TransactionType.EXPENSE && canExpense) return TransactionType.EXPENSE;
      }
      return availableTypes.length > 0 ? availableTypes[0].id : TransactionType.SALE;
  });

  const [step, setStep] = useState<'CART' | 'CHECKOUT'>('CART');
  const [cart, setCart] = useState<TransactionItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [expenseAmount, setExpenseAmount] = useState<string>('');

  // Checkout Fields
  const [date, setDate] = useState(() => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  });
  const [contactId, setContactId] = useState<string>('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(PaymentMethod.CASH);
  const [discount, setDiscount] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<string>('');

  // Quick Add Contact State
  const [isAddingContact, setIsAddingContact] = useState(false);
  const [newContactName, setNewContactName] = useState('');

  // Quick Add Product State
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [newProductData, setNewProductData] = useState({ name: '' });

  // --- Add Product Quantity/Price Modal State ---
  const [productToAdd, setProductToAdd] = useState<Product | null>(null);
  const [addQty, setAddQty] = useState<string>('1');
  const [addPrice, setAddPrice] = useState<string>(''); 
  const [addBatchSellPrice, setAddBatchSellPrice] = useState<string>(''); // Only for batch sell price record (not store update)
  
  const qtyInputRef = useRef<HTMLInputElement>(null);

  // --- Load Data for Edit Mode ---
  useEffect(() => {
    if (location.state?.editTransaction) {
        const tx: Transaction = location.state.editTransaction;
        if (
            (tx.type === TransactionType.SALE && !canSell) ||
            (tx.type === TransactionType.PURCHASE && !canBuy) ||
            (tx.type === TransactionType.EXPENSE && !canExpense)
        ) {
            alert('ليس لديك صلاحية لتعديل هذا النوع من العمليات');
            navigate('/');
            return;
        }

        setEditingTx(tx);
        setType(tx.type);
        setDate(tx.date.split('T')[0]); 
        setNotes(tx.notes || '');
        setContactId(tx.contactId || '');
        setPaymentMethod(tx.paymentMethod);
        setDiscount(tx.discount || 0);
        setPaidAmount(tx.paidAmount !== undefined ? tx.paidAmount.toString() : tx.amount.toString());
        
        if (tx.type === TransactionType.EXPENSE) {
            setExpenseAmount(tx.amount.toString());
        } else if (tx.items) {
            setCart(tx.items);
        }

        if (location.state.jumpToCheckout) {
            setStep('CHECKOUT');
        }
    }
  }, [location.state, canSell, canBuy, canExpense, navigate]);

  // Safety Fallback
  useEffect(() => {
      if (availableTypes.length === 0) return; 
      const isAllowed = availableTypes.some(t => t.id === type);
      if (!isAllowed) {
          setType(availableTypes[0].id);
      }
  }, [availableTypes, type]);

  useEffect(() => {
      if (productToAdd && qtyInputRef.current) {
          qtyInputRef.current.focus();
          qtyInputRef.current.select();
      }
  }, [productToAdd]);

  const handleTypeChange = (newType: TransactionType) => {
    if (editingTx && newType !== editingTx.type) {
        if(!confirm('تغيير النوع سيقوم بمسح البيانات الحالية. هل أنت متأكد؟')) return;
        setEditingTx(null);
        setCart([]);
        setExpenseAmount('');
        setContactId('');
        setNotes('');
    }
    setType(newType);
  };

  // --- Cart Logic ---
  
  const initiateAddProduct = (product: Product) => {
      setProductToAdd(product);
      setAddQty('1');
      // No default price filling as requested
      setAddPrice('');
      setAddBatchSellPrice('');
      setSearchQuery('');
  };

  const confirmAddProduct = () => {
      if (!productToAdd) return;
      
      const qty = parseFloat(addQty) || 1;
      const price = parseFloat(addPrice) || 0;
      let sellPriceForBatch: number | undefined = undefined;

      if (type === TransactionType.PURCHASE) {
          sellPriceForBatch = parseFloat(addBatchSellPrice);
          if (isNaN(sellPriceForBatch)) sellPriceForBatch = undefined;
      }

      setCart(prev => {
        const existing = prev.find(item => item.productId === productToAdd.id);
        
        if (existing) {
          return prev.map(item => 
            item.productId === productToAdd.id 
              ? { 
                  ...item, 
                  quantity: item.quantity + qty, 
                  price: price,
                  sellPrice: sellPriceForBatch
                } 
              : item
          );
        }
        return [...prev, { 
            productId: productToAdd.id, 
            productName: productToAdd.name, 
            price: price, 
            quantity: qty,
            sellPrice: sellPriceForBatch
        }];
      });

      setProductToAdd(null);
      setSearchQuery('');
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.productId === productId) {
        return { ...item, quantity: Math.max(1, item.quantity + delta) };
      }
      return item;
    }));
  };

  const setExactQuantity = (productId: string, newQty: number) => {
    setCart(prev => prev.map(item => {
      if (item.productId === productId) {
        return { ...item, quantity: newQty >= 0 ? newQty : 0 };
      }
      return item;
    }));
  };

  const updateItemPrice = (productId: string, newPrice: number) => {
      setCart(prev => prev.map(item => {
          if (item.productId === productId) {
              return { ...item, price: newPrice };
          }
          return item;
      }));
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.productId !== productId));
  };

  // --- Quick Add Product Logic ---
  const handleQuickAddProduct = () => {
    if (!hasPermission('INVENTORY')) {
        alert('عذراً، ليس لديك صلاحية لإضافة منتجات جديدة للمخزن.');
        return;
    }

    if (!newProductData.name) return;
    const nameToCheck = newProductData.name.trim();

    const isDuplicate = products.some(p => p.name.trim() === nameToCheck);
    if (isDuplicate) {
        alert('هذا المنتج موجود بالفعل في المخزن! الرجاء إضافته مباشرة من البحث.');
        return;
    }

    const newProduct = {
        id: Date.now().toString(),
        name: nameToCheck,
        buyPrice: 0,
        sellPrice: 0,
        stock: 0,
        minStock: 5,
        code: ''
    };

    const success = addProduct(newProduct);
    if (success) {
        initiateAddProduct(newProduct); 
        setIsAddingProduct(false);
        setNewProductData({ name: '' });
    }
  };

  // --- Calculation Logic ---
  const getSubTotal = () => {
    if (type === TransactionType.SALE || type === TransactionType.PURCHASE) {
      return cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    }
    return parseFloat(expenseAmount) || 0;
  };

  const getFinalTotal = () => {
    const sub = getSubTotal();
    return Math.max(0, sub - discount);
  };

  const getRemaining = () => {
    const total = getFinalTotal();
    const paid = paidAmount === '' ? total : parseFloat(paidAmount);
    return Math.max(0, total - paid); 
  };

  // --- Handlers ---
  const handleProceedToCheckout = () => {
     if (type === TransactionType.EXPENSE) {
         if (getSubTotal() <= 0) { alert('ادخل المبلغ'); return; }
         handleFinalSave(); 
         return;
     }

     if (cart.length === 0) {
         alert('اختر منتجات أولاً');
         return;
     }
     if (paidAmount === '') {
         setPaidAmount(cart.reduce((sum, item) => sum + (item.price * item.quantity), 0).toString());
     }
     setStep('CHECKOUT');
  };

  const handleQuickAddContact = () => {
    const canAddBasedOnType = (type === TransactionType.PURCHASE && canBuy) || (type === TransactionType.SALE && canSell);

    if (!hasPermission('CONTACTS') && !canAddBasedOnType) {
        alert('ليس لديك صلاحية لإضافة عملاء/موردين جدد');
        return;
    }

    if (!newContactName.trim()) return;
    
    const newId = Date.now().toString();
    const newContact = {
        id: newId,
        name: newContactName,
        type: type === TransactionType.PURCHASE ? 'SUPPLIER' : 'CLIENT',
        phone: '',
        balance: 0
    } as any; 

    const success = addContact(newContact);
    if (success) {
        setContactId(newId);
        setIsAddingContact(false);
        setNewContactName('');
    }
  };

  const handleFinalSave = () => {
    const totalAmount = getFinalTotal(); 
    const paidVal = paidAmount === '' ? totalAmount : parseFloat(paidAmount);
    const remaining = totalAmount - paidVal;

    if (remaining > 0 && !contactId && (type === TransactionType.SALE || type === TransactionType.PURCHASE)) {
        alert('يوجد مبلغ متبقي، الرجاء اختيار ' + (type === TransactionType.SALE ? 'عميل' : 'مورد') + ' لحفظ المديونية');
        return;
    }

    const [y, m, d] = date.split('-').map(Number);
    const now = new Date();
    let hours = now.getHours();
    let minutes = now.getMinutes();
    let seconds = now.getSeconds();

    if (editingTx) {
       const oldDate = new Date(editingTx.date);
       hours = oldDate.getHours();
       minutes = oldDate.getMinutes();
       seconds = oldDate.getSeconds();
    }
    
    const txnDate = new Date(y, m - 1, d, hours, minutes, seconds);

    let history = editingTx?.paymentHistory || [];
    if (!editingTx && paidVal > 0) {
        history = [{
            id: Date.now().toString(),
            date: txnDate.toISOString(),
            amount: paidVal,
            note: 'دفعة أولية عند الإنشاء'
        }];
    }

    const transactionData: Transaction = {
      id: editingTx ? editingTx.id : Date.now().toString(),
      type,
      amount: totalAmount,
      date: txnDate.toISOString(),
      paymentMethod, 
      contactId: contactId || undefined,
      notes,
      items: (type === TransactionType.SALE || type === TransactionType.PURCHASE) ? cart : undefined,
      discount: discount > 0 ? discount : undefined,
      paidAmount: paidVal,
      paymentHistory: history
    };

    if (editingTx) {
        updateTransaction(editingTx.id, transactionData);
        navigate('/invoices');
    } else {
        const success = addTransaction(transactionData);
        if (success) {
            navigate('/');
        }
    }
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.code?.includes(searchQuery)
  );

  const isCartEnabled = type === TransactionType.SALE || type === TransactionType.PURCHASE;

  if (availableTypes.length === 0) {
      return (
          <div className="min-h-screen bg-gray-50 dark:bg-slate-900 flex flex-col items-center justify-center p-6 text-center">
              <div className="bg-red-100 dark:bg-red-900/30 p-4 rounded-full mb-4">
                  <AlertCircle size={40} className="text-red-500" />
              </div>
              <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-2">عذراً، لا تملك صلاحيات</h2>
              <button 
                onClick={() => navigate('/')}
                className="bg-primary text-white px-6 py-3 rounded-xl font-bold"
              >
                  العودة للرئيسية
              </button>
          </div>
      );
  }

  // --- Render Checkout Overlay ---
  if (step === 'CHECKOUT') {
      const total = getFinalTotal();
      const remaining = getRemaining();
      const canAddNewContact = hasPermission('CONTACTS') || (type === TransactionType.PURCHASE && canBuy) || (type === TransactionType.SALE && canSell);

      return (
        <div className="min-h-screen bg-white dark:bg-slate-900 pb-20 relative transition-colors">
            <div className="p-4 flex items-center border-b border-gray-100 dark:border-slate-800 sticky top-0 bg-white dark:bg-slate-900 z-10 shadow-sm">
                <button onClick={() => setStep('CART')} className="p-2 text-gray-600 dark:text-gray-300">
                    <ArrowRight size={24} />
                </button>
                <h1 className="text-xl font-bold text-gray-800 dark:text-white mr-2 flex-1 text-center">
                    {editingTx ? 'تعديل الفاتورة' : 'حفظ الفاتورة'}
                </h1>
                <div className="w-10"></div> 
            </div>

            <div className="p-6 space-y-6">
                <div>
                    <div className="flex justify-between items-center mb-2">
                        <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">
                            {type === TransactionType.PURCHASE ? 'اسم المورد' : 'اسم العميل'}
                        </label>
                        {!isAddingContact && canAddNewContact && (
                            <button 
                                onClick={() => setIsAddingContact(true)}
                                className="text-xs text-[#006d77] dark:text-emerald-400 font-bold flex items-center bg-emerald-50 dark:bg-emerald-900/30 px-2 py-1 rounded-md"
                            >
                                <Plus size={14} className="ml-1" />
                                إضافة جديد
                            </button>
                        )}
                    </div>
                    
                    {isAddingContact ? (
                        <div className="flex items-center space-x-2 space-x-reverse">
                            <input 
                                type="text"
                                value={newContactName}
                                onChange={(e) => setNewContactName(e.target.value)}
                                className="flex-1 p-3 bg-white dark:bg-slate-800 border border-[#006d77] dark:border-emerald-500 rounded-xl text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-[#006d77]"
                                placeholder={`أدخل اسم ${type === TransactionType.PURCHASE ? 'المورد' : 'العميل'} الجديد`}
                                autoFocus
                            />
                            <button 
                                onClick={handleQuickAddContact}
                                className="p-3 bg-[#006d77] text-white rounded-xl shadow-md"
                            >
                                <Check size={20} />
                            </button>
                            <button 
                                onClick={() => setIsAddingContact(false)}
                                className="p-3 bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-gray-300 rounded-xl"
                            >
                                <X size={20} />
                            </button>
                        </div>
                    ) : (
                        <div className="relative">
                            <select 
                                value={contactId}
                                onChange={(e) => setContactId(e.target.value)}
                                className="w-full p-4 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-[#006d77] text-right appearance-none text-gray-800 dark:text-white font-medium"
                                dir="rtl"
                            >
                                <option value="">بدون {type === TransactionType.PURCHASE ? 'مورد' : 'عميل'}</option>
                                {contacts
                                    .filter(c => type === TransactionType.PURCHASE ? c.type === 'SUPPLIER' : c.type === 'CLIENT')
                                    .map(c => (
                                        <option key={c.id} value={c.id}>{c.name}</option>
                                ))}
                            </select>
                            <ChevronDown className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" size={20}/>
                        </div>
                    )}
                </div>

                <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-2xl p-4 space-y-4 shadow-sm">
                    <div className="flex items-center justify-between border-b border-gray-100 dark:border-slate-700 pb-3">
                         <label className="text-gray-600 dark:text-gray-300 font-medium w-1/3">الخصم</label>
                         <div className="flex items-center w-2/3 bg-gray-50 dark:bg-slate-700 rounded-lg px-3">
                            <span className="text-gray-500 font-bold">%</span> 
                            <input 
                                type="number" 
                                value={discount === 0 ? '' : discount}
                                onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)}
                                className="w-full bg-transparent p-2 text-center font-bold text-gray-900 dark:text-white outline-none"
                                placeholder="0"
                            />
                         </div>
                    </div>

                    <div className="flex items-center justify-between border-b border-gray-100 dark:border-slate-700 pb-3">
                         <span className="text-gray-600 dark:text-gray-300 font-medium">اجمالي الفاتورة</span>
                         <span className="text-xl font-bold text-gray-800 dark:text-white">{total.toLocaleString()}</span>
                    </div>

                    <div className="flex items-center justify-between border-b border-gray-100 dark:border-slate-700 pb-3">
                         <label className="text-gray-600 dark:text-gray-300 font-medium w-1/3">المبلغ المدفوع</label>
                         <div className="w-2/3">
                            <input 
                                type="number" 
                                value={paidAmount}
                                onChange={(e) => setPaidAmount(e.target.value)}
                                className="w-full bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-lg p-2 text-center font-bold text-[#006d77] dark:text-emerald-400 outline-none focus:border-[#006d77]"
                                placeholder={total.toString()}
                            />
                         </div>
                    </div>

                    <div className="flex items-center justify-between">
                         <span className="text-gray-600 dark:text-gray-300 font-medium">المبلغ المتبقي</span>
                         <span className={`text-xl font-bold ${remaining > 0 ? 'text-red-600 dark:text-red-400' : 'text-gray-800 dark:text-gray-200'}`}>
                             {remaining.toLocaleString()}
                         </span>
                    </div>
                </div>

                <div className="flex items-center bg-gray-50 dark:bg-slate-800 p-4 rounded-xl border border-gray-200 dark:border-slate-700">
                    <Calendar className="text-gray-500 ml-3" size={20}/>
                    <input 
                        type="date" 
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="bg-transparent outline-none text-gray-900 dark:text-white font-medium flex-1"
                        style={{ colorScheme: darkMode ? 'dark' : 'light' }}
                    />
                </div>

                <div className="w-full">
                    <label className="flex items-center text-[#006d77] dark:text-emerald-400 font-bold mb-2">
                        <Plus size={20} className="ml-2" />
                        ملاحظات
                    </label>
                    <textarea 
                        placeholder="ملاحظات الفاتورة..."
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        className="w-full bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl p-3 text-gray-900 dark:text-white outline-none resize-none h-24"
                    />
                </div>
            </div>

            <div className="fixed bottom-0 left-0 right-0 p-4 bg-white dark:bg-slate-900 border-t border-gray-200 dark:border-slate-800">
                <button 
                    onClick={handleFinalSave}
                    className="w-full bg-[#006d77] text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:bg-[#005c66] transition-colors"
                >
                    {editingTx ? 'حفظ التعديلات' : 'حفظ'}
                </button>
            </div>
        </div>
      );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900 relative pb-32 transition-colors">
      <div className="flex items-center justify-between p-4 bg-white dark:bg-slate-900 sticky top-0 z-10">
        <button className="p-2 text-gray-600 dark:text-gray-300"><MoreVertical size={24} /></button>
        <div className="flex items-center">
             <h1 className="text-xl font-bold text-gray-800 dark:text-white ml-3">
                {editingTx ? 'تعديل الفاتورة' : (type === TransactionType.SALE ? 'فاتورة بيع' : type === TransactionType.PURCHASE ? 'فاتورة شراء' : 'تسجيل مصروف')}
             </h1>
             <button onClick={() => navigate(-1)} className="p-2 text-gray-600 dark:text-gray-300"><ArrowRight size={24} /></button>
        </div>
      </div>

      <div className="px-4">
          <div className={`flex justify-center mb-4 space-x-2 space-x-reverse ${editingTx ? 'opacity-50 pointer-events-none' : ''}`}>
            {availableTypes.map((t) => (
                <button
                key={t.id}
                onClick={() => handleTypeChange(t.id)}
                className={`px-4 py-1 rounded-full text-sm font-medium transition-all border ${
                    type === t.id 
                    ? `bg-${t.color}-50 dark:bg-${t.color}-900/40 border-${t.color}-500 text-${t.color}-700 dark:text-${t.color}-400` 
                    : `bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-600 text-gray-500 dark:text-gray-400`
                }`}
                >
                {t.label}
                </button>
            ))}
          </div>

          {isCartEnabled ? (
              <div className="flex items-center space-x-2 space-x-reverse mb-6">
                  <button className="bg-[#006d77] text-white p-3 rounded-xl shadow-md flex-shrink-0"><ScanBarcode size={24} /></button>
                  
                  <div className="flex-1 relative">
                      <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                      <input 
                          type="text"
                          placeholder="اضف اسم منتج..."
                          className="w-full py-3 pr-10 pl-4 border border-gray-200 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 text-gray-900 dark:text-white text-right focus:ring-2 focus:ring-[#006d77]/20 outline-none"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                      />
                      {searchQuery && (
                          <div className="absolute w-full bg-white dark:bg-slate-800 shadow-xl border border-gray-100 dark:border-slate-700 rounded-xl mt-1 z-20 max-h-60 overflow-y-auto">
                                {filteredProducts.map(p => (
                                    <div key={p.id} onClick={() => initiateAddProduct(p)} className="p-3 border-b border-gray-50 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700 cursor-pointer flex justify-between items-center">
                                        <span className="font-medium text-gray-800 dark:text-gray-200">{p.name}</span>
                                    </div>
                                ))}
                                {filteredProducts.length === 0 && (
                                    <div 
                                        onClick={() => {
                                            setNewProductData({ name: searchQuery });
                                            setIsAddingProduct(true);
                                        }}
                                        className="p-4 text-center cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
                                    >
                                        <p className="text-gray-400 text-sm mb-2">لا يوجد منتج بهذا الاسم</p>
                                        <div className="flex items-center justify-center text-[#006d77] dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-900/30 py-2 rounded-lg">
                                            <Plus size={16} className="ml-2"/>
                                            إضافة "{searchQuery}" للمخزن
                                        </div>
                                    </div>
                                )}
                          </div>
                      )}
                  </div>

                   {hasPermission('INVENTORY') && (
                        <button 
                                onClick={() => {
                                    setNewProductData({ name: searchQuery });
                                    setIsAddingProduct(true);
                                }}
                                className="bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-900 p-3 rounded-xl shadow-sm flex-shrink-0 hover:bg-emerald-100 transition-colors"
                                title="إضافة منتج جديد"
                        >
                            <Plus size={24} />
                        </button>
                   )}
              </div>
          ) : (
               <div className="mb-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">قيمة المصروف</label>
                        <input
                            type="number"
                            value={expenseAmount}
                            onChange={(e) => setExpenseAmount(e.target.value)}
                            className="w-full p-4 text-2xl font-bold border border-gray-200 dark:border-slate-700 rounded-xl text-center text-red-600 dark:text-red-400 outline-none focus:ring-2 focus:ring-red-100 bg-white dark:bg-slate-800"
                            placeholder="0.00"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">بيان المصروف (النوع)</label>
                        <input
                            type="text"
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                            className="w-full p-4 border border-gray-200 dark:border-slate-700 rounded-xl text-gray-900 dark:text-white text-right outline-none focus:ring-2 focus:ring-red-100 bg-white dark:bg-slate-800"
                            placeholder="مثال: إيجار، رواتب، كهرباء، صيانة..."
                        />
                    </div>
               </div>
          )}

          {isCartEnabled && (
              <div className="space-y-6 pb-8">
                  {cart.length > 0 && (
                    <div className="flex justify-between items-center pb-2 mb-2 border-b-2 border-[#006d77]">
                        <span className="text-sm text-gray-600 dark:text-gray-400 font-medium w-1/4 text-center">الاجمالي</span>
                        <span className="text-sm text-gray-600 dark:text-gray-400 font-medium w-1/4 text-center">السعر</span>
                        <span className="text-sm text-gray-600 dark:text-gray-400 font-medium w-1/3 text-center">الكمية</span>
                    </div>
                  )}
                  {cart.map(item => (
                        <div key={item.productId} className="flex flex-col">
                            <div className="flex justify-between items-center mb-2">
                                <div>
                                    <h3 className="font-bold text-gray-800 dark:text-white text-right">{item.productName}</h3>
                                    {type === TransactionType.PURCHASE && item.sellPrice && (
                                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 flex items-center mt-0.5">
                                            <Tag size={10} className="ml-1"/>
                                            سعر البيع لهذه الفاتورة: {item.sellPrice}
                                        </span>
                                    )}
                                </div>
                                <button onClick={() => removeFromCart(item.productId)} className="text-red-400 p-1"><Trash2 size={16} /></button>
                            </div>
                            <div className="flex justify-between items-center">
                                <div className="w-1/4 text-center font-bold text-gray-900 dark:text-gray-200 text-lg">{(item.price * item.quantity).toLocaleString()}</div>
                                <div className="w-1/4 flex justify-center">
                                    <span className="font-medium text-gray-800 dark:text-gray-300">{item.price}</span>
                                </div>
                                <div className="w-1/3 flex justify-center">
                                    <div className="flex items-center border border-gray-300 dark:border-slate-600 rounded-full px-2 py-1 bg-white dark:bg-slate-800 shadow-sm">
                                        <button onClick={() => updateQuantity(item.productId, -1)} className="w-8 h-8 flex items-center justify-center text-gray-600 dark:text-gray-300"><Minus size={16} /></button>
                                        <input 
                                            type="number"
                                            value={item.quantity === 0 ? '' : item.quantity}
                                            onChange={(e) => setExactQuantity(item.productId, parseFloat(e.target.value) || 0)}
                                            className="w-12 text-center font-bold text-gray-800 dark:text-white outline-none bg-transparent appearance-none"
                                        />
                                        <button onClick={() => updateQuantity(item.productId, 1)} className="w-8 h-8 flex items-center justify-center text-gray-600 dark:text-gray-300"><Plus size={16} /></button>
                                    </div>
                                </div>
                            </div>
                            <div className="w-full h-px bg-gray-100 dark:bg-slate-800 mt-4"></div>
                        </div>
                  ))}
                  {cart.length === 0 && <div className="text-center py-10 text-gray-400">ابدأ بإضافة منتجات</div>}
              </div>
          )}
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] p-4 z-50 flex justify-between items-center border-t border-gray-100 dark:border-slate-800">
          <button
            onClick={handleProceedToCheckout}
            className={`px-10 py-3 rounded-xl text-white font-bold text-lg shadow-lg transition-transform active:scale-95 ${type === TransactionType.EXPENSE ? 'bg-red-600' : 'bg-[#006d77]'}`}
          >
            {type === TransactionType.EXPENSE ? 'حفظ المصروف' : 'حفظ / دفع'}
          </button>
          <div className="text-left">
             <span className="block text-xs text-gray-500 dark:text-gray-400 font-medium">اجمالي الفاتورة</span>
             <span className="block text-2xl font-bold text-gray-800 dark:text-white">{getSubTotal().toLocaleString()} <span className="text-sm font-normal">ج.م</span></span>
          </div>
      </div>

      {productToAdd && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[70] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 shadow-2xl transition-colors">
                <div className="flex justify-between items-center mb-4 border-b border-gray-100 dark:border-slate-700 pb-2">
                    <h3 className="font-bold text-lg text-gray-800 dark:text-white flex items-center">
                        <ShoppingCart size={20} className="ml-2 text-[#006d77] dark:text-emerald-400" />
                        إضافة للمنتجات
                    </h3>
                    <button onClick={() => setProductToAdd(null)} className="bg-gray-100 dark:bg-slate-700 p-1 rounded-full"><X size={20} className="text-gray-500 dark:text-gray-300"/></button>
                </div>
                
                <div className="mb-4">
                     <p className="text-gray-500 dark:text-gray-400 text-sm">المنتج المحدد</p>
                     <p className="font-bold text-xl text-gray-900 dark:text-white">{productToAdd.name}</p>
                     <div className="flex flex-wrap items-center gap-2 mt-2 text-xs">
                        <span className="bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-gray-300 px-2 py-1 rounded flex items-center">
                             <Package size={12} className="ml-1"/>
                             المخزون: {productToAdd.stock}
                        </span>
                     </div>
                </div>

                <div className="space-y-4">
                    <div className="flex gap-4">
                        <div className="flex-1">
                            <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">الكمية</label>
                            <input 
                                ref={qtyInputRef}
                                type="number"
                                value={addQty}
                                onChange={(e) => setAddQty(e.target.value)}
                                className="w-full p-3 border border-gray-200 dark:border-slate-600 rounded-xl text-center bg-white dark:bg-slate-700 font-bold text-2xl text-gray-900 dark:text-white outline-none focus:border-[#006d77] focus:ring-2 focus:ring-[#006d77]/20"
                                placeholder="1"
                            />
                        </div>
                        <div className="flex-1">
                            <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">
                                {type === TransactionType.SALE ? 'سعر البيع' : 'سعر الشراء'}
                            </label>
                            <input 
                                type="number"
                                value={addPrice}
                                onChange={(e) => setAddPrice(e.target.value)}
                                className="w-full p-3 border border-gray-200 dark:border-slate-600 rounded-xl text-center bg-white dark:bg-slate-700 font-bold text-2xl text-gray-900 dark:text-white outline-none focus:border-[#006d77] focus:ring-2 focus:ring-[#006d77]/20"
                                placeholder="0"
                                autoFocus
                            />
                        </div>
                    </div>
                    
                    {type === TransactionType.PURCHASE && (
                         <div className="bg-emerald-50 dark:bg-emerald-900/20 p-3 rounded-xl border border-emerald-100 dark:border-emerald-900/30">
                            <label className="flex items-center text-sm text-emerald-700 dark:text-emerald-400 font-bold mb-2">
                                <Tag size={16} className="ml-1" />
                                سعر البيع (لهذه الكمية فقط)
                            </label>
                            <div className="flex items-center">
                                <input 
                                    type="number"
                                    value={addBatchSellPrice}
                                    onChange={(e) => setAddBatchSellPrice(e.target.value)}
                                    className="w-full p-2 border border-emerald-200 dark:border-emerald-800 rounded-lg text-center bg-white dark:bg-slate-800 font-bold text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
                                    placeholder="اختياري"
                                />
                            </div>
                            <p className="text-[10px] text-gray-500 dark:text-gray-400 mt-1">
                                هذا السعر سيحفظ في سجل الفاتورة فقط كمرجع ولن يغير سعر المخزن.
                            </p>
                        </div>
                    )}

                    <div className="bg-gray-50 dark:bg-slate-700 p-3 rounded-lg flex justify-between items-center">
                        <span className="text-sm text-gray-500 dark:text-gray-400">الإجمالي للصنف</span>
                        <span className="font-bold text-lg text-[#006d77] dark:text-emerald-400">
                            {((parseFloat(addQty) || 0) * (parseFloat(addPrice) || 0)).toLocaleString()} ج.م
                        </span>
                    </div>

                    <button 
                        onClick={confirmAddProduct}
                        className="w-full py-3 rounded-xl font-bold text-white shadow-lg transition-colors mt-2 bg-[#006d77] hover:bg-[#005c66]"
                    >
                        تأكيد وإضافة
                    </button>
                </div>
             </div>
        </div>
      )}

      {isAddingProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[70] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 shadow-2xl">
                <div className="flex justify-between items-center mb-4 border-b border-gray-100 dark:border-slate-700 pb-2">
                    <h3 className="font-bold text-lg text-gray-800 dark:text-white flex items-center">
                        <Package size={20} className="ml-2 text-[#006d77] dark:text-emerald-400" />
                        منتج جديد
                    </h3>
                    <button onClick={() => setIsAddingProduct(false)} className="bg-gray-100 dark:bg-slate-700 p-1 rounded-full"><X size={20} className="text-gray-500 dark:text-gray-300"/></button>
                </div>
                
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">اسم المنتج</label>
                        <input 
                            type="text"
                            value={newProductData.name}
                            onChange={(e) => setNewProductData({...newProductData, name: e.target.value})}
                            className="w-full p-3 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-[#006d77]"
                            placeholder="اسم المنتج..."
                            autoFocus
                        />
                    </div>

                    <button 
                        onClick={handleQuickAddProduct}
                        disabled={!newProductData.name}
                        className={`w-full py-3 rounded-xl font-bold text-white shadow-lg transition-colors mt-2 ${
                            !newProductData.name ? 'bg-gray-300 dark:bg-slate-600 cursor-not-allowed' : 'bg-[#006d77] hover:bg-[#005c66]'
                        }`}
                    >
                        حفظ وإضافة للفاتورة
                    </button>
                </div>
             </div>
        </div>
      )}
    </div>
  );
};

export default AddTransaction;
