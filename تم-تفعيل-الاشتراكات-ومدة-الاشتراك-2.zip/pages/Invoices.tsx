
import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { TransactionType, Transaction, PaymentRecord } from '../types';
import { ArrowRight, Search, FileText, ShoppingBag, ShoppingCart, Calendar, User, ChevronLeft, X, Edit, Trash2, CreditCard, History, CheckCircle, ArrowUpRight, Banknote, Wallet, Plus, ArrowDownLeft, Filter, AlertTriangle, TrendingDown, Printer, UserCheck } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';

const Invoices: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { transactions, contacts, deleteTransaction, updateTransaction, darkMode, partners, realUser, currentUser, storeProfile } = useStore();
  
  const [activeTab, setActiveTab] = useState<'SALES' | 'PURCHASES' | 'PAYMENTS' | 'EXPENSES'>('SALES');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedInvoice, setSelectedInvoice] = useState<Transaction | null>(null);

  // --- Date Filter State ---
  const getLocalDateString = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const [filterType, setFilterType] = useState<'ALL' | 'TODAY' | 'WEEK' | 'MONTH' | 'CUSTOM'>('MONTH');
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(1); // Start of current month
    return getLocalDateString(d);
  });
  const [endDate, setEndDate] = useState(() => {
    return getLocalDateString(new Date());
  });
  
  // Payment Modal State
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentTargetInvoice, setPaymentTargetInvoice] = useState<Transaction | null>(null);
  const [editingPaymentRecord, setEditingPaymentRecord] = useState<PaymentRecord | null>(null);
  
  const [paymentAmount, setPaymentAmount] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState(() => {
    const now = new Date();
    return now.toISOString().split('T')[0];
  });
  const [paymentNote, setPaymentNote] = useState('');

  // DELETE CONFIRMATION STATE
  const [deleteTarget, setDeleteTarget] = useState<{ 
      type: 'INVOICE' | 'PAYMENT_RECORD' | 'EXPENSE'; 
      id: string; 
      parentId?: string; // For payments
  } | null>(null);

  // Helper to get current user name AND phone
  const getCurrentUserCreator = () => {
      if (realUser === currentUser) {
          return { name: storeProfile.name || 'المالك', phone: realUser || '' };
      }
      const partner = partners.find(p => p.phone === realUser);
      return { name: partner ? partner.name : 'مستخدم', phone: realUser || '' };
  };

  // Helper to render Creator info safe (handles old string data vs new object data)
  const renderCreatorInfo = (creator: any) => {
      if (!creator) return null;
      if (typeof creator === 'string') return <span>{creator}</span>;
      return (
          <span className="flex items-center">
              {creator.name} 
              <span className="mr-1 text-[9px] text-gray-400 dark:text-gray-500">({creator.phone})</span>
          </span>
      );
  };

  // Handle Tab Navigation and Auto-Open Invoice from other pages
  useEffect(() => {
      if (location.state?.tab) {
          setActiveTab(location.state.tab);
      }
      
      // Check if we need to open a specific invoice immediately
      if (location.state?.openInvoiceId) {
          const targetInvoice = transactions.find(t => t.id === location.state.openInvoiceId);
          if (targetInvoice) {
              setSelectedInvoice(targetInvoice);
              // Ensure we are on the correct tab for the context background
              if (targetInvoice.type === TransactionType.SALE) setActiveTab('SALES');
              if (targetInvoice.type === TransactionType.PURCHASE) setActiveTab('PURCHASES');
              if (targetInvoice.type === TransactionType.PAYMENT) setActiveTab('PAYMENTS');
              if (targetInvoice.type === TransactionType.EXPENSE) setActiveTab('EXPENSES');
              
              // If opening specific invoice, temporarily set filter to ALL to ensure it's found
              setFilterType('ALL');
          }
      }
  }, [location.state, transactions]);

  // Quick Filter Logic
  const handleQuickFilter = (type: 'ALL' | 'TODAY' | 'WEEK' | 'MONTH') => {
      setFilterType(type);
      const end = new Date();
      const start = new Date();

      if (type === 'TODAY') {
          // Start remains today
      } else if (type === 'WEEK') {
          start.setDate(start.getDate() - 7);
      } else if (type === 'MONTH') {
          start.setDate(1);
      }
      
      if (type !== 'ALL') {
        setStartDate(getLocalDateString(start));
        setEndDate(getLocalDateString(end));
      }
  };

  const handleManualDateChange = (isStart: boolean, val: string) => {
      if (isStart) setStartDate(val);
      else setEndDate(val);
      setFilterType('CUSTOM');
  };

  // Filter transactions based on tab, date, and search
  const filteredTransactions = transactions
    .filter(t => {
      // 1. Tab Filter
      if (activeTab === 'SALES') return t.type === TransactionType.SALE;
      if (activeTab === 'PURCHASES') return t.type === TransactionType.PURCHASE;
      if (activeTab === 'PAYMENTS') return t.type === TransactionType.PAYMENT;
      if (activeTab === 'EXPENSES') return t.type === TransactionType.EXPENSE;
      return false;
    })
    .filter(t => {
      // 2. Date Filter
      if (filterType === 'ALL') return true;
      const tDate = t.date.split('T')[0];
      return tDate >= startDate && tDate <= endDate;
    })
    .filter(t => {
      // 3. Search Filter
      const contactName = contacts.find(c => c.id === t.contactId)?.name || '';
      const creatorName = t.createdBy?.name || '';
      const creatorPhone = t.createdBy?.phone || '';
      
      return contactName.toLowerCase().includes(searchQuery.toLowerCase()) || 
             creatorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
             creatorPhone.includes(searchQuery) ||
             t.amount.toString().includes(searchQuery) ||
             (t.notes && t.notes.toLowerCase().includes(searchQuery.toLowerCase()));
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()); // Sort newest first

  const getContactName = (id?: string) => {
    if (!id) return activeTab === 'SALES' ? 'عميل نقدي' : 'مورد غير محدد';
    return contacts.find(c => c.id === id)?.name || 'غير معروف';
  };

  const getContactPhone = (id?: string) => {
      if (!id) return '';
      return contacts.find(c => c.id === id)?.phone || '';
  };

  // Helper to calculate invoice totals for display
  const getInvoiceTotals = (t: Transaction) => {
    const subTotal = t.items 
      ? t.items.reduce((acc, item) => acc + (item.price * item.quantity), 0) 
      : t.amount; 
    const discount = t.discount || 0;
    const total = t.amount; 
    const paid = t.paidAmount ?? total;
    const remaining = total - paid;
    return { subTotal, discount, total, paid, remaining };
  };

  // --- DELETE LOGIC ---
  const requestDeleteInvoice = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setDeleteTarget({ type: 'INVOICE', id });
  };

  const requestDeleteExpense = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setDeleteTarget({ type: 'EXPENSE', id });
  };

  const requestDeletePaymentRecord = (transactionId: string, recordId: string) => {
    setDeleteTarget({ type: 'PAYMENT_RECORD', id: recordId, parentId: transactionId });
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;

    if (deleteTarget.type === 'INVOICE' || deleteTarget.type === 'EXPENSE') {
        deleteTransaction(deleteTarget.id);
        if (selectedInvoice?.id === deleteTarget.id) setSelectedInvoice(null);
    } else if (deleteTarget.type === 'PAYMENT_RECORD' && deleteTarget.parentId) {
        // Find transaction
        const transaction = transactions.find(t => t.id === deleteTarget.parentId);
        if (transaction) {
            const currentHistory = transaction.paymentHistory || [];
            const updatedHistory = currentHistory.filter(rec => rec.id !== deleteTarget.id);
            const newPaidAmount = updatedHistory.reduce((sum, rec) => sum + rec.amount, 0);

            const updatedTransaction: Transaction = {
                ...transaction,
                paidAmount: newPaidAmount,
                paymentHistory: updatedHistory
            };

            updateTransaction(transaction.id, updatedTransaction);
            if (selectedInvoice?.id === transaction.id) setSelectedInvoice(updatedTransaction);
        }
    }
    setDeleteTarget(null);
  };

  const handleEdit = (transaction: Transaction) => {
      setSelectedInvoice(null);
      navigate('/add', { state: { editTransaction: transaction } });
  };

  const openPaymentModal = (transaction: Transaction, recordToEdit: PaymentRecord | null = null) => {
      setPaymentTargetInvoice(transaction);
      setEditingPaymentRecord(recordToEdit);

      if (recordToEdit) {
          // Editing existing payment
          setPaymentAmount(recordToEdit.amount.toString());
          setPaymentDate(recordToEdit.date.split('T')[0]);
          setPaymentNote(recordToEdit.note || '');
      } else {
          // Adding new payment
          const { remaining } = getInvoiceTotals(transaction);
          setPaymentAmount(remaining.toString());
          setPaymentDate(new Date().toISOString().split('T')[0]);
          setPaymentNote('');
      }
      setIsPaymentModalOpen(true);
  };

  const handleSubmitPayment = () => {
      if (!paymentTargetInvoice || !paymentAmount || parseFloat(paymentAmount) <= 0) return;

      const amount = parseFloat(paymentAmount);
      const currentHistory = paymentTargetInvoice.paymentHistory || [];
      let updatedHistory: PaymentRecord[];
      let newPaidAmount = 0;

      const creator = getCurrentUserCreator(); // Get object {name, phone}

      if (editingPaymentRecord) {
          // UPDATE existing record
          updatedHistory = currentHistory.map(rec => {
              if (rec.id === editingPaymentRecord.id) {
                  return {
                      ...rec,
                      amount: amount,
                      date: new Date(paymentDate).toISOString(),
                      note: paymentNote || 'تم تعديل الدفعة',
                      createdBy: creator // Update creator on edit to current user
                  };
              }
              return rec;
          });
      } else {
          // CREATE new record
          const newPaymentRecord: PaymentRecord = {
            id: Date.now().toString(),
            date: new Date(paymentDate).toISOString(),
            amount: amount,
            note: paymentNote || 'دفعة مسجلة',
            createdBy: creator // Store as object
          };
          updatedHistory = [...currentHistory, newPaymentRecord];
      }

      // Recalculate Total Paid Amount from History
      newPaidAmount = updatedHistory.reduce((sum, rec) => sum + rec.amount, 0);

      const updatedTransaction: Transaction = {
          ...paymentTargetInvoice,
          paidAmount: newPaidAmount,
          paymentHistory: updatedHistory
      };

      // This will automatically handle balance updates via StoreContext
      updateTransaction(paymentTargetInvoice.id, updatedTransaction);
      
      if (selectedInvoice && selectedInvoice.id === paymentTargetInvoice.id) {
        setSelectedInvoice(updatedTransaction);
      }
      
      setPaymentTargetInvoice(null);
      setEditingPaymentRecord(null);
      setIsPaymentModalOpen(false);
  };

  const handlePrint = () => {
      window.print();
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 pb-24 transition-colors">
      {/* Header */}
      <div className="bg-white dark:bg-slate-800 p-4 sticky top-0 z-10 shadow-sm border-b border-gray-100 dark:border-slate-700">
        <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
                <button onClick={() => navigate(-1)} className="p-2 -mr-2 text-gray-600 dark:text-gray-300">
                    <ArrowRight size={24} />
                </button>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white mr-2">سجل العمليات</h1>
            </div>
            
             {/* Quick Create Buttons */}
             {(activeTab === 'SALES' || activeTab === 'PURCHASES') && (
                <button 
                    onClick={() => navigate('/add', { state: { initialType: activeTab === 'SALES' ? TransactionType.SALE : TransactionType.PURCHASE } })}
                    className={`text-white p-2 rounded-lg shadow-sm flex items-center text-sm font-bold active:scale-95 transition-transform ${activeTab === 'SALES' ? 'bg-emerald-600' : 'bg-blue-600'}`}
                >
                    <Plus size={18} className="ml-1"/>
                    {activeTab === 'SALES' ? 'بيع جديد' : 'شراء جديد'}
                </button>
            )}
             {activeTab === 'EXPENSES' && (
                <button 
                    onClick={() => navigate('/add', { state: { initialType: TransactionType.EXPENSE } })}
                    className="bg-red-600 text-white p-2 rounded-lg shadow-sm flex items-center text-sm font-bold active:scale-95 transition-transform"
                >
                    <Plus size={18} className="ml-1"/>
                    مصروف جديد
                </button>
            )}
        </div>

        {/* Tabs */}
        <div className="flex p-1 bg-gray-100 dark:bg-slate-700 rounded-xl mb-4 overflow-x-auto no-scrollbar">
            <button 
                onClick={() => setActiveTab('SALES')}
                className={`flex-1 min-w-[90px] py-2 rounded-lg text-xs font-bold flex items-center justify-center transition-all ${activeTab === 'SALES' ? 'bg-white dark:bg-slate-600 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-gray-500 dark:text-gray-400'}`}
            >
                <ShoppingBag size={14} className="ml-1"/>
                المبيعات
            </button>
            <button 
                onClick={() => setActiveTab('PURCHASES')}
                className={`flex-1 min-w-[90px] py-2 rounded-lg text-xs font-bold flex items-center justify-center transition-all ${activeTab === 'PURCHASES' ? 'bg-white dark:bg-slate-600 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-gray-500 dark:text-gray-400'}`}
            >
                <ShoppingCart size={14} className="ml-1"/>
                المشتريات
            </button>
            <button 
                onClick={() => setActiveTab('PAYMENTS')}
                className={`flex-1 min-w-[90px] py-2 rounded-lg text-xs font-bold flex items-center justify-center transition-all ${activeTab === 'PAYMENTS' ? 'bg-white dark:bg-slate-600 text-purple-600 dark:text-purple-400 shadow-sm' : 'text-gray-500 dark:text-gray-400'}`}
            >
                <Banknote size={14} className="ml-1"/>
                المدفوعات
            </button>
            <button 
                onClick={() => setActiveTab('EXPENSES')}
                className={`flex-1 min-w-[90px] py-2 rounded-lg text-xs font-bold flex items-center justify-center transition-all ${activeTab === 'EXPENSES' ? 'bg-white dark:bg-slate-600 text-red-600 dark:text-red-400 shadow-sm' : 'text-gray-500 dark:text-gray-400'}`}
            >
                <TrendingDown size={14} className="ml-1"/>
                المصروفات
            </button>
        </div>

        {/* Filters */}
        {/* ... Date filters ... */}
        
        {/* Search */}
        <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <input 
                type="text"
                placeholder={activeTab === 'EXPENSES' ? "بحث بنوع المصروف أو المبلغ..." : "بحث باسم العميل/المورد أو المبلغ..."}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-4 pr-10 py-2 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-lg text-sm focus:ring-2 focus:ring-primary outline-none text-gray-900 dark:text-white"
            />
        </div>
      </div>

      {/* List */}
      <div className="p-4 space-y-3">
        {filteredTransactions.map(t => {
            const isPayment = t.type === TransactionType.PAYMENT;
            const isExpense = t.type === TransactionType.EXPENSE;

            if (isPayment) {
                 return (
                    <div key={t.id} className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-purple-100 dark:border-purple-900/30 shadow-sm relative">
                        <div className="flex justify-between items-start mb-2">
                            <div className="flex items-center">
                                <div className="p-2 rounded-full ml-3 bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400">
                                    <Wallet size={20}/>
                                </div>
                                <div>
                                    <h3 className="font-bold text-gray-800 dark:text-white text-sm">
                                        دفعة نقدية
                                    </h3>
                                    <div className="flex items-center text-xs text-gray-400 mt-1">
                                        <Calendar size={12} className="ml-1"/>
                                        {new Date(t.date).toLocaleDateString('ar-EG')}
                                    </div>
                                    {t.createdBy && (
                                        <div className="text-[10px] text-gray-400 mt-0.5 flex items-center">
                                            <UserCheck size={10} className="ml-1"/>
                                            {t.createdBy.name}
                                            <span className="mr-1 text-[9px]">({t.createdBy.phone})</span>
                                        </div>
                                    )}
                                </div>
                            </div>
                            <button 
                                onClick={(e) => requestDeleteInvoice(t.id, e)} 
                                className="text-red-500 bg-white dark:bg-slate-700 hover:bg-red-50 dark:hover:bg-red-900/20 p-2 rounded-lg shadow-sm border border-gray-100 dark:border-slate-600 transition-colors z-10"
                            >
                                <Trash2 size={18} />
                            </button>
                        </div>
                        <div className="flex justify-between items-end">
                            <span className="text-xl font-bold text-purple-600 dark:text-purple-400">
                                {t.amount.toLocaleString()} <span className="text-xs font-normal text-gray-500 dark:text-gray-400 mr-1">ج.م</span>
                            </span>
                            <div className="text-left bg-gray-50 dark:bg-slate-700 px-2 py-1 rounded-md">
                                <span className="text-xs font-bold text-gray-600 dark:text-gray-300 block">{getContactName(t.contactId)}</span>
                            </div>
                        </div>
                    </div>
                 );
            }

            if (isExpense) {
                return (
                    <div key={t.id} className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-red-100 dark:border-red-900/30 shadow-sm relative">
                        <div className="flex justify-between items-start mb-2">
                            <div className="flex items-center">
                                <div className="p-2 rounded-full ml-3 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400">
                                    <TrendingDown size={20}/>
                                </div>
                                <div>
                                    <h3 className="font-bold text-gray-800 dark:text-white text-sm">
                                        مصروف
                                    </h3>
                                    <div className="flex items-center text-xs text-gray-400 mt-1">
                                        <Calendar size={12} className="ml-1"/>
                                        {new Date(t.date).toLocaleDateString('ar-EG')}
                                    </div>
                                    {t.createdBy && (
                                        <div className="text-[10px] text-gray-400 mt-0.5 flex items-center">
                                            <UserCheck size={10} className="ml-1"/>
                                            {t.createdBy.name}
                                            <span className="mr-1 text-[9px]">({t.createdBy.phone})</span>
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className="flex space-x-2 space-x-reverse">
                                <button 
                                    onClick={() => handleEdit(t)} 
                                    className="text-gray-500 bg-white dark:bg-slate-700 hover:bg-gray-100 dark:hover:bg-slate-600 p-2 rounded-lg shadow-sm border border-gray-100 dark:border-slate-600 transition-colors z-10"
                                >
                                    <Edit size={18} />
                                </button>
                                <button 
                                    onClick={(e) => requestDeleteExpense(t.id, e)} 
                                    className="text-red-500 bg-white dark:bg-slate-700 hover:bg-red-50 dark:hover:bg-red-900/20 p-2 rounded-lg shadow-sm border border-gray-100 dark:border-slate-600 transition-colors z-10"
                                >
                                    <Trash2 size={18} />
                                </button>
                            </div>
                        </div>
                        <div className="flex justify-between items-end mt-2">
                            <span className="text-xl font-bold text-red-600 dark:text-red-400">
                                {t.amount.toLocaleString()} <span className="text-xs font-normal text-gray-500 dark:text-gray-400 mr-1">ج.م</span>
                            </span>
                            <div className="text-left bg-gray-50 dark:bg-slate-700 px-3 py-1.5 rounded-md">
                                <span className="text-xs font-bold text-gray-600 dark:text-gray-300 block">{t.notes || 'مصروف عام'}</span>
                            </div>
                        </div>
                    </div>
                );
            }

            // Sales and Purchase Card Style
            const { remaining, paid } = getInvoiceTotals(t);
            return (
                <div 
                    key={t.id} 
                    onClick={() => setSelectedInvoice(t)}
                    className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-gray-100 dark:border-slate-700 shadow-sm active:scale-[0.99] transition-transform cursor-pointer relative"
                >
                    <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center">
                            <div className={`p-2 rounded-full ml-3 ${t.type === TransactionType.SALE ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' : 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'}`}>
                                {t.type === TransactionType.SALE ? <ArrowUpRight size={20}/> : <ArrowDownLeft size={20}/>}
                            </div>
                            <div>
                                <h3 className="font-bold text-gray-800 dark:text-white text-sm">
                                    {t.type === TransactionType.SALE ? 'فاتورة بيع' : 'فاتورة شراء'}
                                </h3>
                                <div className="flex items-center text-xs text-gray-400 mt-1">
                                    <Calendar size={12} className="ml-1"/>
                                    {new Date(t.date).toLocaleDateString('ar-EG')}
                                </div>
                                {t.createdBy && (
                                    <div className="text-[10px] text-gray-400 mt-0.5 flex items-center">
                                        <UserCheck size={10} className="ml-1"/>
                                        {t.createdBy.name}
                                        <span className="mr-1 text-[9px]">({t.createdBy.phone})</span>
                                    </div>
                                )}
                            </div>
                        </div>
                        {/* Status Label */}
                        <div className="px-2 py-0.5 rounded text-[10px] font-bold bg-gray-100 dark:bg-slate-700 text-gray-500 dark:text-gray-400">
                            #{t.id.slice(-4)}
                        </div>
                    </div>

                    <div className="flex justify-between items-end mb-3">
                        <span className={`text-xl font-bold ${t.type === TransactionType.SALE ? 'text-emerald-600 dark:text-emerald-400' : 'text-blue-600 dark:text-blue-400'}`}>
                            {t.amount.toLocaleString()} 
                            <span className="text-xs font-normal text-gray-500 dark:text-gray-400 mr-1">ج.م</span>
                        </span>
                        <div className="text-left">
                            <span className="text-xs text-gray-500 dark:text-gray-400 block">{getContactName(t.contactId)}</span>
                        </div>
                    </div>

                    <div className="bg-gray-50 dark:bg-slate-700 p-3 rounded-lg flex justify-between items-center text-xs">
                         <div className="text-center">
                             <span className="block text-gray-400 mb-1">مدفوع</span>
                             <span className="block font-bold text-gray-800 dark:text-white">{paid.toLocaleString()}</span>
                         </div>
                         <div className="h-6 w-px bg-gray-200 dark:bg-slate-600"></div>
                         <div className="text-center">
                             <span className="block text-red-400 mb-1">متبقي (آجل)</span>
                             <span className={`block font-bold ${remaining > 0 ? 'text-red-600 dark:text-red-400' : 'text-gray-400 dark:text-gray-500'}`}>
                                {remaining.toLocaleString()}
                             </span>
                         </div>
                    </div>

                    <div className="flex justify-between items-center mt-3">
                        {remaining > 0 && (
                            <button 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    openPaymentModal(t);
                                }}
                                className={`py-1.5 px-4 rounded-lg text-xs font-bold flex items-center transition-colors ${t.type === TransactionType.SALE ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/30' : 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/30'}`}
                            >
                                <CreditCard size={12} className="ml-1"/>
                                {t.type === TransactionType.SALE ? 'تحصيل' : 'سداد'}
                            </button>
                        )}
                    </div>
                </div>
            );
        })}
        {filteredTransactions.length === 0 && (
            <div className="text-center py-10 text-gray-400">
                <FileText size={48} className="mx-auto mb-2 opacity-20" />
                <p>لا توجد بيانات مسجلة في هذه الفترة</p>
                {filterType !== 'ALL' && <p className="text-xs mt-2 text-primary cursor-pointer" onClick={() => handleQuickFilter('ALL')}>عرض الكل</p>}
            </div>
        )}
      </div>

      {/* Invoice Detail Modal */}
      {selectedInvoice && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-2xl overflow-hidden flex flex-col max-h-[90vh]">
                {/* Modal Header */}
                <div className={`p-4 flex justify-between items-center text-white ${selectedInvoice.type === TransactionType.SALE ? 'bg-emerald-600 dark:bg-emerald-700' : 'bg-blue-600 dark:bg-blue-700'}`}>
                    <div className="flex items-center">
                        <button onClick={() => setSelectedInvoice(null)} className="p-1 hover:bg-white/20 rounded-full ml-2">
                            <X size={20} />
                        </button>
                        <h2 className="font-bold text-lg">
                            {selectedInvoice.type === TransactionType.SALE ? 'فاتورة مبيعات' : 'فاتورة مشتريات'}
                        </h2>
                    </div>
                    <div className="flex space-x-2 space-x-reverse">
                        <button onClick={handlePrint} className="p-2 bg-white/20 rounded-lg hover:bg-white/30" title="طباعة الفاتورة">
                            <Printer size={18} />
                        </button>
                        <button onClick={() => handleEdit(selectedInvoice)} className="p-2 bg-white/20 rounded-lg hover:bg-white/30">
                            <Edit size={18} />
                        </button>
                        <button onClick={(e) => requestDeleteInvoice(selectedInvoice.id, e)} className="p-2 bg-white/20 rounded-lg hover:bg-red-500 hover:text-white">
                            <Trash2 size={18} />
                        </button>
                    </div>
                </div>

                {/* Modal Body */}
                <div className="p-6 overflow-y-auto no-scrollbar relative">
                    
                    {/* ... Printable Section ... */}
                    <div id="printable-receipt" className="hidden">
                        <div className="text-center mb-4 pb-4 border-b-2 border-dashed border-gray-300">
                            <h2 className="text-2xl font-bold mb-1">حساباتي</h2>
                            <p className="text-sm">إدارة المشاريع الصغيرة</p>
                            <p className="text-xs mt-2">{new Date(selectedInvoice.date).toLocaleString('ar-EG')}</p>
                            <p className="text-xs font-bold mt-1">فاتورة #{selectedInvoice.id.slice(-6)}</p>
                             {selectedInvoice.createdBy && (
                                <p className="text-xs mt-1">بواسطة: {selectedInvoice.createdBy.name} ({selectedInvoice.createdBy.phone})</p>
                            )}
                        </div>
                        {/* ... rest of printable receipt ... */}
                         <div className="mb-4 text-sm">
                             <div className="flex justify-between mb-1">
                                <span>{selectedInvoice.type === TransactionType.SALE ? 'العميل:' : 'المورد:'}</span>
                                <span className="font-bold">{getContactName(selectedInvoice.contactId)}</span>
                             </div>
                             {getContactPhone(selectedInvoice.contactId) && (
                                <div className="flex justify-between">
                                    <span>الهاتف:</span>
                                    <span>{getContactPhone(selectedInvoice.contactId)}</span>
                                </div>
                             )}
                        </div>

                        <div className="border-b-2 border-dashed border-gray-300 pb-2 mb-2">
                             <table className="w-full text-sm">
                                <thead>
                                    <tr className="text-xs border-b border-black">
                                        <th className="text-right pb-1">الصنف</th>
                                        <th className="text-center pb-1">العدد</th>
                                        <th className="text-center pb-1">السعر</th>
                                        <th className="text-left pb-1">المجموع</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {selectedInvoice.items?.map((item, idx) => (
                                        <tr key={idx}>
                                            <td className="pt-1 font-bold">{item.productName}</td>
                                            <td className="pt-1 text-center">{item.quantity}</td>
                                            <td className="pt-1 text-center">{item.price}</td>
                                            <td className="pt-1 text-left">{(item.quantity * item.price).toLocaleString()}</td>
                                        </tr>
                                    ))}
                                </tbody>
                             </table>
                        </div>

                        <div className="space-y-1 text-sm font-bold mb-4 border-b-2 border-dashed border-gray-300 pb-4">
                             {/* Totals */}
                             <div className="flex justify-between">
                                <span>المجموع:</span>
                                <span>{getInvoiceTotals(selectedInvoice).subTotal.toLocaleString()}</span>
                             </div>
                             {getInvoiceTotals(selectedInvoice).discount > 0 && (
                                <div className="flex justify-between">
                                    <span>الخصم:</span>
                                    <span>{getInvoiceTotals(selectedInvoice).discount.toLocaleString()}-</span>
                                </div>
                             )}
                             <div className="flex justify-between text-lg mt-2">
                                <span>الاجمالي:</span>
                                <span>{getInvoiceTotals(selectedInvoice).total.toLocaleString()}</span>
                             </div>
                              <div className="flex justify-between mt-1 font-normal text-xs">
                                <span>المدفوع:</span>
                                <span>{getInvoiceTotals(selectedInvoice).paid.toLocaleString()}</span>
                             </div>
                             {getInvoiceTotals(selectedInvoice).remaining > 0 && (
                                <div className="flex justify-between mt-1 text-xs">
                                    <span>المتبقي:</span>
                                    <span>{getInvoiceTotals(selectedInvoice).remaining.toLocaleString()}</span>
                                </div>
                             )}
                        </div>
                        
                        <div className="text-center text-xs mt-4">
                            <p>شكراً لتعاملكم معنا</p>
                        </div>
                    </div>

                    {/* Contact Info */}
                    <div className="flex items-center justify-between mb-4 p-3 bg-gray-50 dark:bg-slate-700 rounded-xl border border-gray-100 dark:border-slate-600">
                        <div className="flex items-center">
                            <User className="text-gray-400 ml-2" size={20} />
                            <div>
                                <p className="text-xs text-gray-500 dark:text-gray-400">
                                    {selectedInvoice.type === TransactionType.SALE ? 'العميل' : 'المورد'}
                                </p>
                                <p className="font-bold text-gray-800 dark:text-white">{getContactName(selectedInvoice.contactId)}</p>
                            </div>
                        </div>
                        <div className="text-left">
                            <p className="text-xs text-gray-500 dark:text-gray-400">رقم الفاتورة</p>
                            <p className="font-mono text-gray-800 dark:text-white font-bold text-sm">#{selectedInvoice.id.slice(-6)}</p>
                        </div>
                    </div>

                    {/* Created By Info - NEW SECTION */}
                    {selectedInvoice.createdBy && (
                         <div className="flex items-center justify-between mb-4 p-3 bg-blue-50 dark:bg-blue-900/10 rounded-xl border border-blue-100 dark:border-blue-900/30">
                            <div className="flex items-center">
                                <UserCheck className="text-blue-500 ml-2" size={20} />
                                <div>
                                    <p className="text-xs text-blue-500 dark:text-blue-400">
                                        تم التسجيل بواسطة
                                    </p>
                                    <p className="font-bold text-gray-800 dark:text-white text-sm">{selectedInvoice.createdBy.name}</p>
                                </div>
                            </div>
                             <div className="text-left">
                                <p className="text-xs text-gray-500 dark:text-gray-400">هاتف الموظف</p>
                                <p className="font-mono text-gray-800 dark:text-white font-bold text-xs">{selectedInvoice.createdBy.phone}</p>
                            </div>
                        </div>
                    )}

                    {/* Items Table */}
                    <div className="mb-6">
                        <h3 className="font-bold text-gray-800 dark:text-white mb-3 text-sm flex items-center">
                           <ShoppingBag size={16} className="ml-2 text-primary"/>
                           تفاصيل المنتجات
                        </h3>
                        {/* ... items table code ... */}
                        <div className="bg-gray-50 dark:bg-slate-700 rounded-xl overflow-hidden border border-gray-100 dark:border-slate-600">
                            <table className="w-full text-sm">
                                <thead className="bg-gray-100 dark:bg-slate-600 text-gray-500 dark:text-gray-300 text-xs">
                                    <tr>
                                        <th className="p-3 text-right font-medium">المنتج</th>
                                        <th className="p-3 text-center font-medium">الكمية</th>
                                        <th className="p-3 text-center font-medium">السعر</th>
                                        <th className="p-3 text-left font-medium">الاجمالي</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100 dark:divide-slate-600">
                                    {selectedInvoice.items?.map((item, idx) => (
                                        <tr key={idx}>
                                            <td className="p-3 font-bold text-gray-800 dark:text-white">{item.productName}</td>
                                            <td className="p-3 text-center text-gray-600 dark:text-gray-300">{item.quantity}</td>
                                            <td className="p-3 text-center text-gray-600 dark:text-gray-300">{item.price}</td>
                                            <td className="p-3 text-left font-bold text-gray-800 dark:text-white">{(item.quantity * item.price).toLocaleString()}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {(!selectedInvoice.items || selectedInvoice.items.length === 0) && (
                                <div className="p-4 text-center text-gray-400 text-sm italic">لا توجد تفاصيل منتجات (عملية قديمة)</div>
                            )}
                        </div>
                    </div>
                    
                    {/* ... Rest of modal (History, Totals, Pay Button) ... */}
                    {/* Payment History */}
                    {selectedInvoice.paymentHistory && selectedInvoice.paymentHistory.length > 0 && (
                        <div className="mb-6">
                            <h3 className="font-bold text-gray-800 dark:text-white mb-3 text-sm flex items-center">
                               <History size={16} className="ml-2 text-primary"/>
                               سجل الدفعات السابقة
                            </h3>
                            <div className="bg-white dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl overflow-hidden text-sm">
                                {selectedInvoice.paymentHistory.map((rec, idx) => (
                                    <div key={idx} className="flex justify-between items-center p-3 border-b border-gray-100 dark:border-slate-600 last:border-0 group">
                                        <div className="flex items-center text-gray-600 dark:text-gray-300 text-xs">
                                            <CheckCircle size={14} className="ml-2 text-emerald-500"/>
                                            <div className="mr-2">
                                                <span className="font-medium block">{new Date(rec.date).toLocaleDateString('ar-EG')}</span>
                                                {rec.createdBy && <span className="text-[10px] text-blue-600 dark:text-blue-400 font-bold block">بواسطة: {renderCreatorInfo(rec.createdBy)}</span>}
                                                {rec.note && <span className="text-gray-400 text-[10px] block">{rec.note}</span>}
                                            </div>
                                        </div>
                                        
                                        <div className="flex items-center">
                                            <span className="font-bold text-emerald-600 dark:text-emerald-400 ml-3">{rec.amount.toLocaleString()} ج.م</span>
                                            <div className="flex space-x-2 space-x-reverse opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                                                <button 
                                                    onClick={() => openPaymentModal(selectedInvoice, rec)}
                                                    className="p-1.5 bg-gray-100 dark:bg-slate-600 text-gray-600 dark:text-gray-300 rounded-md hover:bg-gray-200 dark:hover:bg-slate-500"
                                                >
                                                    <Edit size={14} />
                                                </button>
                                                <button 
                                                    onClick={() => requestDeletePaymentRecord(selectedInvoice.id, rec.id)}
                                                    className="p-1.5 bg-red-50 dark:bg-red-900/20 text-red-500 rounded-md hover:bg-red-100 dark:hover:bg-red-900/40"
                                                >
                                                    <Trash2 size={14} />
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Totals */}
                    <div className="bg-gray-50 dark:bg-slate-700 p-4 rounded-xl space-y-2 border border-gray-100 dark:border-slate-600 text-sm">
                        <div className="flex justify-between text-gray-600 dark:text-gray-300">
                            <span>المجموع الفرعي</span>
                            <span>{getInvoiceTotals(selectedInvoice).subTotal.toLocaleString()}</span>
                        </div>
                        {getInvoiceTotals(selectedInvoice).discount > 0 && (
                            <div className="flex justify-between text-red-500 font-medium">
                                <span>الخصم</span>
                                <span>- {getInvoiceTotals(selectedInvoice).discount.toLocaleString()}</span>
                            </div>
                        )}
                        <div className="border-t border-gray-200 dark:border-slate-600 my-2"></div>
                        <div className="flex justify-between font-bold text-lg text-gray-800 dark:text-white">
                            <span>الاجمالي النهائي</span>
                            <span>{getInvoiceTotals(selectedInvoice).total.toLocaleString()} ج.م</span>
                        </div>
                         <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-medium pt-1">
                            <span>المبلغ المدفوع</span>
                            <span>{getInvoiceTotals(selectedInvoice).paid.toLocaleString()}</span>
                        </div>
                        {getInvoiceTotals(selectedInvoice).remaining > 0 && (
                            <div className="flex justify-between text-red-600 dark:text-red-400 font-bold pt-1">
                                <span>المبلغ المتبقي (آجل)</span>
                                <span>{getInvoiceTotals(selectedInvoice).remaining.toLocaleString()}</span>
                            </div>
                        )}
                    </div>
                    
                    {/* Pay Button for remaining balance */}
                    {getInvoiceTotals(selectedInvoice).remaining > 0 && (
                        <button 
                            onClick={() => {
                                openPaymentModal(selectedInvoice);
                            }}
                            className={`w-full mt-4 text-white py-3 rounded-xl font-bold flex items-center justify-center shadow-lg transition-colors ${selectedInvoice.type === TransactionType.SALE ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-blue-600 hover:bg-blue-700'}`}
                        >
                            <CreditCard size={20} className="ml-2" />
                            {selectedInvoice.type === TransactionType.SALE ? 'تسجيل دفعة (تحصيل)' : 'تسجيل دفعة (سداد)'}
                        </button>
                    )}

                    {selectedInvoice.notes && (
                        <div className="mt-4 bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-lg border border-yellow-100 dark:border-yellow-900/30 text-xs text-yellow-800 dark:text-yellow-400">
                            <span className="font-bold block mb-1">ملاحظات:</span>
                            {selectedInvoice.notes}
                        </div>
                    )}

                </div>
            </div>
        </div>
      )}

      {/* ... Payment and Delete Modals ... */}
      {isPaymentModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[70] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 shadow-2xl transition-colors">
                <h3 className="font-bold text-lg mb-4 text-center dark:text-white">
                    {editingPaymentRecord ? 'تعديل الدفعة' : (paymentTargetInvoice?.type === TransactionType.PURCHASE ? 'سداد دفعة للمورد' : 'تحصيل دفعة من العميل')}
                </h3>
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">المبلغ المدفوع</label>
                        <input 
                            type="number"
                            value={paymentAmount}
                            onChange={(e) => setPaymentAmount(e.target.value)}
                            className={`w-full p-3 border border-gray-300 dark:border-slate-600 rounded-lg font-bold text-center text-xl outline-none focus:ring-2 bg-white dark:bg-slate-700 text-gray-900 dark:text-white ${paymentTargetInvoice?.type === TransactionType.PURCHASE ? 'text-blue-600 focus:ring-blue-600' : 'text-emerald-600 focus:ring-emerald-600'}`}
                            placeholder="0"
                            autoFocus
                        />
                    </div>
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">تاريخ الدفع</label>
                        <input 
                             type="date"
                             value={paymentDate}
                             onChange={(e) => setPaymentDate(e.target.value)}
                             className="w-full p-3 border border-gray-300 dark:border-slate-600 rounded-lg text-center bg-white dark:bg-slate-700 text-gray-900 dark:text-white"
                             style={{ colorScheme: darkMode ? 'dark' : 'light' }}
                        />
                    </div>
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">ملاحظات (اختياري)</label>
                        <textarea 
                             value={paymentNote}
                             onChange={(e) => setPaymentNote(e.target.value)}
                             className={`w-full p-3 border border-gray-300 dark:border-slate-600 rounded-lg text-right h-20 resize-none outline-none focus:ring-2 bg-white dark:bg-slate-700 text-gray-900 dark:text-white ${paymentTargetInvoice?.type === TransactionType.PURCHASE ? 'focus:ring-blue-600' : 'focus:ring-emerald-600'}`}
                             placeholder="اكتب ملاحظات..."
                        />
                    </div>
                    <div className="flex space-x-3 space-x-reverse pt-2">
                        <button 
                            onClick={handleSubmitPayment}
                            className={`flex-1 text-white py-3 rounded-xl font-bold transition-colors ${paymentTargetInvoice?.type === TransactionType.PURCHASE ? 'bg-blue-600 hover:bg-blue-700' : 'bg-emerald-600 hover:bg-emerald-700'}`}
                        >
                            {editingPaymentRecord ? 'حفظ التعديلات' : 'تأكيد الدفع'}
                        </button>
                        <button 
                            onClick={() => {
                                setIsPaymentModalOpen(false);
                                setPaymentTargetInvoice(null);
                                setEditingPaymentRecord(null);
                            }}
                            className="flex-1 bg-gray-100 dark:bg-slate-600 text-gray-700 dark:text-gray-200 py-3 rounded-xl font-bold hover:bg-gray-200 dark:hover:bg-slate-500"
                        >
                            إلغاء
                        </button>
                    </div>
                </div>
             </div>
        </div>
      )}

      {deleteTarget && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[80] flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 text-center shadow-xl transition-colors">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <AlertTriangle size={32} className="text-red-600 dark:text-red-500" />
                </div>
                <h3 className="font-bold text-lg text-gray-900 dark:text-white mb-2">
                    {deleteTarget.type === 'INVOICE' ? 'حذف الفاتورة؟' : 
                     deleteTarget.type === 'EXPENSE' ? 'حذف المصروف؟' : 'حذف سجل الدفع؟'}
                </h3>
                <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">
                    {deleteTarget.type === 'INVOICE' ? 'هل أنت متأكد من حذف هذه الفاتورة؟ سيتم عكس التأثير المالي وتحديث المخزون.' :
                     deleteTarget.type === 'EXPENSE' ? 'هل أنت متأكد من حذف هذا المصروف؟' :
                     'هل أنت متأكد من حذف هذا السجل؟ سيتم تحديث رصيد الفاتورة والعميل.'}
                </p>
                <div className="flex space-x-3 space-x-reverse">
                    <button 
                        onClick={confirmDelete}
                        className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 rounded-xl font-bold transition-colors shadow-lg"
                    >
                        نعم، حذف
                    </button>
                    <button 
                        onClick={() => setDeleteTarget(null)}
                        className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 py-3 rounded-xl font-bold transition-colors hover:bg-gray-200 dark:hover:bg-slate-600"
                    >
                        إلغاء
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default Invoices;