
import React, { useState, useMemo, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { Settings, TrendingUp, TrendingDown, Package, ArrowDown, ShoppingCart, DollarSign, Moon, Sun, X, LogOut, User, Camera, Edit2, Users, Plus, Trash2, CheckSquare, Square, ChevronLeft, Printer, FileText, PieChart as PieChartIcon, BarChart3, Wallet, ShieldCheck, Lock, Copy, Crown, Zap, Shield, CalendarClock } from 'lucide-react';
import { TransactionType, Permission } from '../types';
import { ALL_PERMISSIONS, FREE_LIMITS } from '../context/StoreContext';
import { useNavigate } from 'react-router-dom';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const PERMISSION_LABELS: Record<string, string> = {
  'DASHBOARD': 'لوحة التحكم والإحصائيات',
  'INVENTORY': 'إدارة المخزون والمنتجات',
  'SALES': 'إدارة المبيعات',
  'PURCHASES': 'إدارة المشتريات',
  'EXPENSES': 'إدارة المصروفات',
  'CONTACTS': 'العملاء والموردين',
  'REPORTS': 'التقارير والإعدادات'
};

const Reports: React.FC = () => {
  const navigate = useNavigate();
  const { 
    transactions, 
    products, 
    contacts, 
    darkMode, 
    toggleDarkMode, 
    hasPin, 
    setAppPin, 
    removeAppPin, 
    unlockApp, 
    logout, 
    currentUser, 
    realUser, 
    storeProfile, 
    updateStoreProfile, 
    partners, 
    addPartner, 
    removePartner, 
    updatePartnerPermissions,
    hasPermission,
    isPro,
    subscriptionDetails // Access subscription details
  } = useStore();
  
  // Check if current user is the owner
  const isOwner = currentUser === realUser;
  const canViewReports = hasPermission('REPORTS');
  const ADMIN_PHONE = '01050011413';

  // Helper to get Local Date String YYYY-MM-DD
  const getLocalDateString = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Initial state: This Month
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(1); // Start of current month
    return getLocalDateString(d);
  });
  
  const [endDate, setEndDate] = useState(() => {
    return getLocalDateString(new Date());
  });

  const [activeFilter, setActiveFilter] = useState<'TODAY' | 'WEEK' | 'MONTH' | 'CUSTOM'>('MONTH');
  
  // Modals State
  const [isSalesDetailModalOpen, setIsSalesDetailModalOpen] = useState(false);
  const [isInventoryAuditModalOpen, setIsInventoryAuditModalOpen] = useState(false);
  const [isSupplierStatsOpen, setIsSupplierStatsOpen] = useState(false);
  const [isMoneyDistOpen, setIsMoneyDistOpen] = useState(false);
  
  // Security Modal State
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [pinMode, setPinMode] = useState<'SETUP' | 'REMOVE'>('SETUP');
  const [pinInput, setPinInput] = useState('');
  const [pinStep, setPinStep] = useState<'ENTER' | 'CONFIRM'>('ENTER');
  const [firstPin, setFirstPin] = useState('');
  const [pinError, setPinError] = useState('');

  // Logout Confirm Modal State
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  // Edit Profile Modal State
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [profileName, setProfileName] = useState(storeProfile.name);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Partner Modal State
  const [isPartnerModalOpen, setIsPartnerModalOpen] = useState(false);
  const [isAddPartnerView, setIsAddPartnerView] = useState(true); // Toggle between List and Add
  const [newPartnerPhone, setNewPartnerPhone] = useState('');
  const [newPartnerName, setNewPartnerName] = useState(''); 
  const [selectedPermissions, setSelectedPermissions] = useState<Permission[]>(ALL_PERMISSIONS);
  const [editingPartnerPhone, setEditingPartnerPhone] = useState<string | null>(null); 
  const [partnerToDelete, setPartnerToDelete] = useState<string | null>(null);

  // Quick Filter Logic
  const setQuickFilter = (type: 'TODAY' | 'WEEK' | 'MONTH') => {
    const end = new Date();
    const start = new Date();

    if (type === 'TODAY') {
        // Start remains today
    } else if (type === 'WEEK') {
        start.setDate(start.getDate() - 7);
    } else if (type === 'MONTH') {
        start.setDate(1);
    }

    setStartDate(getLocalDateString(start));
    setEndDate(getLocalDateString(end));
    setActiveFilter(type);
  };

  // Filter transactions based on date range
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      const tDateObj = new Date(t.date);
      const tDateStr = getLocalDateString(tDateObj);
      return tDateStr >= startDate && tDateStr <= endDate;
    });
  }, [transactions, startDate, endDate]);

  // --- Financial Calculations ---
  const financialStats = useMemo(() => {
      const sales = filteredTransactions
        .filter(t => t.type === TransactionType.SALE)
        .reduce((sum, t) => sum + t.amount, 0);

      const expenses = filteredTransactions
        .filter(t => t.type === TransactionType.EXPENSE)
        .reduce((sum, t) => sum + t.amount, 0);
        
      const purchases = filteredTransactions
        .filter(t => t.type === TransactionType.PURCHASE)
        .reduce((sum, t) => sum + t.amount, 0);

      // Net Profit Calculation
      let grossProfit = 0;
      filteredTransactions.filter(t => t.type === TransactionType.SALE).forEach(sale => {
        if (sale.items && sale.items.length > 0) {
            sale.items.forEach(item => {
                const product = products.find(p => p.id === item.productId);
                const buyPrice = product ? product.buyPrice : 0; 
                grossProfit += (item.price - buyPrice) * item.quantity;
            });
        } else {
            grossProfit += sale.amount; 
        }
        if (sale.discount) grossProfit -= sale.discount;
      });

      const netProfit = grossProfit - expenses;

      return { sales, expenses, purchases, netProfit, salesCount: filteredTransactions.filter(t => t.type === TransactionType.SALE).length };
  }, [filteredTransactions, products]);

  // --- Inventory Valuation ---
  const inventoryStats = useMemo(() => {
      let totalItems = 0;
      let costValue = 0;
      let salesValue = 0;

      const productStats = products.map(p => {
          let estimatedSellPrice = p.sellPrice;
          
          if (estimatedSellPrice === 0) {
              const lastPurchase = transactions.find(t => 
                  t.type === TransactionType.PURCHASE && 
                  t.items?.some(i => i.productId === p.id && i.sellPrice && i.sellPrice > 0)
              );
              
              if (lastPurchase) {
                  const item = lastPurchase.items?.find(i => i.productId === p.id);
                  if (item?.sellPrice) estimatedSellPrice = item.sellPrice;
              } else {
                   const lastSale = transactions.find(t => 
                      t.type === TransactionType.SALE && 
                      t.items?.some(i => i.productId === p.id)
                  );
                  if (lastSale) {
                      const item = lastSale.items?.find(i => i.productId === p.id);
                      if (item?.price) estimatedSellPrice = item.price;
                  }
              }
          }

          const pCost = p.stock * p.buyPrice;
          const pSales = p.stock * estimatedSellPrice;

          totalItems += p.stock;
          costValue += pCost;
          salesValue += pSales;

          return { 
              ...p, 
              estimatedSellPrice, 
              pCost, 
              pSales 
          };
      });

      return { totalItems, costValue, salesValue, productStats };
  }, [products, transactions]);

  // --- Sales Detail Report Data ---
  const salesDetails = useMemo(() => {
      return filteredTransactions
          .filter(t => t.type === TransactionType.SALE)
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [filteredTransactions]);

  // --- Suppliers Purchase Stats ---
  const supplierStats = useMemo(() => {
      const stats: Record<string, number> = {};
      filteredTransactions
          .filter(t => t.type === TransactionType.PURCHASE)
          .forEach(t => {
              const name = t.contactId ? (contacts.find(c => c.id === t.contactId)?.name || 'مورد غير معروف') : 'مورد عام';
              stats[name] = (stats[name] || 0) + t.amount;
          });
      return Object.entries(stats)
          .map(([name, value]) => ({ name, value }))
          .sort((a, b) => b.value - a.value);
  }, [filteredTransactions, contacts]);

  // --- Charts Data ---
  const moneyDistData = [
      { name: 'المشتريات', value: financialStats.purchases, color: '#3b82f6' },
      { name: 'المصاريف', value: financialStats.expenses, color: '#ef4444' },
      { name: 'الأرباح (الصافي)', value: Math.max(0, financialStats.netProfit), color: '#10b981' }
  ].filter(d => d.value > 0);

  // --- Helper Functions ---
  const handlePrint = () => window.print();
  const getContactName = (id?: string) => contacts.find(c => c.id === id)?.name || (id ? 'غير معروف' : 'عميل نقدي');
  
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
        alert('تم نسخ الرقم');
    });
  };

  // --- Settings Logic Handlers ---
  const handlePinDigit = (num: number) => { if (pinInput.length < 4) { setPinInput(prev => prev + num); setPinError(''); } };
  const handlePinDelete = () => setPinInput(prev => prev.slice(0, -1));
  const handlePinSubmit = () => {
      if (pinInput.length !== 4) return;
      if (pinMode === 'REMOVE') {
          if (unlockApp(pinInput)) { removeAppPin(); setIsPinModalOpen(false); setPinInput(''); alert('تم إلغاء القفل'); } 
          else { setPinError('رمز خطأ'); setPinInput(''); }
          return;
      }
      if (pinStep === 'ENTER') { setFirstPin(pinInput); setPinInput(''); setPinStep('CONFIRM'); } 
      else {
          if (pinInput === firstPin) { setAppPin(pinInput); setIsPinModalOpen(false); setPinInput(''); setPinStep('ENTER'); alert('تم تفعيل القفل'); } 
          else { setPinError('الرمز غير متطابق'); setPinInput(''); setFirstPin(''); setPinStep('ENTER'); }
      }
  };
  const openPinModal = (mode: 'SETUP' | 'REMOVE' = 'SETUP') => { setPinMode(mode); setIsPinModalOpen(true); setPinInput(''); setPinStep('ENTER'); setPinError(''); };
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => { updateStoreProfile({ image: reader.result as string }); };
        reader.readAsDataURL(file);
    }
  };
  const handleSaveProfile = () => { updateStoreProfile({ name: profileName }); setIsProfileModalOpen(false); };
  
  // Partner Logic
  const resetPartnerForm = () => { setNewPartnerPhone(''); setNewPartnerName(''); setSelectedPermissions(ALL_PERMISSIONS); setEditingPartnerPhone(null); setIsAddPartnerView(false); };
  const togglePermission = (perm: Permission) => setSelectedPermissions(prev => prev.includes(perm) ? prev.filter(p => p !== perm) : [...prev, perm]);
  const handleAddOrUpdatePartner = () => {
      if (editingPartnerPhone) updatePartnerPermissions(editingPartnerPhone, selectedPermissions);
      else {
          const phone = newPartnerPhone.trim(); const name = newPartnerName.trim() || 'موظف';
          if (phone.length !== 11 || !phone.startsWith('01')) { alert('رقم خطأ'); return; }
          addPartner(name, phone, selectedPermissions);
      }
      resetPartnerForm();
  };
  const handleEditPartner = (partner: any) => { setEditingPartnerPhone(partner.phone); setNewPartnerPhone(partner.phone); setNewPartnerName(partner.name); setSelectedPermissions(partner.permissions); setIsAddPartnerView(true); };
  const handleRemovePartnerRequest = (phone: string) => setPartnerToDelete(phone);
  const executePartnerRemoval = () => { if (partnerToDelete) { removePartner(partnerToDelete); setPartnerToDelete(null); }};


  return (
    <div className="p-4 pb-24 min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors relative">
      <h1 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">
        {canViewReports ? 'التقارير والإعدادات' : 'الإعدادات'}
      </h1>

      {canViewReports && (
        <>
             <div className="bg-white dark:bg-slate-800 p-2 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 mb-6 sticky top-0 z-10">
                <div className="flex bg-gray-100 dark:bg-slate-700 p-1 rounded-lg mb-3">
                    {[ { id: 'TODAY', label: 'اليوم' }, { id: 'WEEK', label: 'أسبوع' }, { id: 'MONTH', label: 'شهر' }, { id: 'CUSTOM', label: 'مخصص' } ].map((filter) => (
                        <button key={filter.id} onClick={() => filter.id !== 'CUSTOM' && setQuickFilter(filter.id as any)} className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${activeFilter === filter.id ? 'bg-white dark:bg-slate-600 text-purple-600 dark:text-purple-400 shadow-sm' : 'text-gray-500 dark:text-gray-400'}`}>{filter.label}</button>
                    ))}
                </div>
                <div className="flex gap-2 items-center text-sm">
                    <div className="flex-1"><label className="text-xs text-gray-400 block mb-1 mr-1">من:</label><input type="date" value={startDate} onChange={(e) => { setStartDate(e.target.value); setActiveFilter('CUSTOM'); }} className="w-full bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-600 rounded-lg p-2 text-center text-gray-800 dark:text-white text-xs outline-none" /></div>
                    <div className="flex-1"><label className="text-xs text-gray-400 block mb-1 mr-1">إلى:</label><input type="date" value={endDate} onChange={(e) => { setEndDate(e.target.value); setActiveFilter('CUSTOM'); }} className="w-full bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-600 rounded-lg p-2 text-center text-gray-800 dark:text-white text-xs outline-none" /></div>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-xl border border-emerald-100 dark:border-emerald-900/30">
                    <div className="flex items-center gap-2 mb-2"><div className="p-1.5 bg-emerald-200 dark:bg-emerald-800 rounded-lg text-emerald-800 dark:text-emerald-100"><TrendingUp size={16} /></div><span className="text-xs font-bold text-emerald-800 dark:text-emerald-400">المبيعات</span></div>
                    <p className="text-lg font-black text-gray-800 dark:text-white">{financialStats.sales.toLocaleString()}</p>
                    <p className="text-[10px] text-gray-500 dark:text-gray-400">{financialStats.salesCount} عملية بيع</p>
                </div>
                <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-xl border border-purple-100 dark:border-purple-900/30">
                    <div className="flex items-center gap-2 mb-2"><div className="p-1.5 bg-purple-200 dark:bg-purple-800 rounded-lg text-purple-800 dark:text-purple-100"><DollarSign size={16} /></div><span className="text-xs font-bold text-purple-800 dark:text-purple-400">صافي الربح</span></div>
                    <p className="text-lg font-black text-gray-800 dark:text-white">{financialStats.netProfit.toLocaleString()}</p>
                    <p className="text-[10px] text-gray-500 dark:text-gray-400">بعد خصم المصروفات</p>
                </div>
                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl border border-blue-100 dark:border-blue-900/30">
                    <div className="flex items-center gap-2 mb-2"><div className="p-1.5 bg-blue-200 dark:bg-blue-800 rounded-lg text-blue-800 dark:text-blue-100"><ShoppingCart size={16} /></div><span className="text-xs font-bold text-blue-800 dark:text-blue-400">المشتريات</span></div>
                    <p className="text-lg font-black text-gray-800 dark:text-white">{financialStats.purchases.toLocaleString()}</p>
                </div>
                <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-xl border border-red-100 dark:border-red-900/30">
                    <div className="flex items-center gap-2 mb-2"><div className="p-1.5 bg-red-200 dark:bg-red-800 rounded-lg text-red-800 dark:text-red-100"><TrendingDown size={16} /></div><span className="text-xs font-bold text-red-800 dark:text-red-400">المصروفات</span></div>
                    <p className="text-lg font-black text-gray-800 dark:text-white">{financialStats.expenses.toLocaleString()}</p>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 mb-6">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-gray-800 dark:text-white flex items-center gap-2"><Package className="text-orange-500" size={20} />تقرير المخزون (الجرد)</h3>
                    <button onClick={() => setIsInventoryAuditModalOpen(true)} className="text-xs bg-orange-50 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400 px-3 py-1.5 rounded-lg font-bold hover:bg-orange-100 dark:hover:bg-orange-900/50 transition-colors">عرض التفاصيل</button>
                </div>
                <div className="flex justify-between items-center text-sm">
                    <div><p className="text-gray-500 dark:text-gray-400 text-xs">قيمة البضاعة (شراء)</p><p className="font-bold text-gray-900 dark:text-white text-lg">{inventoryStats.costValue.toLocaleString()} ج.م</p></div>
                    <div className="h-8 w-px bg-gray-200 dark:bg-slate-600"></div>
                    <div><p className="text-gray-500 dark:text-gray-400 text-xs">قيمة البضاعة (بيع)</p><p className="font-bold text-emerald-600 dark:text-emerald-400 text-lg">{inventoryStats.salesValue.toLocaleString()} ج.م</p></div>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-3 mb-8">
                <button onClick={() => setIsSalesDetailModalOpen(true)} className="w-full bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors">
                    <div className="flex items-center gap-3"><div className="bg-indigo-50 dark:bg-indigo-900/30 p-2 rounded-lg text-indigo-600 dark:text-indigo-400"><FileText size={20} /></div><div className="text-right"><span className="font-bold text-gray-800 dark:text-white block">تقرير مبيعات مفصل</span><span className="text-xs text-gray-500 dark:text-gray-400">جدول بجميع العمليات للفترة المحددة</span></div></div><ChevronLeft size={20} className="text-gray-400" />
                </button>
                <button onClick={() => setIsSupplierStatsOpen(true)} className="w-full bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors">
                    <div className="flex items-center gap-3"><div className="bg-blue-50 dark:bg-blue-900/30 p-2 rounded-lg text-blue-600 dark:text-blue-400"><BarChart3 size={20} /></div><div className="text-right"><span className="font-bold text-gray-800 dark:text-white block">المشتريات حسب المورد</span><span className="text-xs text-gray-500 dark:text-gray-400">توزيع المشتريات على الموردين</span></div></div><ChevronLeft size={20} className="text-gray-400" />
                </button>
                <button onClick={() => setIsMoneyDistOpen(true)} className="w-full bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors">
                    <div className="flex items-center gap-3"><div className="bg-teal-50 dark:bg-teal-900/30 p-2 rounded-lg text-teal-600 dark:text-teal-400"><PieChartIcon size={20} /></div><div className="text-right"><span className="font-bold text-gray-800 dark:text-white block">توزيع الأموال</span><span className="text-xs text-gray-500 dark:text-gray-400">تحليل المصروفات والدخل (Charts)</span></div></div><ChevronLeft size={20} className="text-gray-400" />
                </button>
            </div>
            <div className="border-t border-gray-200 dark:border-slate-700 my-6"></div>
        </>
      )}

      {/* --- SETTINGS HEADER --- */}
      <div className="mb-4">
        <h2 className="text-lg font-bold text-gray-800 dark:text-white flex items-center gap-2">
            <Settings size={20} className="text-gray-500" />
            إعدادات النظام
        </h2>
      </div>

      {/* Settings Section */}
      <div className="space-y-3">
        {/* Account Card (Store Profile) */}
        <div className="bg-gradient-to-l from-slate-700 to-slate-800 rounded-xl p-4 shadow-lg mb-4 text-white flex justify-between items-center relative overflow-hidden">
            <div className="flex items-center relative z-10">
                <div className="bg-white/20 p-1 rounded-full ml-3 w-14 h-14 flex items-center justify-center overflow-hidden border-2 border-white/30">
                    {storeProfile.image ? (
                        <img src={storeProfile.image} alt="Logo" className="w-full h-full object-cover rounded-full" />
                    ) : (
                        <User size={28} />
                    )}
                </div>
                <div>
                    <p className="text-xs text-slate-300 mb-0.5">الحساب الحالي</p>
                    <p className="font-bold text-lg leading-tight">{storeProfile.name}</p>
                    {/* ID Display */}
                    {storeProfile.id && (
                        <div className="flex items-center gap-2 mt-1 bg-black/20 px-2 py-0.5 rounded-md w-fit">
                            <p className="text-[10px] text-slate-300 font-mono tracking-wider">ID: {storeProfile.id}</p>
                            <button 
                                onClick={() => copyToClipboard(storeProfile.id || '')}
                                className="text-slate-400 hover:text-white transition-colors"
                            >
                                <Copy size={10} />
                            </button>
                        </div>
                    )}
                </div>
            </div>
            {isOwner && (
                <button 
                    onClick={() => {
                        setProfileName(storeProfile.name);
                        setIsProfileModalOpen(true);
                    }}
                    className="p-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors relative z-10"
                >
                    <Edit2 size={18} />
                </button>
            )}
        </div>

        {/* --- SUBSCRIPTION CARD --- */}
        {isOwner && (
             <div className={`p-4 rounded-xl shadow-sm border mb-4 relative overflow-hidden ${isPro ? 'bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border-amber-200 dark:border-amber-800' : 'bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700'}`}>
                <div className="flex justify-between items-start mb-3 relative z-10">
                    <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-full ${isPro ? 'bg-amber-400 text-white' : 'bg-gray-200 dark:bg-slate-600 text-gray-500'}`}>
                            {isPro ? <Crown size={24} fill="currentColor" /> : <Lock size={24} />}
                        </div>
                        <div>
                            <h3 className="font-bold text-gray-800 dark:text-white">{isPro ? 'النسخة الكاملة (Pro)' : 'النسخة المجانية'}</h3>
                            <p className="text-xs text-gray-500 dark:text-gray-400">{isPro ? 'جميع الخصائص مفعلة' : 'ترقية الحساب للحصول على ميزات إضافية'}</p>
                        </div>
                    </div>
                     {/* Secret Admin Button - Only for Specific Phone Number */}
                     {realUser === ADMIN_PHONE && (
                         <button 
                            onClick={() => navigate('/admin-panel')}
                            className="text-gray-300 hover:text-red-500 p-2 transition-colors"
                            title="لوحة الأدمن"
                         >
                             <Shield size={16} />
                         </button>
                     )}
                </div>

                {!isPro && (
                    <div className="space-y-3 relative z-10">
                         {/* Limits Progress */}
                         <div className="space-y-2 text-xs">
                             <div>
                                 <div className="flex justify-between mb-1">
                                     <span className="text-gray-600 dark:text-gray-300">المنتجات ({products.length}/{FREE_LIMITS.PRODUCTS})</span>
                                     <span className="text-gray-400">{Math.round((products.length/FREE_LIMITS.PRODUCTS)*100)}%</span>
                                 </div>
                                 <div className="h-1.5 w-full bg-gray-100 dark:bg-slate-700 rounded-full overflow-hidden">
                                     <div className="h-full bg-blue-500 rounded-full" style={{ width: `${Math.min(100, (products.length/FREE_LIMITS.PRODUCTS)*100)}%` }}></div>
                                 </div>
                             </div>
                             <div>
                                 <div className="flex justify-between mb-1">
                                     <span className="text-gray-600 dark:text-gray-300">العمليات ({transactions.length}/{FREE_LIMITS.TRANSACTIONS})</span>
                                     <span className="text-gray-400">{Math.round((transactions.length/FREE_LIMITS.TRANSACTIONS)*100)}%</span>
                                 </div>
                                 <div className="h-1.5 w-full bg-gray-100 dark:bg-slate-700 rounded-full overflow-hidden">
                                     <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${Math.min(100, (transactions.length/FREE_LIMITS.TRANSACTIONS)*100)}%` }}></div>
                                 </div>
                             </div>
                         </div>
                         <div className="text-xs text-gray-500 mt-2">
                             يرجى التواصل مع الإدارة لتفعيل الحساب باستخدام الرقم: <span className="font-mono bg-gray-100 dark:bg-slate-700 px-1 rounded font-bold">{storeProfile.id}</span>
                         </div>
                    </div>
                )}
                
                {isPro && subscriptionDetails && (
                    <div className="space-y-2 relative z-10">
                        <div className="mt-2 text-xs text-amber-700 dark:text-amber-400 flex items-center gap-1 bg-amber-100 dark:bg-amber-900/30 p-2 rounded-lg">
                            <Zap size={12} fill="currentColor" />
                            <span>حسابك مفعل بالكامل. شكراً لاستخدامك النسخة المدفوعة!</span>
                        </div>
                        <div className="text-xs text-gray-600 dark:text-gray-400 bg-white/50 dark:bg-black/20 p-2 rounded-lg flex items-center gap-2">
                            <CalendarClock size={14} className="text-amber-500" />
                            <span>ينتهي الاشتراك في: <span className="font-bold text-gray-800 dark:text-white font-mono">{new Date(subscriptionDetails.endDate).toLocaleDateString('ar-EG')}</span></span>
                        </div>
                    </div>
                )}
             </div>
        )}

        {/* ... Rest of Settings Buttons (Dark Mode, Partners, Pin, Logout) ... */}
        <button 
            onClick={toggleDarkMode}
            className="w-full bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex items-center justify-between text-gray-700 dark:text-gray-200 transition-colors hover:bg-gray-50 dark:hover:bg-slate-700"
        >
            <div className="flex items-center">
                <div className="bg-purple-100 dark:bg-purple-900/40 p-2 rounded-lg ml-3">
                    {darkMode ? <Moon className="text-purple-500" size={18} /> : <Sun className="text-orange-500" size={18} />}
                </div>
                <span className="font-medium">الوضع الليلي</span>
            </div>
            <div className={`w-12 h-6 rounded-full p-1 transition-colors ${darkMode ? 'bg-primary' : 'bg-gray-300'}`}>
                <div className={`w-4 h-4 bg-white rounded-full shadow-md transform transition-transform ${darkMode ? '-translate-x-6' : '-translate-x-0'}`}></div>
            </div>
        </button>

        {isOwner && (
            <button 
                onClick={() => {
                    setIsPartnerModalOpen(true);
                    setIsAddPartnerView(false);
                }}
                className="w-full bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex items-center justify-between text-gray-700 dark:text-gray-200 transition-colors hover:bg-gray-50 dark:hover:bg-slate-700"
            >
                <div className="flex items-center">
                    <div className="bg-blue-100 dark:bg-blue-900/40 p-2 rounded-lg ml-3">
                        <Users className="text-blue-500" size={18} />
                    </div>
                    <div className="text-right">
                        <span className="font-medium block">إدارة الشركاء والموظفين</span>
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                            {partners.length > 0 ? `${partners.length} أرقام مرتبطة بالحساب` : 'إضافة أرقام للوصول للبيانات'}
                        </span>
                    </div>
                </div>
            </button>
        )}

        <button 
            onClick={() => openPinModal('SETUP')}
            className="w-full bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex items-center justify-between text-gray-700 dark:text-gray-200 transition-colors hover:bg-gray-50 dark:hover:bg-slate-700"
        >
            <div className="flex items-center">
                <div className={`p-2 rounded-lg ml-3 ${hasPin ? 'bg-emerald-100 dark:bg-emerald-900/40' : 'bg-gray-100 dark:bg-slate-700'}`}>
                    {hasPin ? <ShieldCheck className="text-emerald-500" size={18} /> : <Lock className="text-gray-500 dark:text-gray-300" size={18} />}
                </div>
                <div className="text-right">
                    <span className="font-medium block">{hasPin ? 'تغيير رمز القفل' : 'تفعيل قفل التطبيق'}</span>
                </div>
            </div>
        </button>

        {hasPin && (
            <button 
                onClick={() => openPinModal('REMOVE')}
                className="w-full bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 flex items-center justify-between text-gray-700 dark:text-gray-200 transition-colors hover:bg-gray-50 dark:hover:bg-slate-700"
            >
                <div className="flex items-center">
                    <div className="bg-red-50 dark:bg-red-900/30 p-2 rounded-lg ml-3">
                        <Lock className="text-red-500" size={18} />
                    </div>
                    <span className="font-medium">إلغاء قفل الأمان</span>
                </div>
            </button>
        )}

        <button 
            onClick={() => setShowLogoutConfirm(true)}
            className="w-full bg-red-50 dark:bg-red-900/10 p-4 rounded-xl shadow-sm border border-red-100 dark:border-red-900/30 flex items-center justify-center text-red-600 dark:text-red-400 transition-colors hover:bg-red-100 dark:hover:bg-red-900/20 mt-4"
        >
            <LogOut size={20} className="ml-2" />
            <span className="font-bold">تسجيل الخروج</span>
        </button>
      </div>

      {/* --- DETAILED SALES REPORT MODAL --- */}
      {isSalesDetailModalOpen && canViewReports && (
         <div className="fixed inset-0 bg-black bg-opacity-60 z-[100] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-2xl flex flex-col max-h-[90vh] shadow-2xl overflow-hidden">
                <div className="p-4 border-b border-gray-200 dark:border-slate-700 flex justify-between items-center bg-gray-50 dark:bg-slate-900">
                    <h3 className="font-bold text-lg dark:text-white">تقرير المبيعات المفصل</h3>
                    <div className="flex gap-2">
                        <button onClick={handlePrint} className="p-2 bg-white dark:bg-slate-700 rounded-lg shadow-sm hover:bg-gray-100 dark:hover:bg-slate-600 text-gray-700 dark:text-gray-200"><Printer size={18} /></button>
                        <button onClick={() => setIsSalesDetailModalOpen(false)} className="p-2 bg-white dark:bg-slate-700 rounded-lg shadow-sm hover:bg-gray-100 dark:hover:bg-slate-600 text-gray-700 dark:text-gray-200"><X size={18} /></button>
                    </div>
                </div>
                <div className="p-4 overflow-y-auto no-scrollbar relative">
                    <div id="printable-receipt" className="hidden">
                        <div className="text-center mb-4 border-b-2 border-black pb-2">
                            <h2 className="text-xl font-bold">{storeProfile.name}</h2>
                            <p className="text-sm">تقرير مبيعات مفصل</p>
                            <p className="text-xs">من {startDate} إلى {endDate}</p>
                        </div>
                        <table className="w-full text-xs border-collapse">
                            <thead><tr className="border-b border-black"><th className="text-right py-1">التاريخ</th><th className="text-right py-1">الفاتورة</th><th className="text-right py-1">العميل</th><th className="text-left py-1">الاجمالي</th></tr></thead>
                            <tbody>{salesDetails.map(t => (<tr key={t.id} className="border-b border-gray-300"><td className="py-2">{new Date(t.date).toLocaleDateString('ar-EG')}</td><td className="py-2">#{t.id.slice(-4)}</td><td className="py-2">{getContactName(t.contactId)}</td><td className="py-2 font-bold text-left">{t.amount.toLocaleString()}</td></tr>))}</tbody>
                        </table>
                        <div className="mt-4 border-t-2 border-black pt-2 flex justify-between font-bold"><span>اجمالي المبيعات:</span><span>{financialStats.sales.toLocaleString()} ج.م</span></div>
                    </div>
                    <p className="text-sm text-gray-500 mb-4 text-center">الفترة: من {startDate} إلى {endDate}</p>
                    {salesDetails.length > 0 ? (<div className="space-y-3">{salesDetails.map(t => (<div key={t.id} className="bg-gray-50 dark:bg-slate-700 p-3 rounded-lg border border-gray-100 dark:border-slate-600 text-sm"><div className="flex justify-between items-start mb-2"><div><span className="font-bold text-gray-800 dark:text-white block">#{t.id.slice(-4)} - {getContactName(t.contactId)}</span><span className="text-xs text-gray-500 dark:text-gray-400">{new Date(t.date).toLocaleDateString('ar-EG')}</span></div><span className="font-bold text-emerald-600 dark:text-emerald-400">{t.amount.toLocaleString()} ج.م</span></div></div>))}</div>) : (<p className="text-center text-gray-400 py-10">لا توجد مبيعات في هذه الفترة</p>)}
                </div>
             </div>
         </div>
      )}

      {/* --- INVENTORY AUDIT MODAL --- */}
      {isInventoryAuditModalOpen && canViewReports && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[100] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-2xl rounded-2xl flex flex-col max-h-[90vh] shadow-2xl overflow-hidden">
                <div className="p-4 border-b border-gray-200 dark:border-slate-700 flex justify-between items-center bg-gray-50 dark:bg-slate-900">
                    <h3 className="font-bold text-lg dark:text-white flex items-center gap-2">
                        <Package className="text-orange-500" size={20} />
                        تقرير المخزون (الجرد)
                    </h3>
                    <div className="flex gap-2">
                        <button onClick={handlePrint} className="p-2 bg-white dark:bg-slate-700 rounded-lg shadow-sm hover:bg-gray-100 dark:hover:bg-slate-600 text-gray-700 dark:text-gray-200"><Printer size={18} /></button>
                        <button onClick={() => setIsInventoryAuditModalOpen(false)} className="p-2 bg-white dark:bg-slate-700 rounded-lg shadow-sm hover:bg-gray-100 dark:hover:bg-slate-600 text-gray-700 dark:text-gray-200"><X size={18} /></button>
                    </div>
                </div>
                
                <div className="p-4 overflow-y-auto no-scrollbar">
                     <div className="grid grid-cols-2 gap-3 mb-4">
                         <div className="bg-gray-50 dark:bg-slate-700 p-3 rounded-xl border border-gray-100 dark:border-slate-600">
                             <p className="text-xs text-gray-500 dark:text-gray-400">إجمالي التكلفة (رأس المال)</p>
                             <p className="text-lg font-bold text-gray-900 dark:text-white">{inventoryStats.costValue.toLocaleString()} ج.م</p>
                         </div>
                         <div className="bg-gray-50 dark:bg-slate-700 p-3 rounded-xl border border-gray-100 dark:border-slate-600">
                             <p className="text-xs text-gray-500 dark:text-gray-400">إجمالي القيمة البيعية (المتوقعة)</p>
                             <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{inventoryStats.salesValue.toLocaleString()} ج.م</p>
                         </div>
                     </div>
                     
                     <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-gray-300">
                                <tr>
                                    <th className="p-2 text-right rounded-r-lg">المنتج</th>
                                    <th className="p-2 text-center">الكمية</th>
                                    <th className="p-2 text-center">التكلفة</th>
                                    <th className="p-2 text-center">بيع (تقديري)</th>
                                    <th className="p-2 text-center rounded-l-lg">القيمة</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 dark:divide-slate-700">
                                {inventoryStats.productStats.map(p => (
                                    <tr key={p.id} className="hover:bg-gray-50 dark:hover:bg-slate-800">
                                        <td className="p-2 font-medium text-gray-800 dark:text-white">{p.name}</td>
                                        <td className="p-2 text-center font-bold">{p.stock}</td>
                                        <td className="p-2 text-center text-gray-500 dark:text-gray-400">{p.buyPrice}</td>
                                        <td className="p-2 text-center text-gray-500 dark:text-gray-400">{p.estimatedSellPrice}</td>
                                        <td className="p-2 text-center font-bold text-emerald-600 dark:text-emerald-400">{p.pSales.toLocaleString()}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                     </div>
                </div>
             </div>
        </div>
      )}

      {/* --- SUPPLIER STATS MODAL --- */}
      {isSupplierStatsOpen && canViewReports && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[100] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-2xl flex flex-col max-h-[90vh] shadow-2xl overflow-hidden">
                <div className="p-4 border-b border-gray-200 dark:border-slate-700 flex justify-between items-center bg-gray-50 dark:bg-slate-900">
                    <h3 className="font-bold text-lg dark:text-white flex items-center gap-2">
                         <BarChart3 className="text-blue-500" size={20} />
                         إحصائيات الموردين
                    </h3>
                    <button onClick={() => setIsSupplierStatsOpen(false)} className="p-2 bg-white dark:bg-slate-700 rounded-lg shadow-sm hover:bg-gray-100 dark:hover:bg-slate-600 text-gray-700 dark:text-gray-200"><X size={18} /></button>
                </div>
                
                <div className="p-4 h-96">
                    {supplierStats.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={supplierStats.slice(0, 10)} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                                <XAxis type="number" hide />
                                <YAxis dataKey="name" type="category" width={80} tick={{fill: darkMode ? '#cbd5e1' : '#475569', fontSize: 10}} />
                                <Tooltip 
                                    cursor={{fill: 'transparent'}}
                                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                                />
                                <Bar dataKey="value" fill="#3b82f6" radius={[0, 4, 4, 0]} barSize={20} />
                            </BarChart>
                        </ResponsiveContainer>
                    ) : (
                        <div className="flex items-center justify-center h-full text-gray-400">
                            لا توجد بيانات مشتريات
                        </div>
                    )}
                </div>
                <div className="p-4 border-t border-gray-100 dark:border-slate-700 bg-gray-50 dark:bg-slate-900">
                    <p className="text-xs text-center text-gray-500">* يعرض أعلى 10 موردين من حيث حجم التعامل</p>
                </div>
             </div>
        </div>
      )}

      {/* --- MONEY DISTRIBUTION MODAL --- */}
      {isMoneyDistOpen && canViewReports && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[100] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-2xl flex flex-col max-h-[90vh] shadow-2xl overflow-hidden">
                <div className="p-4 border-b border-gray-200 dark:border-slate-700 flex justify-between items-center bg-gray-50 dark:bg-slate-900">
                    <h3 className="font-bold text-lg dark:text-white flex items-center gap-2">
                         <PieChartIcon className="text-teal-500" size={20} />
                         توزيع الأموال
                    </h3>
                    <button onClick={() => setIsMoneyDistOpen(false)} className="p-2 bg-white dark:bg-slate-700 rounded-lg shadow-sm hover:bg-gray-100 dark:hover:bg-slate-600 text-gray-700 dark:text-gray-200"><X size={18} /></button>
                </div>
                
                <div className="p-4 h-80">
                     {moneyDistData.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={moneyDistData}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={80}
                                    paddingAngle={5}
                                    dataKey="value"
                                >
                                    {moneyDistData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.color} />
                                    ))}
                                </Pie>
                                <Tooltip />
                                <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                     ) : (
                        <div className="flex items-center justify-center h-full text-gray-400">
                            لا توجد بيانات مالية كافية
                        </div>
                     )}
                </div>
                
                <div className="p-4 grid grid-cols-3 gap-2 border-t border-gray-100 dark:border-slate-700">
                    {moneyDistData.map((item, idx) => (
                        <div key={idx} className="text-center p-2 rounded-lg bg-gray-50 dark:bg-slate-700">
                            <div className="w-3 h-3 rounded-full mx-auto mb-1" style={{ backgroundColor: item.color }}></div>
                            <p className="text-[10px] text-gray-500 dark:text-gray-400">{item.name}</p>
                            <p className="font-bold text-gray-800 dark:text-white text-xs">{item.value.toLocaleString()}</p>
                        </div>
                    ))}
                </div>
             </div>
        </div>
      )}

      {/* --- PIN MODAL --- */}
      {isPinModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[70] flex items-center justify-center p-6 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 shadow-2xl transition-colors">
                <div className="text-center mb-6"><div className="w-16 h-16 bg-emerald-50 dark:bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4"><Wallet size={32} className="text-emerald-600 dark:text-emerald-400" /></div><h3 className="font-bold text-lg text-gray-800 dark:text-white mb-2">{pinMode === 'REMOVE' ? 'إلغاء قفل الأمان' : (pinStep === 'ENTER' ? 'تعيين رمز مرور جديد' : 'تأكيد رمز المرور')}</h3></div>
                <div className="flex justify-center gap-4 mb-8">{[0, 1, 2, 3].map(i => (<div key={i} className={`w-4 h-4 rounded-full transition-all ${i < pinInput.length ? 'bg-emerald-500 scale-110' : 'bg-gray-200 dark:bg-slate-600'}`} />))}</div>
                {pinError && <p className="text-red-500 text-center text-sm font-bold mb-4 animate-pulse">{pinError}</p>}
                <div className="grid grid-cols-3 gap-4" dir="ltr">{[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (<button key={num} onClick={() => handlePinDigit(num)} className="w-16 h-16 rounded-full bg-gray-100 dark:bg-slate-700 text-gray-800 dark:text-white font-bold text-xl hover:bg-gray-200 dark:hover:bg-slate-600 mx-auto">{num}</button>))}<div className="col-start-2"><button onClick={() => handlePinDigit(0)} className="w-16 h-16 rounded-full bg-gray-100 dark:bg-slate-700 text-gray-800 dark:text-white font-bold text-xl hover:bg-gray-200 dark:hover:bg-slate-600 mx-auto">0</button></div><div className="col-start-3 flex items-center justify-center"><button onClick={handlePinDelete} className="w-16 h-16 rounded-full bg-transparent text-gray-500 hover:text-red-500 flex items-center justify-center mx-auto"><ArrowDown className="rotate-90" size={24} /></button></div></div>
                <div className="flex gap-3 mt-6"><button onClick={handlePinSubmit} disabled={pinInput.length !== 4} className={`flex-1 py-3 rounded-xl font-bold text-white transition-colors ${pinInput.length === 4 ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-gray-300 dark:bg-slate-600 cursor-not-allowed'}`}>{pinStep === 'CONFIRM' ? 'تأكيد' : 'متابعة'}</button><button onClick={() => setIsPinModalOpen(false)} className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-200 py-3 rounded-xl font-bold">إلغاء</button></div>
             </div>
        </div>
      )}

      {/* --- PROFILE MODAL --- */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[70] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 shadow-2xl transition-colors">
                <div className="flex justify-between items-center mb-6 border-b border-gray-100 dark:border-slate-700 pb-4"><h3 className="font-bold text-lg text-gray-800 dark:text-white">تعديل الملف الشخصي</h3><button onClick={() => setIsProfileModalOpen(false)} className="bg-gray-100 dark:bg-slate-700 p-1 rounded-full text-gray-500 dark:text-gray-300"><X size={20} /></button></div>
                <div className="flex flex-col items-center mb-6"><div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}><div className="w-24 h-24 rounded-full bg-gray-100 dark:bg-slate-700 flex items-center justify-center overflow-hidden border-4 border-white dark:border-slate-600 shadow-lg">{storeProfile.image ? (<img src={storeProfile.image} alt="Profile" className="w-full h-full object-cover" />) : (<User size={40} className="text-gray-400" />)}</div><div className="absolute inset-0 bg-black/30 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><Camera className="text-white" size={24} /></div></div><input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} /><p className="text-xs text-gray-500 mt-2">اضغط على الصورة للتغيير</p></div>
                <div className="space-y-4"><div><label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1">اسم المتجر / النشاط</label><input type="text" value={profileName} onChange={(e) => setProfileName(e.target.value)} className="w-full p-3 border border-gray-200 dark:border-slate-700 rounded-lg bg-gray-50 dark:bg-slate-900 text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500 text-center font-bold" placeholder="اسم متجرك" /></div><button onClick={handleSaveProfile} className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-lg transition-colors">حفظ التعديلات</button></div>
             </div>
        </div>
      )}

       {/* --- PARTNERS MANAGEMENT MODAL (Only for Owner) --- */}
      {isPartnerModalOpen && isOwner && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[90] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 shadow-2xl transition-colors max-h-[90vh] overflow-y-auto no-scrollbar">
                <div className="flex justify-between items-center mb-6 border-b border-gray-100 dark:border-slate-700 pb-4">
                    <div><h3 className="font-bold text-lg text-gray-800 dark:text-white">الشركاء والموظفين</h3><p className="text-xs text-gray-500 dark:text-gray-400">إدارة الصلاحيات والوصول</p></div>
                    <button onClick={() => setIsPartnerModalOpen(false)} className="bg-gray-100 dark:bg-slate-700 p-1 rounded-full text-gray-500 dark:text-gray-300"><X size={20} /></button>
                </div>
                {isAddPartnerView ? (
                    <div className="space-y-4">
                        <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl space-y-3">
                             <div><label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">اسم الموظف / الشريك</label><input type="text" value={newPartnerName} onChange={(e) => setNewPartnerName(e.target.value)} className="w-full p-3 border border-blue-200 dark:border-blue-800 rounded-lg bg-white dark:bg-slate-800 text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 text-right" placeholder="مثال: أحمد محمد" /></div>
                             <div><label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">{editingPartnerPhone ? 'رقم الهاتف (لا يمكن تعديله)' : 'رقم الهاتف'}</label><input type="tel" value={newPartnerPhone} disabled={!!editingPartnerPhone} onChange={(e) => {const val = e.target.value.replace(/\D/g, '').slice(0, 11); setNewPartnerPhone(val);}} className={`w-full p-3 border border-blue-200 dark:border-blue-800 rounded-lg bg-white dark:bg-slate-800 text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 text-center font-mono ${editingPartnerPhone ? 'opacity-70 cursor-not-allowed' : ''}`} placeholder="01xxxxxxxxx" /></div>
                        </div>
                        <div className="space-y-2"><p className="font-bold text-sm text-gray-700 dark:text-gray-300 mb-2">تحديد الصلاحيات:</p>{ALL_PERMISSIONS.map(perm => (<button key={perm} onClick={() => togglePermission(perm)} className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all ${selectedPermissions.includes(perm) ? 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800' : 'bg-gray-50 dark:bg-slate-800 border-gray-100 dark:border-slate-700 opacity-60'}`}><span className={`text-sm font-medium ${selectedPermissions.includes(perm) ? 'text-emerald-700 dark:text-emerald-400' : 'text-gray-500 dark:text-gray-400'}`}>{PERMISSION_LABELS[perm] || perm}</span>{selectedPermissions.includes(perm) ? <CheckSquare className="text-emerald-600 dark:text-emerald-400" size={20} /> : <Square className="text-gray-400" size={20} />}</button>))}</div>
                        <div className="flex gap-3 pt-2"><button onClick={handleAddOrUpdatePartner} disabled={newPartnerPhone.length !== 11} className={`flex-1 py-3 rounded-xl font-bold text-white transition-colors ${newPartnerPhone.length === 11 ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-400 cursor-not-allowed'}`}>{editingPartnerPhone ? 'حفظ الصلاحيات' : 'إضافة'}</button><button onClick={() => { setIsAddPartnerView(false); setNewPartnerPhone(''); setNewPartnerName(''); setEditingPartnerPhone(null); setSelectedPermissions(ALL_PERMISSIONS);}} className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-gray-300 py-3 rounded-xl font-bold">إلغاء</button></div>
                    </div>
                ) : (
                    <>
                        <div className="mb-6 space-y-3">
                            <div className="flex justify-between items-center mb-2"><p className="text-xs font-bold text-gray-500 dark:text-gray-400">القائمة الحالية</p><button onClick={() => { setIsAddPartnerView(true); setNewPartnerPhone(''); setNewPartnerName(''); setSelectedPermissions(ALL_PERMISSIONS);}} className="text-xs text-blue-600 dark:text-blue-400 font-bold flex items-center"><Plus size={14} className="ml-1"/>إضافة جديد</button></div>
                            {partners.length > 0 ? (partners.map(partner => (<div key={partner.phone} className="bg-gray-50 dark:bg-slate-700 p-3 rounded-lg border border-gray-100 dark:border-slate-600"><div className="flex justify-between items-center mb-2"><div className="flex items-center"><div className="bg-white dark:bg-slate-600 p-2 rounded-full ml-3 text-gray-500 dark:text-gray-300"><User size={16} /></div><div><span className="block font-bold text-gray-800 dark:text-white text-sm">{partner.name}</span><span className="text-xs text-gray-500 dark:text-gray-400 font-mono">{partner.phone}</span></div></div><div className="flex gap-2"><button onClick={() => handleEditPartner(partner)} className="p-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-lg"><Edit2 size={16} /></button><button onClick={() => handleRemovePartnerRequest(partner.phone)} className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 p-2 rounded-lg transition-colors"><Trash2 size={16} /></button></div></div></div>))) : (<p className="text-center text-gray-400 text-sm py-4 border-2 border-dashed border-gray-100 dark:border-slate-700 rounded-xl">لا يوجد شركاء مضافين حالياً</p>)}
                        </div>
                    </>
                )}
            </div>
        </div>
      )}

      {/* --- LOGOUT CONFIRM MODAL --- */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[70] flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 text-center shadow-xl transition-colors">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4"><LogOut size={32} className="text-red-600 dark:text-red-500" /></div>
                <h3 className="font-bold text-lg text-gray-900 dark:text-white mb-2">تسجيل الخروج؟</h3>
                <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">هل أنت متأكد من رغبتك في تسجيل الخروج؟ بياناتك آمنة ومرتبطة برقم هاتفك.</p>
                <div className="flex space-x-3 space-x-reverse">
                    <button onClick={() => { logout(); setShowLogoutConfirm(false); }} className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 rounded-xl font-bold transition-colors shadow-lg">خروج</button>
                    <button onClick={() => setShowLogoutConfirm(false)} className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 py-3 rounded-xl font-bold transition-colors hover:bg-gray-200 dark:hover:bg-slate-600">إلغاء</button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default Reports;
