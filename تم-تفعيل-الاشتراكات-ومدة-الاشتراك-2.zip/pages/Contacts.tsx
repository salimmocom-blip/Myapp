
import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Contact, TransactionType, PaymentMethod, Transaction, PaymentRecord } from '../types';
import { User, Phone, Plus, Trash2, Wallet, FileText, X, Calendar, ArrowUpRight, ArrowDownLeft, Banknote, History, Receipt, Edit, CheckCircle, ShoppingBag, CreditCard, ChevronDown, AlertTriangle, Search, Copy } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Contacts: React.FC = () => {
  const navigate = useNavigate();
  const { contacts, addContact, deleteContact, transactions, addTransaction, deleteTransaction, updateTransaction, partners, realUser, currentUser, storeProfile } = useStore();
  const [activeTab, setActiveTab] = useState<'CLIENT' | 'SUPPLIER'>('CLIENT');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [viewingContact, setViewingContact] = useState<Contact | null>(null);
  const [viewingInvoice, setViewingInvoice] = useState<Transaction | null>(null); // NEW: Local Invoice View
  
  // History Tab State (Invoices vs Payments)
  const [historyTab, setHistoryTab] = useState<'INVOICES' | 'PAYMENTS'>('INVOICES');

  // Payment Modal State (General & Invoice Specific)
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentType, setPaymentType] = useState<'GENERAL' | 'INVOICE'>('GENERAL'); // To distinguish payment type
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null); // For editing GENERAL payments
  const [targetInvoice, setTargetInvoice] = useState<Transaction | null>(null); // For INVOICE partial payments
  const [editingPaymentRecord, setEditingPaymentRecord] = useState<PaymentRecord | null>(null); // For editing INVOICE payment records

  // DELETE CONFIRMATION STATE
  const [deleteTarget, setDeleteTarget] = useState<{ 
      type: 'CONTACT' | 'TRANSACTION' | 'INVOICE_PAYMENT'; 
      id: string; 
      parentId?: string; // For invoice payments, parentId is the invoice ID
  } | null>(null);

  const [paymentAmount, setPaymentAmount] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [paymentNote, setPaymentNote] = useState('');

  const [formData, setFormData] = useState<Partial<Contact>>({
    name: '',
    phone: '',
    balance: 0
  });

  const filteredContacts = contacts.filter(c => 
    c.type === activeTab && 
    (c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
     c.phone.includes(searchQuery))
  );

  // Calculate Total Balance for the current view
  const totalBalance = filteredContacts.reduce((sum, contact) => sum + contact.balance, 0);

  // Helper: Get Invoice Totals
  const getInvoiceTotals = (t: Transaction) => {
    const subTotal = t.items 
      ? t.items.reduce((acc, item) => acc + (item.price * item.quantity), 0) 
      : t.amount; 
    const discount = t.discount || 0;
    const total = t.amount; 
    const paid = t.paidAmount ?? total;
    const remaining = total - paid;
    return { subTotal, discount, total, paid, remaining };
  };

  // Helper to get current user name AND phone
  const getCurrentUserCreator = () => {
      if (realUser === currentUser) {
          return { name: storeProfile.name || 'المالك', phone: realUser || '' };
      }
      const partner = partners.find(p => p.phone === realUser);
      return { name: partner ? partner.name : 'مستخدم', phone: realUser || '' };
  };

   // Helper to render Creator info safe (handles old string data vs new object data)
   const renderCreatorInfo = (creator: any) => {
    if (!creator) return null;
    if (typeof creator === 'string') return <span>{creator}</span>;
    return (
        <span className="flex items-center">
            {creator.name} 
            <span className="mr-1 text-[9px] text-gray-400 dark:text-gray-500">({creator.phone})</span>
        </span>
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = addContact({
        id: Date.now().toString(),
        type: activeTab,
        name: formData.name || 'Unknown',
        phone: formData.phone || '',
        balance: formData.balance || 0
    });
    
    if (success) {
        setIsAddModalOpen(false);
        setFormData({ name: '', phone: '', balance: 0 });
    }
  };

  const copyToClipboard = (text: string, e: React.MouseEvent) => {
      e.stopPropagation();
      navigator.clipboard.writeText(text).then(() => {
          alert('تم نسخ المعرف بنجاح');
      });
  };

  // --- DELETE LOGIC WITH MODAL ---
  const requestDeleteContact = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      setDeleteTarget({ type: 'CONTACT', id });
  };

  const requestDeleteTransaction = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      setDeleteTarget({ type: 'TRANSACTION', id });
  };

  const requestDeleteInvoicePayment = (transactionId: string, recordId: string) => {
      setDeleteTarget({ type: 'INVOICE_PAYMENT', id: recordId, parentId: transactionId });
  };

  const confirmDelete = () => {
      if (!deleteTarget) return;

      if (deleteTarget.type === 'CONTACT') {
          deleteContact(deleteTarget.id);
          if (viewingContact?.id === deleteTarget.id) setViewingContact(null);
      } else if (deleteTarget.type === 'TRANSACTION') {
          deleteTransaction(deleteTarget.id);
          if (viewingInvoice?.id === deleteTarget.id) setViewingInvoice(null);
      } else if (deleteTarget.type === 'INVOICE_PAYMENT' && deleteTarget.parentId) {
          // Find the transaction first
          const transaction = transactions.find(t => t.id === deleteTarget.parentId);
          if (transaction) {
              const currentHistory = transaction.paymentHistory || [];
              const updatedHistory = currentHistory.filter(rec => rec.id !== deleteTarget.id);
              const newPaidAmount = updatedHistory.reduce((sum, rec) => sum + rec.amount, 0);

              const updatedTransaction: Transaction = {
                  ...transaction,
                  paidAmount: newPaidAmount,
                  paymentHistory: updatedHistory
              };

              updateTransaction(transaction.id, updatedTransaction);
              if (viewingInvoice?.id === transaction.id) setViewingInvoice(updatedTransaction);
          }
      }

      setDeleteTarget(null);
  };

  // --- OPEN PAYMENT MODAL LOGIC ---
  
  // 1. For General Payment (standalone transaction)
  const openGeneralPaymentModal = (tx?: Transaction) => {
      setPaymentType('GENERAL');
      if (tx) {
          setEditingTransaction(tx);
          setPaymentAmount(tx.amount.toString());
          setPaymentDate(tx.date.split('T')[0]);
          setPaymentNote(tx.notes || '');
      } else {
          setEditingTransaction(null);
          setPaymentAmount('');
          setPaymentDate(new Date().toISOString().split('T')[0]);
          setPaymentNote('');
      }
      setIsPaymentModalOpen(true);
  };

  // 2. For Invoice Partial Payment
  const openInvoicePaymentModal = (invoice: Transaction, recordToEdit: PaymentRecord | null = null) => {
      setPaymentType('INVOICE');
      setTargetInvoice(invoice);
      setEditingPaymentRecord(recordToEdit);

      if (recordToEdit) {
          setPaymentAmount(recordToEdit.amount.toString());
          setPaymentDate(recordToEdit.date.split('T')[0]);
          setPaymentNote(recordToEdit.note || '');
      } else {
          const { remaining } = getInvoiceTotals(invoice);
          setPaymentAmount(remaining.toString());
          setPaymentDate(new Date().toISOString().split('T')[0]);
          setPaymentNote('');
      }
      setIsPaymentModalOpen(true);
  };

  // --- SUBMIT PAYMENT LOGIC ---
  const handlePaymentSubmit = () => {
    const amount = parseFloat(paymentAmount);
    if (isNaN(amount) || amount <= 0) {
        alert('الرجاء إدخال مبلغ صحيح');
        return;
    }
    
    const creator = getCurrentUserCreator(); // Get {name, phone}

    if (paymentType === 'GENERAL') {
        // Handle General Transaction Payment
        if (!viewingContact) return;
        const txData: Transaction = {
            id: editingTransaction ? editingTransaction.id : Date.now().toString(),
            type: TransactionType.PAYMENT,
            amount: amount,
            date: new Date(paymentDate).toISOString(),
            paymentMethod: PaymentMethod.CASH,
            contactId: viewingContact.id,
            notes: paymentNote || (editingTransaction ? '' : 'دفعة نقدية مسجلة من صفحة العميل/المورد'),
            paidAmount: amount,
            // addTransaction in StoreContext handles creator, but we can pass it if we modify store context, 
            // OR rely on StoreContext to add it. StoreContext adds it.
        };

        if (editingTransaction) {
            updateTransaction(editingTransaction.id, txData);
        } else {
            const success = addTransaction(txData);
            if (!success) {
                // If failed due to limit, just return, the modal will show from context
                return;
            }
        }
        // Switch to payments tab to see the new record
        setHistoryTab('PAYMENTS');

    } else if (paymentType === 'INVOICE' && targetInvoice) {
        // Handle Invoice Partial Payment
        const currentHistory = targetInvoice.paymentHistory || [];
        let updatedHistory: PaymentRecord[];

        if (editingPaymentRecord) {
            updatedHistory = currentHistory.map(rec => {
                if (rec.id === editingPaymentRecord.id) {
                    return { ...rec, amount, date: new Date(paymentDate).toISOString(), note: paymentNote || 'تم تعديل الدفعة', createdBy: creator };
                }
                return rec;
            });
        } else {
            updatedHistory = [...currentHistory, {
                id: Date.now().toString(),
                date: new Date(paymentDate).toISOString(),
                amount,
                note: paymentNote || 'دفعة مسجلة',
                createdBy: creator // Save object
            }];
        }

        const newPaidAmount = updatedHistory.reduce((sum, rec) => sum + rec.amount, 0);
        const updatedTransaction: Transaction = {
            ...targetInvoice,
            paidAmount: newPaidAmount,
            paymentHistory: updatedHistory
        };

        updateTransaction(targetInvoice.id, updatedTransaction);
        if (viewingInvoice?.id === targetInvoice.id) setViewingInvoice(updatedTransaction);
    }

    // Reset and Close
    setIsPaymentModalOpen(false);
    setPaymentAmount('');
    setPaymentNote('');
    setEditingTransaction(null);
    setTargetInvoice(null);
    setEditingPaymentRecord(null);
  };

  // Helper to get fresh contact data
  const getCurrentContactData = () => {
      if (!viewingContact) return null;
      return contacts.find(c => c.id === viewingContact.id) || viewingContact;
  };

  const currentContact = getCurrentContactData();

  // Get Transactions for specific contact and filter by tab
  const getContactTransactions = (contactId: string) => {
      const all = transactions
        .filter(t => t.contactId === contactId)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

      if (historyTab === 'PAYMENTS') {
          return all.filter(t => t.type === TransactionType.PAYMENT);
      } else {
          return all.filter(t => t.type !== TransactionType.PAYMENT);
      }
  };

  const openDetails = (contact: Contact) => {
      setViewingContact(contact);
      setHistoryTab('INVOICES'); 
  };

  const handleEditInvoice = (transaction: Transaction) => {
      navigate('/add', { state: { editTransaction: transaction } });
  };

  return (
    <div className="p-4 pb-24 min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">العملاء والموردين</h1>
        <button onClick={() => setIsAddModalOpen(true)} className="bg-primary text-white p-2 rounded-lg shadow-md">
          <Plus size={24} />
        </button>
      </div>

      <div className="flex bg-white dark:bg-slate-800 p-1 rounded-xl mb-6 border border-gray-200 dark:border-slate-700">
        <button 
            className={`flex-1 py-2 rounded-lg font-medium text-sm transition-all ${activeTab === 'CLIENT' ? 'bg-primary text-white shadow-sm' : 'text-gray-500 dark:text-gray-400'}`}
            onClick={() => setActiveTab('CLIENT')}
        >
            العملاء
        </button>
        <button 
            className={`flex-1 py-2 rounded-lg font-medium text-sm transition-all ${activeTab === 'SUPPLIER' ? 'bg-primary text-white shadow-sm' : 'text-gray-500 dark:text-gray-400'}`}
            onClick={() => setActiveTab('SUPPLIER')}
        >
            الموردين
        </button>
      </div>

      {/* Search Input */}
      <div className="relative mb-6">
        <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
        <input 
            type="text"
            placeholder={activeTab === 'CLIENT' ? "بحث باسم العميل أو الهاتف..." : "بحث باسم المورد أو الهاتف..."}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-4 pr-10 py-3 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-sm focus:ring-2 focus:ring-primary outline-none text-gray-900 dark:text-white"
        />
      </div>

      <div className="space-y-3">
        {filteredContacts.map(contact => (
            <div 
                key={contact.id} 
                onClick={() => openDetails(contact)}
                className="bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700 cursor-pointer active:scale-[0.98] transition-transform relative"
            >
                <div className="flex justify-between items-start">
                    <div className="flex items-center">
                        <div className="w-10 h-10 bg-gray-100 dark:bg-slate-700 rounded-full flex items-center justify-center text-gray-500 dark:text-gray-400 ml-3">
                            <User size={20} />
                        </div>
                        <div>
                            <h3 className="font-bold text-gray-800 dark:text-white">{contact.name}</h3>
                            {contact.phone && (
                                <div className="flex items-center text-xs text-gray-500 dark:text-gray-400 mt-1">
                                    <Phone size={12} className="ml-1" />
                                    {contact.phone}
                                </div>
                            )}
                             <div className="flex items-center mt-1 gap-2">
                                <span className="text-[10px] bg-gray-100 dark:bg-slate-700 text-gray-500 dark:text-gray-400 px-1.5 py-0.5 rounded font-mono">
                                    ID: {contact.id}
                                </span>
                                <button 
                                    onClick={(e) => copyToClipboard(contact.id, e)}
                                    className="text-gray-400 hover:text-primary transition-colors"
                                    title="نسخ المعرف"
                                >
                                    <Copy size={12} />
                                </button>
                             </div>
                        </div>
                    </div>
                    <button 
                        onClick={(e) => requestDeleteContact(contact.id, e)} 
                        className="text-gray-300 dark:text-slate-600 hover:text-red-500 p-3 rounded-full hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors z-20"
                    >
                        <Trash2 size={20} />
                    </button>
                </div>
                <div className="mt-4 pt-3 border-t border-gray-50 dark:border-slate-700 flex justify-between items-center">
                    <span className="text-xs text-gray-500 dark:text-gray-400">الرصيد الحالي:</span>
                    <span className={`font-bold ${contact.balance > 0 ? 'text-emerald-600 dark:text-emerald-400' : contact.balance < 0 ? 'text-red-600 dark:text-red-400' : 'text-gray-800 dark:text-gray-200'}`}>
                        {Math.abs(contact.balance).toLocaleString()} ج.م
                        <span className="text-[10px] font-normal mr-1">
                            {contact.balance > 0 ? '(له)' : contact.balance < 0 ? '(عليه)' : ''}
                        </span>
                    </span>
                </div>
            </div>
        ))}
        {filteredContacts.length === 0 && <p className="text-center text-gray-400 mt-10">القائمة فارغة</p>}
      </div>

      {/* ... rest of the component (Modals) ... */}
      {filteredContacts.length > 0 && (
          <div className="mt-6 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl p-4 shadow-sm flex items-center justify-between sticky bottom-20 z-10">
              <div className="flex items-center">
                  <div className={`p-2 rounded-lg ml-3 ${totalBalance >= 0 ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' : 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400'}`}>
                      <Wallet size={24} />
                  </div>
                  <div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                          {activeTab === 'CLIENT' ? 'إجمالي ديون العملاء (لنا)' : 'إجمالي ديون الموردين (علينا)'}
                      </p>
                  </div>
              </div>
              <div className="text-left">
                  <span className={`block text-xl font-bold ${totalBalance >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                      {Math.abs(totalBalance).toLocaleString()} <span className="text-sm text-gray-500 font-normal">ج.م</span>
                  </span>
                  <span className="text-[10px] text-gray-400">
                      {totalBalance > 0 ? '(رصيد موجب)' : totalBalance < 0 ? '(رصيد سالب)' : 'خالص'}
                  </span>
              </div>
          </div>
      )}

      {/* --- ADD Contact Modal --- */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white dark:bg-slate-800 rounded-2xl w-full max-w-md p-6">
                <h2 className="text-xl font-bold mb-4 dark:text-white">إضافة {activeTab === 'CLIENT' ? 'عميل' : 'مورد'} جديد</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-300 mb-1">الاسم</label>
                        <input className="w-full border dark:border-slate-600 rounded-lg p-2 bg-white dark:bg-slate-700 text-gray-900 dark:text-white" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} required />
                    </div>
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-300 mb-1">رقم الهاتف</label>
                        <input className="w-full border dark:border-slate-600 rounded-lg p-2 bg-white dark:bg-slate-700 text-gray-900 dark:text-white" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-300 mb-1">الرصيد الافتتاحي (عليه موجب / له سالب)</label>
                        <input 
                            type="number" 
                            className="w-full border dark:border-slate-600 rounded-lg p-2 bg-white dark:bg-slate-700 text-gray-900 dark:text-white" 
                            value={formData.balance === 0 ? '' : formData.balance} 
                            onChange={e => setFormData({...formData, balance: Number(e.target.value)})} 
                        />
                    </div>
                    <div className="flex space-x-3 space-x-reverse pt-4">
                        <button type="submit" className="flex-1 bg-primary text-white py-3 rounded-xl font-bold">حفظ</button>
                        <button type="button" onClick={() => setIsAddModalOpen(false)} className="flex-1 bg-gray-100 dark:bg-slate-600 text-gray-600 dark:text-gray-200 py-3 rounded-xl font-bold">إلغاء</button>
                    </div>
                </form>
            </div>
        </div>
      )}

      {/* --- CONTACT STATEMENT (Account Statement) Modal --- */}
      {currentContact && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end sm:items-center justify-center animate-fade-in">
            <div className="bg-white dark:bg-slate-800 w-full max-w-lg h-[90vh] sm:h-[85vh] sm:rounded-2xl rounded-t-2xl flex flex-col overflow-hidden animate-slide-up sm:animate-none relative transition-colors">
                <div className="p-4 border-b border-gray-100 dark:border-slate-700 flex justify-between items-center bg-gray-50 dark:bg-slate-700">
                    <div>
                        <div className="flex items-center gap-2">
                            <h2 className="text-lg font-bold text-gray-900 dark:text-white">{currentContact.name}</h2>
                             <button 
                                onClick={(e) => copyToClipboard(currentContact.id, e)}
                                className="text-gray-400 hover:text-primary transition-colors"
                                title="نسخ المعرف"
                            >
                                <Copy size={14} />
                            </button>
                        </div>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{currentContact.phone} | ID: {currentContact.id}</p>
                    </div>
                    <button onClick={() => setViewingContact(null)} className="p-2 bg-white dark:bg-slate-600 rounded-full text-gray-500 dark:text-gray-300 shadow-sm">
                        <X size={20} />
                    </button>
                </div>

                <div className="p-4 bg-white dark:bg-slate-800 shadow-sm z-10 space-y-3">
                    <div className="flex justify-between items-center bg-gray-800 dark:bg-slate-900 text-white p-4 rounded-xl">
                        <div className="flex items-center">
                            <Wallet className="text-yellow-400 ml-3" size={24} />
                            <div>
                                <p className="text-xs text-gray-300">الرصيد الحالي</p>
                                <p className="font-bold text-lg">
                                    {Math.abs(currentContact.balance).toLocaleString()} 
                                    <span className="text-xs font-normal mr-1">ج.م</span>
                                </p>
                            </div>
                        </div>
                        <span className={`px-2 py-1 rounded text-xs font-bold ${currentContact.balance > 0 ? 'bg-emerald-500' : currentContact.balance < 0 ? 'bg-red-500' : 'bg-gray-500'}`}>
                            {currentContact.balance > 0 ? 'له' : currentContact.balance < 0 ? 'عليه' : 'متزن'}
                        </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                        <button 
                            onClick={() => openGeneralPaymentModal()}
                            className={`py-3 rounded-xl font-bold flex items-center justify-center shadow-sm text-white transition-colors col-span-2 ${
                                currentContact.type === 'CLIENT' ? 'bg-[#006d77] hover:bg-[#005c66]' : 'bg-blue-600 hover:bg-blue-700'
                            }`}
                        >
                            <Banknote size={20} className="ml-2" />
                            {currentContact.type === 'CLIENT' ? 'تحصيل دفعة' : 'سداد دفعة'}
                        </button>
                        
                        <button 
                             onClick={() => setHistoryTab('PAYMENTS')}
                             className={`py-2 rounded-lg font-bold text-sm border flex items-center justify-center transition-colors ${historyTab === 'PAYMENTS' ? 'bg-purple-50 dark:bg-purple-900/30 border-purple-200 dark:border-purple-800 text-purple-700 dark:text-purple-300' : 'bg-white dark:bg-slate-700 border-gray-200 dark:border-slate-600 text-gray-600 dark:text-gray-300'}`}
                        >
                            <History size={16} className="ml-1" />
                            سجل الدفعات
                        </button>

                         <button 
                             onClick={() => setHistoryTab('INVOICES')}
                             className={`py-2 rounded-lg font-bold text-sm border flex items-center justify-center transition-colors ${historyTab === 'INVOICES' ? 'bg-emerald-50 dark:bg-emerald-900/30 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300' : 'bg-white dark:bg-slate-700 border-gray-200 dark:border-slate-600 text-gray-600 dark:text-gray-300'}`}
                        >
                            <Receipt size={16} className="ml-1" />
                            سجل الفواتير
                        </button>
                    </div>
                </div>

                <div className="bg-gray-50 dark:bg-slate-700 px-4 pt-4 pb-2 border-b border-gray-100 dark:border-slate-600 flex justify-between items-center">
                    <h3 className="font-bold text-gray-700 dark:text-gray-200 text-sm flex items-center">
                        {historyTab === 'INVOICES' ? <FileText size={16} className="ml-2"/> : <History size={16} className="ml-2"/>}
                        {historyTab === 'INVOICES' ? 'فواتير البيع والشراء' : 'سجل الدفعات السابقة'}
                    </h3>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50 dark:bg-slate-800 no-scrollbar">
                    {getContactTransactions(currentContact.id).length > 0 ? (
                        getContactTransactions(currentContact.id).map(t => {
                            const isSale = t.type === TransactionType.SALE;
                            const isPurchase = t.type === TransactionType.PURCHASE;
                            const isPayment = t.type === TransactionType.PAYMENT;
                            
                            return (
                                <div 
                                    key={t.id} 
                                    onClick={() => {
                                        if (isSale || isPurchase) {
                                            // OPEN LOCAL INVOICE VIEW
                                            setViewingInvoice(t);
                                        }
                                    }}
                                    className={`bg-white dark:bg-slate-700 p-3 rounded-xl border border-gray-100 dark:border-slate-600 shadow-sm ${!isPayment ? 'cursor-pointer hover:border-primary transition-colors active:scale-[0.98]' : ''}`}
                                >
                                    <div className="flex justify-between items-center mb-2">
                                        <div className="flex items-center">
                                            <div className={`p-2 rounded-full ml-3 ${
                                                isSale ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' : 
                                                isPurchase ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400' : 
                                                'bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400'
                                            }`}>
                                                {isSale ? <ArrowUpRight size={18}/> : 
                                                isPurchase ? <ArrowDownLeft size={18}/> : 
                                                <Banknote size={18}/>}
                                            </div>
                                            <div>
                                                <h4 className="font-bold text-gray-800 dark:text-white text-sm">
                                                    {isSale ? 'فاتورة بيع' : 
                                                    isPurchase ? 'فاتورة شراء' : 
                                                    'دفعة نقدية'}
                                                </h4>
                                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 flex items-center">
                                                    <Calendar size={10} className="ml-1"/>
                                                    {new Date(t.date).toLocaleDateString('ar-EG')}
                                                </p>
                                                {t.createdBy && (
                                                    <p className="text-[9px] text-gray-400 mt-0.5">
                                                        بواسطة: {t.createdBy.name} <span className="opacity-75">({t.createdBy.phone})</span>
                                                    </p>
                                                )}
                                            </div>
                                        </div>
                                        <div className="flex items-center">
                                            <span className={`font-bold text-sm ${
                                                isSale ? 'text-emerald-600 dark:text-emerald-400' : 
                                                isPurchase ? 'text-blue-600 dark:text-blue-400' : 
                                                'text-purple-600 dark:text-purple-400'
                                            }`}>
                                                {t.amount.toLocaleString()}
                                            </span>
                                        </div>
                                    </div>

                                    {isPayment && (
                                        <div className="flex items-center justify-end space-x-2 space-x-reverse border-t border-gray-50 dark:border-slate-600 pt-2 mt-1">
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); openGeneralPaymentModal(t); }}
                                                className="p-1.5 bg-gray-100 dark:bg-slate-600 text-gray-600 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-slate-500 flex items-center text-xs font-bold"
                                            >
                                                <Edit size={14} className="ml-1" />
                                                تعديل
                                            </button>
                                            <button 
                                                onClick={(e) => requestDeleteTransaction(t.id, e)}
                                                className="p-1.5 bg-red-50 dark:bg-red-900/20 text-red-500 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/40 flex items-center text-xs font-bold"
                                            >
                                                <Trash2 size={14} className="ml-1" />
                                                حذف
                                            </button>
                                        </div>
                                    )}
                                    {t.notes && (
                                        <div className="text-xs text-gray-500 dark:text-gray-400 mt-2 bg-gray-50 dark:bg-slate-800 p-2 rounded">
                                            {t.notes}
                                        </div>
                                    )}
                                </div>
                            );
                        })
                    ) : (
                        <div className="text-center py-8 text-gray-400">
                            <p className="text-sm">لا توجد سجلات لعرضها</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
      )}

      {/* --- INVOICE DETAILS MODAL (LOCAL) --- */}
      {viewingInvoice && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[60] flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white dark:bg-slate-800 w-full max-w-lg rounded-2xl overflow-hidden flex flex-col max-h-[90vh]">
                <div className={`p-4 flex justify-between items-center text-white ${viewingInvoice.type === TransactionType.SALE ? 'bg-emerald-600 dark:bg-emerald-700' : 'bg-blue-600 dark:bg-blue-700'}`}>
                    <div className="flex items-center">
                        <button onClick={() => setViewingInvoice(null)} className="p-1 hover:bg-white/20 rounded-full ml-2">
                            <X size={20} />
                        </button>
                        <h2 className="font-bold text-lg">
                            {viewingInvoice.type === TransactionType.SALE ? 'فاتورة مبيعات' : 'فاتورة مشتريات'}
                        </h2>
                    </div>
                    <div className="flex space-x-2 space-x-reverse">
                        <button onClick={() => handleEditInvoice(viewingInvoice)} className="p-2 bg-white/20 rounded-lg hover:bg-white/30">
                            <Edit size={18} />
                        </button>
                        <button onClick={(e) => requestDeleteTransaction(viewingInvoice.id, e)} className="p-2 bg-white/20 rounded-lg hover:bg-red-500 hover:text-white">
                            <Trash2 size={18} />
                        </button>
                    </div>
                </div>

                <div className="p-6 overflow-y-auto no-scrollbar">
                    {/* Items Table */}
                    <div className="mb-6">
                        <h3 className="font-bold text-gray-800 dark:text-white mb-3 text-sm flex items-center">
                           <ShoppingBag size={16} className="ml-2 text-primary"/>
                           تفاصيل المنتجات
                        </h3>
                        <div className="bg-gray-50 dark:bg-slate-700 rounded-xl overflow-hidden border border-gray-100 dark:border-slate-600">
                            <table className="w-full text-sm">
                                <thead className="bg-gray-100 dark:bg-slate-600 text-gray-500 dark:text-gray-300 text-xs">
                                    <tr>
                                        <th className="p-3 text-right font-medium">المنتج</th>
                                        <th className="p-3 text-center font-medium">الكمية</th>
                                        <th className="p-3 text-center font-medium">السعر</th>
                                        <th className="p-3 text-left font-medium">الاجمالي</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100 dark:divide-slate-600">
                                    {viewingInvoice.items?.map((item, idx) => (
                                        <tr key={idx}>
                                            <td className="p-3 font-bold text-gray-800 dark:text-white">{item.productName}</td>
                                            <td className="p-3 text-center text-gray-600 dark:text-gray-300">{item.quantity}</td>
                                            <td className="p-3 text-center text-gray-600 dark:text-gray-300">{item.price}</td>
                                            <td className="p-3 text-left font-bold text-gray-800 dark:text-white">{(item.quantity * item.price).toLocaleString()}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {(!viewingInvoice.items || viewingInvoice.items.length === 0) && (
                                <div className="p-4 text-center text-gray-400 text-sm italic">لا توجد تفاصيل منتجات (عملية قديمة)</div>
                            )}
                        </div>
                    </div>

                    {/* Payment History */}
                    {viewingInvoice.paymentHistory && viewingInvoice.paymentHistory.length > 0 && (
                        <div className="mb-6">
                            <h3 className="font-bold text-gray-800 dark:text-white mb-3 text-sm flex items-center">
                               <History size={16} className="ml-2 text-primary"/>
                               سجل الدفعات السابقة
                            </h3>
                            <div className="bg-white dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl overflow-hidden text-sm">
                                {viewingInvoice.paymentHistory.map((rec, idx) => (
                                    <div key={idx} className="flex justify-between items-center p-3 border-b border-gray-100 dark:border-slate-600 last:border-0 group">
                                        <div className="flex items-center text-gray-600 dark:text-gray-300 text-xs">
                                            <CheckCircle size={14} className="ml-2 text-emerald-500"/>
                                            <div className="mr-2">
                                                <span className="font-medium block">{new Date(rec.date).toLocaleDateString('ar-EG')}</span>
                                                {rec.createdBy && <span className="text-[10px] text-blue-600 dark:text-blue-400 font-bold block">بواسطة: {renderCreatorInfo(rec.createdBy)}</span>}
                                                {rec.note && <span className="text-gray-400 text-[10px] block">{rec.note}</span>}
                                            </div>
                                        </div>
                                        
                                        <div className="flex items-center">
                                            <span className="font-bold text-emerald-600 dark:text-emerald-400 ml-3">{rec.amount.toLocaleString()} ج.م</span>
                                            <div className="flex space-x-2 space-x-reverse">
                                                <button 
                                                    onClick={() => openInvoicePaymentModal(viewingInvoice, rec)}
                                                    className="p-1.5 bg-gray-100 dark:bg-slate-600 text-gray-600 dark:text-gray-300 rounded-md hover:bg-gray-200 dark:hover:bg-slate-500"
                                                >
                                                    <Edit size={14} />
                                                </button>
                                                <button 
                                                    onClick={() => requestDeleteInvoicePayment(viewingInvoice.id, rec.id)}
                                                    className="p-1.5 bg-red-50 dark:bg-red-900/20 text-red-500 rounded-md hover:bg-red-100 dark:hover:bg-red-900/40"
                                                >
                                                    <Trash2 size={14} />
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Totals */}
                    <div className="bg-gray-50 dark:bg-slate-700 p-4 rounded-xl space-y-2 border border-gray-100 dark:border-slate-600 text-sm">
                        <div className="flex justify-between text-gray-600 dark:text-gray-300">
                            <span>المجموع الفرعي</span>
                            <span>{getInvoiceTotals(viewingInvoice).subTotal.toLocaleString()}</span>
                        </div>
                        {getInvoiceTotals(viewingInvoice).discount > 0 && (
                            <div className="flex justify-between text-red-500 font-medium">
                                <span>الخصم</span>
                                <span>- {getInvoiceTotals(viewingInvoice).discount.toLocaleString()}</span>
                            </div>
                        )}
                        <div className="border-t border-gray-200 dark:border-slate-600 my-2"></div>
                        <div className="flex justify-between font-bold text-lg text-gray-800 dark:text-white">
                            <span>الاجمالي النهائي</span>
                            <span>{getInvoiceTotals(viewingInvoice).total.toLocaleString()} ج.م</span>
                        </div>
                         <div className="flex justify-between text-emerald-600 dark:text-emerald-400 font-medium pt-1">
                            <span>المبلغ المدفوع</span>
                            <span>{getInvoiceTotals(viewingInvoice).paid.toLocaleString()}</span>
                        </div>
                        {getInvoiceTotals(viewingInvoice).remaining > 0 && (
                            <div className="flex justify-between text-red-600 dark:text-red-400 font-bold pt-1">
                                <span>المبلغ المتبقي (آجل)</span>
                                <span>{getInvoiceTotals(viewingInvoice).remaining.toLocaleString()}</span>
                            </div>
                        )}
                    </div>

                    {/* Pay Button */}
                    {getInvoiceTotals(viewingInvoice).remaining > 0 && (
                        <button 
                            onClick={() => openInvoicePaymentModal(viewingInvoice)}
                            className={`w-full mt-4 text-white py-3 rounded-xl font-bold flex items-center justify-center shadow-lg transition-colors ${viewingInvoice.type === TransactionType.SALE ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-blue-600 hover:bg-blue-700'}`}
                        >
                            <CreditCard size={20} className="ml-2" />
                            {viewingInvoice.type === TransactionType.SALE ? 'تسجيل دفعة (تحصيل)' : 'تسجيل دفعة (سداد)'}
                        </button>
                    )}

                    {viewingInvoice.notes && (
                        <div className="mt-4 bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-lg border border-yellow-100 dark:border-yellow-900/30 text-xs text-yellow-800 dark:text-yellow-400">
                            <span className="font-bold block mb-1">ملاحظات:</span>
                            {viewingInvoice.notes}
                        </div>
                    )}
                </div>
            </div>
        </div>
      )}

      {/* --- PAYMENT MODAL (SHARED) --- */}
      {isPaymentModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[70] flex items-center justify-center p-4 animate-fade-in">
             <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 shadow-2xl transition-colors">
                <h3 className="font-bold text-lg mb-4 text-center dark:text-white">
                    {paymentType === 'GENERAL' 
                        ? (activeTab === 'CLIENT' ? 'تحصيل دفعة' : 'سداد دفعة')
                        : (editingPaymentRecord ? 'تعديل الدفعة' : 'تسجيل دفعة جزئية')
                    }
                </h3>
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">المبلغ</label>
                        <input 
                            type="number"
                            value={paymentAmount}
                            onChange={(e) => setPaymentAmount(e.target.value)}
                            className="w-full p-3 border border-gray-300 dark:border-slate-600 rounded-lg font-bold text-center text-xl outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-slate-700 text-gray-900 dark:text-white"
                            placeholder="0"
                            autoFocus
                        />
                    </div>
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">التاريخ</label>
                        <input 
                             type="date"
                             value={paymentDate}
                             onChange={(e) => setPaymentDate(e.target.value)}
                             className="w-full p-3 border border-gray-300 dark:border-slate-600 rounded-lg text-center bg-white dark:bg-slate-700 text-gray-900 dark:text-white"
                        />
                    </div>
                    <div>
                        <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">ملاحظات</label>
                        <textarea 
                             value={paymentNote}
                             onChange={(e) => setPaymentNote(e.target.value)}
                             className="w-full p-3 border border-gray-300 dark:border-slate-600 rounded-lg text-right h-20 resize-none outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-slate-700 text-gray-900 dark:text-white"
                             placeholder="ملاحظات..."
                        />
                    </div>
                    <div className="flex space-x-3 space-x-reverse pt-2">
                        <button 
                            onClick={handlePaymentSubmit}
                            className="flex-1 bg-primary text-white py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors"
                        >
                            حفظ
                        </button>
                        <button 
                            onClick={() => setIsPaymentModalOpen(false)}
                            className="flex-1 bg-gray-100 dark:bg-slate-600 text-gray-700 dark:text-gray-200 py-3 rounded-xl font-bold hover:bg-gray-200 dark:hover:bg-slate-500 transition-colors"
                        >
                            إلغاء
                        </button>
                    </div>
                </div>
             </div>
        </div>
      )}

      {/* --- DELETE CONFIRMATION MODAL --- */}
      {deleteTarget && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-[80] flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-2xl p-6 text-center shadow-xl transition-colors">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <AlertTriangle size={32} className="text-red-600 dark:text-red-500" />
                </div>
                <h3 className="font-bold text-lg text-gray-900 dark:text-white mb-2">
                    {deleteTarget.type === 'CONTACT' ? 'حذف هذا الشخص؟' : 
                     deleteTarget.type === 'TRANSACTION' ? 'حذف العملية؟' : 'حذف الدفعة؟'}
                </h3>
                <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">
                    {deleteTarget.type === 'CONTACT' ? 'سيتم حذف جميع العمليات والسجلات المرتبطة بهذا الشخص. هذا الإجراء لا يمكن التراجع عنه.' :
                     'هل أنت متأكد من حذف هذا السجل؟ سيتم عكس التأثير المالي على الرصيد.'}
                </p>
                <div className="flex space-x-3 space-x-reverse">
                    <button 
                        onClick={confirmDelete}
                        className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 rounded-xl font-bold transition-colors shadow-lg"
                    >
                        نعم، حذف
                    </button>
                    <button 
                        onClick={() => setDeleteTarget(null)}
                        className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 py-3 rounded-xl font-bold transition-colors hover:bg-gray-200 dark:hover:bg-slate-600"
                    >
                        إلغاء
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default Contacts;
