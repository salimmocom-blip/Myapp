
import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo } from 'react';
import { Product, Transaction, Contact, TransactionType, DashboardStats, PaymentMethod, Partner, Permission } from '../types';

interface StoreProfile {
  name: string;
  image: string | null;
  id?: string;
}

// --- Subscription Interface ---
export interface Subscription {
    id: string;
    startDate: string; // ISO string
    endDate: string;   // ISO string
    duration: number;  // Months
    active: boolean;
}

// --- Subscription Limits Constants ---
export const FREE_LIMITS = {
    PRODUCTS: 10,
    CONTACTS: 5,
    TRANSACTIONS: 20
};

type LimitType = 'PRODUCTS' | 'CONTACTS' | 'TRANSACTIONS';

interface StoreContextType {
  currentUser: string | null; 
  realUser: string | null; 
  login: (phone: string) => void;
  logout: () => void;
  
  storeProfile: StoreProfile;
  updateStoreProfile: (profile: Partial<StoreProfile>) => void;

  partners: Partner[];
  addPartner: (name: string, phone: string, permissions: Permission[]) => void;
  updatePartnerPermissions: (phone: string, permissions: Permission[]) => void;
  removePartner: (phone: string) => void;
  
  hasPermission: (permission: Permission) => boolean;

  products: Product[];
  transactions: Transaction[];
  contacts: Contact[];
  addProduct: (product: Product) => boolean;
  updateProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  addTransaction: (transaction: Transaction) => boolean;
  updateTransaction: (id: string, transaction: Transaction) => void;
  deleteTransaction: (id: string) => void;
  addContact: (contact: Contact) => boolean;
  deleteContact: (id: string) => void;
  getDashboardStats: () => DashboardStats;
  resetData: () => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  isLocked: boolean;
  hasPin: boolean;
  unlockApp: (pin: string) => boolean;
  setAppPin: (pin: string) => void;
  removeAppPin: () => void;

  // Subscription Features
  isPro: boolean;
  subscriptionDetails: Subscription | null; // For the current user
  approvedIds: Subscription[]; // List of all subscriptions (Admin view)
  approveId: (id: string, months: number) => void; // Modified to accept months
  revokeId: (id: string) => void;
  checkLimit: (type: LimitType) => boolean;
  
  // Modal Control
  limitReachedType: LimitType | null;
  clearLimitReached: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const GLOBAL_LINKS_KEY = 'hesabaty_account_links'; 
const GLOBAL_APPROVED_IDS_KEY = 'hesabaty_approved_pro_ids'; 

const INITIAL_PRODUCTS: Product[] = [
  { id: '1', name: 'أرز مصري 1ك', code: '1001', buyPrice: 25, sellPrice: 0, stock: 50, minStock: 10 },
  { id: '2', name: 'زيت طعام 700مل', code: '1002', buyPrice: 55, sellPrice: 0, stock: 20, minStock: 5 },
  { id: '3', name: 'سكر أبيض', code: '1003', buyPrice: 35, sellPrice: 0, stock: 5, minStock: 10 },
];

const INITIAL_CONTACTS: Contact[] = [
  { id: '1', name: 'عميل نقدي', phone: '', type: 'CLIENT', balance: 0 },
  { id: '2', name: 'شركة الحمد للتوريدات', phone: '0100000000', type: 'SUPPLIER', balance: -5000 },
];

export const ALL_PERMISSIONS: Permission[] = [
    'DASHBOARD', 'INVENTORY', 'SALES', 'PURCHASES', 'EXPENSES', 'CONTACTS', 'REPORTS'
];

const generateShortId = () => Math.floor(100000 + Math.random() * 900000).toString();

export const StoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<string | null>(() => {
    return localStorage.getItem('hesabaty_current_user');
  });

  const [realUser, setRealUser] = useState<string | null>(() => {
    return localStorage.getItem('hesabaty_real_user') || localStorage.getItem('hesabaty_current_user');
  });

  const [products, setProducts] = useState<Product[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [partners, setPartners] = useState<Partner[]>([]); 
  const [loaded, setLoaded] = useState(false);
  
  const [storeProfile, setStoreProfile] = useState<StoreProfile>({ name: 'حساباتي', image: null });

  // Subscription State (Modified to hold objects)
  const [approvedIds, setApprovedIds] = useState<Subscription[]>(() => {
      const saved = localStorage.getItem(GLOBAL_APPROVED_IDS_KEY);
      if (!saved) return [];
      
      try {
          const parsed = JSON.parse(saved);
          // Migration Logic: If it's an array of strings (old format), convert to objects
          if (Array.isArray(parsed) && parsed.length > 0 && typeof parsed[0] === 'string') {
              const migrated: Subscription[] = parsed.map((id: string) => {
                  const now = new Date();
                  const nextYear = new Date();
                  nextYear.setFullYear(now.getFullYear() + 1);
                  return {
                      id: String(id).trim(),
                      startDate: now.toISOString(),
                      endDate: nextYear.toISOString(),
                      duration: 12,
                      active: true
                  };
              });
              return migrated;
          }
          return parsed;
      } catch (e) {
          return [];
      }
  });
  
  // UI State for Limits
  const [limitReachedType, setLimitReachedType] = useState<LimitType | null>(null);

  const [darkMode, setDarkMode] = useState<boolean>(() => {
      const savedTheme = localStorage.getItem('hesabaty_theme');
      if (savedTheme === null) return true;
      return savedTheme === 'dark';
  });

  const [securityPin, setSecurityPin] = useState<string | null>(null);
  const [isLocked, setIsLocked] = useState<boolean>(false);

  const getUserKey = (key: string) => {
    if (!currentUser) return `hesabaty_temp_${key}`;
    return `hesabaty_${currentUser}_${key}`;
  };

  const login = (phone: string) => {
    const linksStr = localStorage.getItem(GLOBAL_LINKS_KEY);
    const links = linksStr ? JSON.parse(linksStr) : {};
    
    const ownerPhone = links[phone] || phone; 

    localStorage.setItem('hesabaty_current_user', ownerPhone);
    localStorage.setItem('hesabaty_real_user', phone);
    
    setCurrentUser(ownerPhone);
    setRealUser(phone);
  };

  const logout = () => {
    localStorage.removeItem('hesabaty_current_user');
    localStorage.removeItem('hesabaty_real_user');
    setSecurityPin(null);
    setIsLocked(false);
    setProducts([]);
    setTransactions([]);
    setContacts([]);
    setPartners([]);
    setStoreProfile({ name: 'حساباتي', image: null });
    setCurrentUser(null);
    setRealUser(null);
  };

  useEffect(() => {
      if (darkMode) {
          document.documentElement.classList.add('dark');
          localStorage.setItem('hesabaty_theme', 'dark');
      } else {
          document.documentElement.classList.remove('dark');
          localStorage.setItem('hesabaty_theme', 'light');
      }
  }, [darkMode]);

  const toggleDarkMode = () => {
      setDarkMode(prev => !prev);
  };

  useEffect(() => {
    if (!currentUser) {
        setProducts([]);
        setTransactions([]);
        setContacts([]);
        setPartners([]);
        setLoaded(true);
        return; 
    }

    const productsKey = getUserKey('products');
    const transactionsKey = getUserKey('transactions');
    const contactsKey = getUserKey('contacts');
    const partnersKey = getUserKey('partners');
    const pinKey = getUserKey('pin');
    const profileKey = getUserKey('store_profile');

    const loadedProducts = localStorage.getItem(productsKey);
    const loadedTransactions = localStorage.getItem(transactionsKey);
    const loadedContacts = localStorage.getItem(contactsKey);
    const loadedPartners = localStorage.getItem(partnersKey);
    const savedPin = localStorage.getItem(pinKey);
    const savedProfile = localStorage.getItem(profileKey);

    if (savedPin) {
        setSecurityPin(savedPin);
        setIsLocked(true); 
    } else {
        setSecurityPin(null);
        setIsLocked(false);
    }
    
    if (savedProfile) {
        const parsedProfile = JSON.parse(savedProfile);
        if (!parsedProfile.id) {
            parsedProfile.id = generateShortId();
            localStorage.setItem(profileKey, JSON.stringify(parsedProfile));
        }
        setStoreProfile(parsedProfile);
    } else {
        const newProfile = { name: 'حساباتي', image: null, id: generateShortId() };
        setStoreProfile(newProfile);
        localStorage.setItem(profileKey, JSON.stringify(newProfile));
    }

    if (loadedProducts) setProducts(JSON.parse(loadedProducts));
    else setProducts(INITIAL_PRODUCTS);

    if (loadedTransactions) setTransactions(JSON.parse(loadedTransactions));
    else setTransactions([]);
    
    if (loadedContacts) setContacts(JSON.parse(loadedContacts));
    else setContacts(INITIAL_CONTACTS);

    if (loadedPartners) {
        const parsed = JSON.parse(loadedPartners);
        if (parsed.length > 0) {
             const migrated: Partner[] = parsed.map((p: any) => {
                 const base = typeof p === 'string' ? { name: 'موظف', phone: p, permissions: ALL_PERMISSIONS } : { ...p, name: p.name || 'موظف' };
                 if (!base.id) base.id = generateShortId();
                 return base;
             });
             setPartners(migrated);
        } else {
             setPartners(parsed);
        }
    } else {
        setPartners([]);
    }
    
    setLoaded(true);
  }, [currentUser]);

  useEffect(() => {
    if (loaded && currentUser) {
      localStorage.setItem(getUserKey('products'), JSON.stringify(products));
      localStorage.setItem(getUserKey('transactions'), JSON.stringify(transactions));
      localStorage.setItem(getUserKey('contacts'), JSON.stringify(contacts));
      localStorage.setItem(getUserKey('partners'), JSON.stringify(partners));
    }
  }, [products, transactions, contacts, partners, loaded, currentUser]);

  // --- Subscription Logic (Admin Based) ---
  
  // Is this specific store PRO? Checks existence AND expiration date
  const subscriptionDetails = storeProfile.id 
    ? approvedIds.find(sub => String(sub.id).trim() === String(storeProfile.id).trim()) || null
    : null;

  const isPro = useMemo(() => {
      if (!subscriptionDetails) return false;
      const now = new Date();
      const end = new Date(subscriptionDetails.endDate);
      return now <= end;
  }, [subscriptionDetails]);

  const approveId = (id: string, months: number) => {
      const normalizedId = String(id).trim(); 
      if (!normalizedId) return;

      const startDate = new Date();
      const endDate = new Date(startDate);
      endDate.setMonth(endDate.getMonth() + months);

      const newSubscription: Subscription = {
          id: normalizedId,
          startDate: startDate.toISOString(),
          endDate: endDate.toISOString(),
          duration: months,
          active: true
      };

      // Update or Add
      const updatedList = approvedIds.filter(sub => sub.id !== normalizedId);
      const finalList = [...updatedList, newSubscription];
      
      setApprovedIds(finalList);
      localStorage.setItem(GLOBAL_APPROVED_IDS_KEY, JSON.stringify(finalList));
  };

  const revokeId = (id: string) => {
      const normalizedId = String(id).trim();
      const updated = approvedIds.filter(sub => String(sub.id).trim() !== normalizedId);
      setApprovedIds(updated);
      localStorage.setItem(GLOBAL_APPROVED_IDS_KEY, JSON.stringify(updated));
  };

  const checkLimit = (type: LimitType): boolean => {
      if (isPro) return true; // No limits for Pro

      if (type === 'PRODUCTS') return products.length < FREE_LIMITS.PRODUCTS;
      if (type === 'CONTACTS') return contacts.length < FREE_LIMITS.CONTACTS;
      if (type === 'TRANSACTIONS') return transactions.length < FREE_LIMITS.TRANSACTIONS;
      
      return false;
  };
  
  const clearLimitReached = () => setLimitReachedType(null);

  const addPartner = (name: string, phone: string, permissions: Permission[]) => {
      if (!currentUser) return;
      if (partners.some(p => p.phone === phone)) return;
      if (phone === currentUser) return;

      const newId = generateShortId();
      setPartners(prev => [...prev, { id: newId, name, phone, permissions }]);

      const linksStr = localStorage.getItem(GLOBAL_LINKS_KEY);
      const links = linksStr ? JSON.parse(linksStr) : {};
      links[phone] = currentUser; 
      localStorage.setItem(GLOBAL_LINKS_KEY, JSON.stringify(links));
  };

  const updatePartnerPermissions = (phone: string, permissions: Permission[]) => {
      setPartners(prev => prev.map(p => p.phone === phone ? { ...p, permissions } : p));
  };

  const removePartner = (phone: string) => {
      if (!currentUser) return;
      
      setPartners(prev => prev.filter(p => p.phone !== phone));

      const linksStr = localStorage.getItem(GLOBAL_LINKS_KEY);
      if (linksStr) {
          const links = JSON.parse(linksStr);
          delete links[phone];
          localStorage.setItem(GLOBAL_LINKS_KEY, JSON.stringify(links));
      }
  };

  const hasPermission = (permission: Permission): boolean => {
      if (currentUser === realUser) return true;
      const partnerRecord = partners.find(p => p.phone === realUser);
      if (!partnerRecord) return false; 
      return partnerRecord.permissions.includes(permission);
  };

  const updateStoreProfile = (profile: Partial<StoreProfile>) => {
      setStoreProfile(prev => {
          const newProfile = { ...prev, ...profile };
          if (currentUser) {
              localStorage.setItem(getUserKey('store_profile'), JSON.stringify(newProfile));
          }
          return newProfile;
      });
  };

  const unlockApp = (pin: string): boolean => {
      if (securityPin === pin) {
          setIsLocked(false);
          return true;
      }
      return false;
  };

  const setAppPin = (pin: string) => {
      if (!currentUser) return;
      setSecurityPin(pin);
      localStorage.setItem(getUserKey('pin'), pin);
  };

  const removeAppPin = () => {
      if (!currentUser) return;
      setSecurityPin(null);
      setIsLocked(false);
      localStorage.removeItem(getUserKey('pin'));
  };

  const addProduct = (product: Product): boolean => {
    if (!checkLimit('PRODUCTS')) {
        setLimitReachedType('PRODUCTS');
        return false;
    }
    setProducts(prev => [...prev, product]);
    return true;
  };

  const updateProduct = (updatedProduct: Product) => {
    setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => String(p.id) !== String(id)));
  };

  const addTransaction = (transaction: Transaction): boolean => {
    if (!checkLimit('TRANSACTIONS')) {
         setLimitReachedType('TRANSACTIONS');
         return false;
    }

    let creatorName = 'المالك';
    let creatorPhone = realUser || '';

    if (realUser === currentUser) {
        creatorName = storeProfile.name || 'المالك';
    } else {
        const partner = partners.find(p => p.phone === realUser);
        if (partner) creatorName = partner.name;
    }

    const txWithCreator = {
        ...transaction,
        createdBy: {
            name: creatorName,
            phone: creatorPhone
        }
    };

    setTransactions(prev => [txWithCreator, ...prev]);

    if (transaction.items && transaction.items.length > 0) {
      const newProducts = [...products];
      
      transaction.items.forEach(item => {
        const productIndex = newProducts.findIndex(p => p.id === item.productId);
        if (productIndex > -1) {
          if (transaction.type === TransactionType.SALE) {
             newProducts[productIndex] = {
              ...newProducts[productIndex],
              stock: newProducts[productIndex].stock - item.quantity
            };
          }
          else if (transaction.type === TransactionType.PURCHASE) {
             const currentStock = newProducts[productIndex].stock;
             const currentBuyPrice = newProducts[productIndex].buyPrice;
             const incomingQty = item.quantity;
             const incomingPrice = item.price;
             
             let newAvgPrice = incomingPrice;
             
             if (currentStock > 0) {
                 const totalValue = (currentStock * currentBuyPrice) + (incomingQty * incomingPrice);
                 const totalQty = currentStock + incomingQty;
                 newAvgPrice = totalValue / totalQty;
             }

             newProducts[productIndex] = {
              ...newProducts[productIndex],
              stock: newProducts[productIndex].stock + item.quantity,
              buyPrice: parseFloat(newAvgPrice.toFixed(2)), 
              sellPrice: item.sellPrice && item.sellPrice > 0 ? item.sellPrice : newProducts[productIndex].sellPrice // Update Sell Price if provided
            };
          }
        }
      });
      setProducts(newProducts);
    }
    
    if (transaction.contactId) {
      setContacts(prev => prev.map(c => {
        if (c.id !== transaction.contactId) return c;

        let newBalance = c.balance;
        
        if (transaction.type === TransactionType.SALE) {
            const remaining = transaction.amount - (transaction.paidAmount || 0);
            newBalance += remaining;
        } else if (transaction.type === TransactionType.PURCHASE) {
            const remaining = transaction.amount - (transaction.paidAmount || 0);
            newBalance -= remaining; 
        } else if (transaction.type === TransactionType.PAYMENT) {
            if (c.type === 'CLIENT') {
                newBalance -= transaction.amount;
            } else {
                newBalance += transaction.amount;
            }
        }

        return { ...c, balance: newBalance };
      }));
    }
    return true;
  };

  const updateTransaction = (id: string, updatedTx: Transaction) => {
      const oldTx = transactions.find(t => t.id === id);
      if (!oldTx) return;

      if (oldTx.items) {
          const revertProducts = [...products];
          oldTx.items.forEach(item => {
              const pIdx = revertProducts.findIndex(p => p.id === item.productId);
              if (pIdx > -1) {
                  if (oldTx.type === TransactionType.SALE) {
                      revertProducts[pIdx] = { ...revertProducts[pIdx], stock: revertProducts[pIdx].stock + item.quantity };
                  } else if (oldTx.type === TransactionType.PURCHASE) {
                       revertProducts[pIdx] = { ...revertProducts[pIdx], stock: revertProducts[pIdx].stock - item.quantity };
                  }
              }
          });
          setProducts(revertProducts);
      }

      if (oldTx.contactId) {
          setContacts(prev => prev.map(c => {
              if (c.id !== oldTx.contactId) return c;
              let b = c.balance;
              const paid = oldTx.paidAmount || 0;
              const remaining = oldTx.amount - paid;

              if (oldTx.type === TransactionType.SALE) b -= remaining;
              else if (oldTx.type === TransactionType.PURCHASE) b += remaining;
              else if (oldTx.type === TransactionType.PAYMENT) {
                  if (c.type === 'CLIENT') b += oldTx.amount;
                  else b -= oldTx.amount;
              }
              return { ...c, balance: b };
          }));
      }

      setTransactions(prev => prev.map(t => t.id === id ? updatedTx : t));

      if (updatedTx.items) {
          setProducts(prev => {
              const newProds = [...prev];
              updatedTx.items?.forEach(item => {
                   const pIdx = newProds.findIndex(p => p.id === item.productId);
                   if (pIdx > -1) {
                       if (updatedTx.type === TransactionType.SALE) {
                           newProds[pIdx] = { ...newProds[pIdx], stock: newProds[pIdx].stock - item.quantity };
                       } else if (updatedTx.type === TransactionType.PURCHASE) {
                             const currentStock = newProds[pIdx].stock;
                             const currentBuyPrice = newProds[pIdx].buyPrice;
                             const incomingQty = item.quantity;
                             const incomingPrice = item.price;
                             let newAvgPrice = incomingPrice;
                             if (currentStock > 0) {
                                 const totalValue = (currentStock * currentBuyPrice) + (incomingQty * incomingPrice);
                                 const totalQty = currentStock + incomingQty;
                                 newAvgPrice = totalValue / totalQty;
                             }
                           newProds[pIdx] = { 
                               ...newProds[pIdx], 
                               stock: newProds[pIdx].stock + item.quantity,
                               buyPrice: parseFloat(newAvgPrice.toFixed(2)),
                               sellPrice: item.sellPrice && item.sellPrice > 0 ? item.sellPrice : newProds[pIdx].sellPrice
                           };
                       }
                   }
              });
              return newProds;
          });
      }

      if (updatedTx.contactId) {
          setContacts(prev => prev.map(c => {
              if (c.id !== updatedTx.contactId) return c;
              let b = c.balance;
              const paid = updatedTx.paidAmount || 0;
              const remaining = updatedTx.amount - paid;

              if (updatedTx.type === TransactionType.SALE) b += remaining;
              else if (updatedTx.type === TransactionType.PURCHASE) b -= remaining;
              else if (updatedTx.type === TransactionType.PAYMENT) {
                  if (c.type === 'CLIENT') b -= updatedTx.amount;
                  else b += updatedTx.amount;
              }
              return { ...c, balance: b };
          }));
      }
  };

  const deleteTransaction = (id: string) => {
      const tx = transactions.find(t => t.id === id);
      if (!tx) return;

      if (tx.items) {
          setProducts(prev => {
              const newProds = [...prev];
              tx.items?.forEach(item => {
                   const pIdx = newProds.findIndex(p => p.id === item.productId);
                   if (pIdx > -1) {
                       if (tx.type === TransactionType.SALE) {
                           newProds[pIdx] = { ...newProds[pIdx], stock: newProds[pIdx].stock + item.quantity };
                       } else if (tx.type === TransactionType.PURCHASE) {
                           newProds[pIdx] = { ...newProds[pIdx], stock: newProds[pIdx].stock - item.quantity };
                       }
                   }
              });
              return newProds;
          });
      }

      if (tx.contactId) {
          setContacts(prev => prev.map(c => {
              if (c.id !== tx.contactId) return c;
              let b = c.balance;
              const paid = tx.paidAmount || 0;
              const remaining = tx.amount - paid;

              if (tx.type === TransactionType.SALE) b -= remaining;
              else if (tx.type === TransactionType.PURCHASE) b += remaining;
              else if (tx.type === TransactionType.PAYMENT) {
                  if (c.type === 'CLIENT') b += tx.amount;
                  else b -= tx.amount;
              }
              return { ...c, balance: b };
          }));
      }

      setTransactions(prev => prev.filter(t => t.id !== id));
  };

  const addContact = (contact: Contact): boolean => {
    if (!checkLimit('CONTACTS')) {
        setLimitReachedType('CONTACTS');
        return false;
    }
    setContacts(prev => [...prev, contact]);
    return true;
  }
  const deleteContact = (id: string) => setContacts(prev => prev.filter(c => c.id !== id));

  const getDashboardStats = (): DashboardStats => {
      const today = new Date().toISOString().split('T')[0];
      const todayTx = transactions.filter(t => t.date.startsWith(today));
      
      const dailySales = todayTx.filter(t => t.type === TransactionType.SALE).reduce((sum, t) => sum + t.amount, 0);
      const dailyExpenses = todayTx.filter(t => t.type === TransactionType.EXPENSE).reduce((sum, t) => sum + t.amount, 0);
      const dailyPurchases = todayTx.filter(t => t.type === TransactionType.PURCHASE).reduce((sum, t) => sum + t.amount, 0);
      
      let dailyCOGS = 0;
      todayTx.filter(t => t.type === TransactionType.SALE).forEach(sale => {
          sale.items?.forEach(item => {
              const product = products.find(p => p.id === item.productId);
              if (product) dailyCOGS += product.buyPrice * item.quantity;
          });
      });
      const dailyProfit = (dailySales - dailyCOGS) - dailyExpenses;

      const lowStockCount = products.filter(p => p.stock <= p.minStock).length;

      return { dailySales, dailyExpenses, dailyPurchases, dailyProfit, lowStockCount };
  };

  const resetData = () => {
      if (!currentUser) return;
      localStorage.removeItem(getUserKey('products'));
      localStorage.removeItem(getUserKey('transactions'));
      localStorage.removeItem(getUserKey('contacts'));
      setProducts(INITIAL_PRODUCTS);
      setTransactions([]);
      setContacts(INITIAL_CONTACTS);
  };

  return (
    <StoreContext.Provider value={{
      currentUser,
      realUser,
      login,
      logout,
      storeProfile,
      updateStoreProfile,
      partners,
      addPartner,
      updatePartnerPermissions,
      removePartner,
      hasPermission,
      products,
      transactions,
      contacts,
      addProduct,
      updateProduct,
      deleteProduct,
      addTransaction,
      updateTransaction,
      deleteTransaction,
      addContact,
      deleteContact,
      getDashboardStats,
      resetData,
      darkMode,
      toggleDarkMode,
      isLocked,
      hasPin: !!securityPin,
      unlockApp,
      setAppPin,
      removeAppPin,
      isPro,
      subscriptionDetails,
      approvedIds,
      approveId,
      revokeId,
      checkLimit,
      limitReachedType,
      clearLimitReached
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
